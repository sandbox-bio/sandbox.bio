--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 14.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP EVENT TRIGGER IF EXISTS "pgrst_drop_watch";
DROP EVENT TRIGGER IF EXISTS "pgrst_ddl_watch";
DROP EVENT TRIGGER IF EXISTS "issue_pg_graphql_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_cron_access";
DROP EVENT TRIGGER IF EXISTS "issue_graphql_placeholder";
DROP PUBLICATION IF EXISTS "supabase_realtime";
DROP POLICY IF EXISTS "UPDATE" ON "public"."state";
DROP POLICY IF EXISTS "SELECT" ON "public"."state";
DROP POLICY IF EXISTS "INSERT" ON "public"."state";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_owner_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_bucketId_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets" DROP CONSTRAINT IF EXISTS "buckets_owner_fkey";
ALTER TABLE IF EXISTS ONLY "public"."state" DROP CONSTRAINT IF EXISTS "state_env_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_parent_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_user_id_fkey";
DROP TRIGGER IF EXISTS "tr_check_filters" ON "realtime"."subscription";
DROP INDEX IF EXISTS "storage"."name_prefix_search";
DROP INDEX IF EXISTS "storage"."bucketid_objname";
DROP INDEX IF EXISTS "storage"."bname";
DROP INDEX IF EXISTS "realtime"."subscription_subscription_id_entity_filters_key";
DROP INDEX IF EXISTS "realtime"."ix_realtime_subscription_entity";
DROP INDEX IF EXISTS "auth"."users_instance_id_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_email_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_token_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_parent_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_user_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_idx";
DROP INDEX IF EXISTS "auth"."recovery_token_idx";
DROP INDEX IF EXISTS "auth"."reauthentication_token_idx";
DROP INDEX IF EXISTS "auth"."identities_user_id_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_new_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_current_idx";
DROP INDEX IF EXISTS "auth"."confirmation_token_idx";
DROP INDEX IF EXISTS "auth"."audit_logs_instance_id_idx";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_name_key";
ALTER TABLE IF EXISTS ONLY "storage"."buckets" DROP CONSTRAINT IF EXISTS "buckets_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."subscription" DROP CONSTRAINT IF EXISTS "pk_subscription";
ALTER TABLE IF EXISTS ONLY "public"."state" DROP CONSTRAINT IF EXISTS "unique_user_id";
ALTER TABLE IF EXISTS ONLY "public"."state" DROP CONSTRAINT IF EXISTS "state_env_pkey";
ALTER TABLE IF EXISTS ONLY "public"."pings" DROP CONSTRAINT IF EXISTS "pings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."logs" DROP CONSTRAINT IF EXISTS "logs_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_phone_key";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_email_key";
ALTER TABLE IF EXISTS ONLY "auth"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_token_unique";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."instances" DROP CONSTRAINT IF EXISTS "instances_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."audit_log_entries" DROP CONSTRAINT IF EXISTS "audit_log_entries_pkey";
ALTER TABLE IF EXISTS "auth"."refresh_tokens" ALTER COLUMN "id" DROP DEFAULT;
DROP TABLE IF EXISTS "storage"."objects";
DROP TABLE IF EXISTS "storage"."migrations";
DROP TABLE IF EXISTS "storage"."buckets";
DROP TABLE IF EXISTS "realtime"."subscription";
DROP TABLE IF EXISTS "realtime"."schema_migrations";
DROP TABLE IF EXISTS "public"."state";
DROP SEQUENCE IF EXISTS "public"."state_env_id_seq";
DROP TABLE IF EXISTS "public"."pings";
DROP TABLE IF EXISTS "public"."logs";
DROP TABLE IF EXISTS "auth"."users";
DROP TABLE IF EXISTS "auth"."schema_migrations";
DROP SEQUENCE IF EXISTS "auth"."refresh_tokens_id_seq";
DROP TABLE IF EXISTS "auth"."refresh_tokens";
DROP TABLE IF EXISTS "auth"."instances";
DROP TABLE IF EXISTS "auth"."identities";
DROP TABLE IF EXISTS "auth"."audit_log_entries";
DROP FUNCTION IF EXISTS "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer);
DROP FUNCTION IF EXISTS "storage"."get_size_by_bucket"();
DROP FUNCTION IF EXISTS "storage"."foldername"("name" "text");
DROP FUNCTION IF EXISTS "storage"."filename"("name" "text");
DROP FUNCTION IF EXISTS "storage"."extension"("name" "text");
DROP FUNCTION IF EXISTS "realtime"."to_regrole"("role_name" "text");
DROP FUNCTION IF EXISTS "realtime"."subscription_check_filters"();
DROP FUNCTION IF EXISTS "realtime"."quote_wal2json"("entity" "regclass");
DROP FUNCTION IF EXISTS "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]);
DROP FUNCTION IF EXISTS "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text");
DROP FUNCTION IF EXISTS "realtime"."cast"("val" "text", "type_" "regtype");
DROP FUNCTION IF EXISTS "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "pgbouncer"."get_auth"("p_usename" "text");
DROP FUNCTION IF EXISTS "extensions"."set_graphql_placeholder"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_drop_watch"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_ddl_watch"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_graphql_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_cron_access"();
DROP FUNCTION IF EXISTS "auth"."uid"();
DROP FUNCTION IF EXISTS "auth"."role"();
DROP FUNCTION IF EXISTS "auth"."jwt"();
DROP FUNCTION IF EXISTS "auth"."email"();
DROP TYPE IF EXISTS "realtime"."wal_rls";
DROP TYPE IF EXISTS "realtime"."wal_column";
DROP TYPE IF EXISTS "realtime"."user_defined_filter";
DROP TYPE IF EXISTS "realtime"."equality_op";
DROP TYPE IF EXISTS "realtime"."action";
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS "pgjwt";
DROP EXTENSION IF EXISTS "pgcrypto";
DROP EXTENSION IF EXISTS "pg_stat_statements";
DROP SCHEMA IF EXISTS "storage";
DROP SCHEMA IF EXISTS "realtime";
DROP SCHEMA IF EXISTS "pgbouncer";
DROP SCHEMA IF EXISTS "graphql_public";
DROP EXTENSION IF EXISTS "pg_graphql";
DROP SCHEMA IF EXISTS "extensions";
DROP SCHEMA IF EXISTS "auth";
--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "auth";


ALTER SCHEMA "auth" OWNER TO "supabase_admin";

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "extensions";


ALTER SCHEMA "extensions" OWNER TO "postgres";

--
-- Name: pg_graphql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_graphql" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pg_graphql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pg_graphql" IS 'GraphQL support';


--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql_public";


ALTER SCHEMA "graphql_public" OWNER TO "supabase_admin";

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA "pgbouncer";


ALTER SCHEMA "pgbouncer" OWNER TO "pgbouncer";

--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "realtime";


ALTER SCHEMA "realtime" OWNER TO "supabase_admin";

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "storage";


ALTER SCHEMA "storage" OWNER TO "supabase_admin";

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pg_stat_statements"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pg_stat_statements" IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pgcrypto"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pgcrypto" IS 'cryptographic functions';


--
-- Name: pgjwt; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pgjwt" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pgjwt"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pgjwt" IS 'JSON Web Token API for Postgresql';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."action" AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE "realtime"."action" OWNER TO "supabase_admin";

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."equality_op" AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte'
);


ALTER TYPE "realtime"."equality_op" OWNER TO "supabase_admin";

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."user_defined_filter" AS (
	"column_name" "text",
	"op" "realtime"."equality_op",
	"value" "text"
);


ALTER TYPE "realtime"."user_defined_filter" OWNER TO "supabase_admin";

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."wal_column" AS (
	"name" "text",
	"type_name" "text",
	"type_oid" "oid",
	"value" "jsonb",
	"is_pkey" boolean,
	"is_selectable" boolean
);


ALTER TYPE "realtime"."wal_column" OWNER TO "supabase_admin";

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."wal_rls" AS (
	"wal" "jsonb",
	"is_rls_enabled" boolean,
	"subscription_ids" "uuid"[],
	"errors" "text"[]
);


ALTER TYPE "realtime"."wal_rls" OWNER TO "supabase_admin";

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."email"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  	coalesce(
		nullif(current_setting('request.jwt.claim.email', true), ''),
		(nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
	)::text
$$;


ALTER FUNCTION "auth"."email"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "email"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."email"() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."jwt"() RETURNS "jsonb"
    LANGUAGE "sql" STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION "auth"."jwt"() OWNER TO "supabase_auth_admin";

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."role"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  	coalesce(
		nullif(current_setting('request.jwt.claim.role', true), ''),
		(nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
	)::text
$$;


ALTER FUNCTION "auth"."role"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "role"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."role"() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."uid"() RETURNS "uuid"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  	coalesce(
		nullif(current_setting('request.jwt.claim.sub', true), ''),
		(nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
	)::uuid
$$;


ALTER FUNCTION "auth"."uid"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "uid"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."uid"() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: postgres
--

CREATE FUNCTION "extensions"."grant_pg_cron_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  schema_is_cron bool;
BEGIN
  schema_is_cron = (
    SELECT n.nspname = 'cron'
    FROM pg_event_trigger_ddl_commands() AS ev
    LEFT JOIN pg_catalog.pg_namespace AS n
      ON ev.objid = n.oid
  );

  IF schema_is_cron
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option; 

  END IF;

END;
$$;


ALTER FUNCTION "extensions"."grant_pg_cron_access"() OWNER TO "postgres";

--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: COMMENT; Schema: extensions; Owner: postgres
--

COMMENT ON FUNCTION "extensions"."grant_pg_cron_access"() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_graphql_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
DECLARE
    func_is_graphql_resolve bool;
BEGIN
    func_is_graphql_resolve = (
        SELECT n.proname = 'resolve'
        FROM pg_event_trigger_ddl_commands() AS ev
        LEFT JOIN pg_catalog.pg_proc AS n
        ON ev.objid = n.oid
    );

    IF func_is_graphql_resolve
    THEN

        -- Update public wrapper to pass all arguments through to the pg_graphql resolve func
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language sql
        as $$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

		-- This hook executes when `graphql.resolve` is created. That is not necessarily the last
		-- function in the extension so we need to grant permissions on existing entities AND
		-- update default permissions to any others that are created after `graphql.resolve`
        grant usage on schema graphql to postgres, anon, authenticated, service_role;
        grant select on all tables in schema graphql to postgres, anon, authenticated, service_role;
        grant execute on all functions in schema graphql to postgres, anon, authenticated, service_role;
        grant all on all sequences in schema graphql to postgres, anon, authenticated, service_role;
		alter default privileges in schema graphql grant all on tables to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on functions to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on sequences to postgres, anon, authenticated, service_role;
    END IF;

END;
$_$;


ALTER FUNCTION "extensions"."grant_pg_graphql_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_graphql_access"() IS 'Grants access to pg_graphql';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_ddl_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_ddl_watch"() OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_drop_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_drop_watch"() OWNER TO "supabase_admin";

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."set_graphql_placeholder"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION "extensions"."set_graphql_placeholder"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."set_graphql_placeholder"() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: get_auth("text"); Type: FUNCTION; Schema: pgbouncer; Owner: postgres
--

CREATE FUNCTION "pgbouncer"."get_auth"("p_usename" "text") RETURNS TABLE("username" "text", "password" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
    RAISE WARNING 'PgBouncer auth request: %', p_usename;

    RETURN QUERY
    SELECT usename::TEXT, passwd::TEXT FROM pg_catalog.pg_shadow
    WHERE usename = p_usename;
END;
$$;


ALTER FUNCTION "pgbouncer"."get_auth"("p_usename" "text") OWNER TO "postgres";

--
-- Name: apply_rls("jsonb", integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer DEFAULT (1024 * 1024)) RETURNS SETOF "realtime"."wal_rls"
    LANGUAGE "plpgsql"
    AS $$
      declare
          -- Regclass of the table e.g. public.notes
          entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

          -- I, U, D, T: insert, update ...
          action realtime.action = (
              case wal ->> 'action'
                  when 'I' then 'INSERT'
                  when 'U' then 'UPDATE'
                  when 'D' then 'DELETE'
                  else 'ERROR'
              end
          );

          -- Is row level security enabled for the table
          is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

          subscriptions realtime.subscription[] = array_agg(subs)
              from
                  realtime.subscription subs
              where
                  subs.entity = entity_;

          -- Subscription vars
          roles regrole[] = array_agg(distinct us.claims_role)
              from
                  unnest(subscriptions) us;

          working_role regrole;
          claimed_role regrole;
          claims jsonb;

          subscription_id uuid;
          subscription_has_access bool;
          visible_to_subscription_ids uuid[] = '{}';

          -- structured info for wal's columns
          columns realtime.wal_column[];
          -- previous identity values for update/delete
          old_columns realtime.wal_column[];

          error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

          -- Primary jsonb output for record
          output jsonb;

      begin
          perform set_config('role', null, true);

          columns =
              array_agg(
                  (
                      x->>'name',
                      x->>'type',
                      x->>'typeoid',
                      realtime.cast(
                          (x->'value') #>> '{}',
                          coalesce(
                              (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                              (x->>'type')::regtype
                          )
                      ),
                      (pks ->> 'name') is not null,
                      true
                  )::realtime.wal_column
              )
              from
                  jsonb_array_elements(wal -> 'columns') x
                  left join jsonb_array_elements(wal -> 'pk') pks
                      on (x ->> 'name') = (pks ->> 'name');

          old_columns =
              array_agg(
                  (
                      x->>'name',
                      x->>'type',
                      x->>'typeoid',
                      realtime.cast(
                          (x->'value') #>> '{}',
                          coalesce(
                              (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                              (x->>'type')::regtype
                          )
                      ),
                      (pks ->> 'name') is not null,
                      true
                  )::realtime.wal_column
              )
              from
                  jsonb_array_elements(wal -> 'identity') x
                  left join jsonb_array_elements(wal -> 'pk') pks
                      on (x ->> 'name') = (pks ->> 'name');

          for working_role in select * from unnest(roles) loop

              -- Update `is_selectable` for columns and old_columns
              columns =
                  array_agg(
                      (
                          c.name,
                          c.type_name,
                          c.type_oid,
                          c.value,
                          c.is_pkey,
                          pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                      )::realtime.wal_column
                  )
                  from
                      unnest(columns) c;

              old_columns =
                      array_agg(
                          (
                              c.name,
                              c.type_name,
                              c.type_oid,
                              c.value,
                              c.is_pkey,
                              pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                          )::realtime.wal_column
                      )
                      from
                          unnest(old_columns) c;

              if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
                  return next (
                      jsonb_build_object(
                          'schema', wal ->> 'schema',
                          'table', wal ->> 'table',
                          'type', action
                      ),
                      is_rls_enabled,
                      -- subscriptions is already filtered by entity
                      (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
                      array['Error 400: Bad Request, no primary key']
                  )::realtime.wal_rls;

              -- The claims role does not have SELECT permission to the primary key of entity
              elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
                  return next (
                      jsonb_build_object(
                          'schema', wal ->> 'schema',
                          'table', wal ->> 'table',
                          'type', action
                      ),
                      is_rls_enabled,
                      (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
                      array['Error 401: Unauthorized']
                  )::realtime.wal_rls;

              else
                  output = jsonb_build_object(
                      'schema', wal ->> 'schema',
                      'table', wal ->> 'table',
                      'type', action,
                      'commit_timestamp', to_char(
                          (wal ->> 'timestamp')::timestamptz,
                          'YYYY-MM-DD"T"HH24:MI:SS"Z"'
                      ),
                      'columns', (
                          select
                              jsonb_agg(
                                  jsonb_build_object(
                                      'name', pa.attname,
                                      'type', pt.typname
                                  )
                                  order by pa.attnum asc
                              )
                          from
                              pg_attribute pa
                              join pg_type pt
                                  on pa.atttypid = pt.oid
                          where
                              attrelid = entity_
                              and attnum > 0
                              and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
                      )
                  )
                  -- Add "record" key for insert and update
                  || case
                      when action in ('INSERT', 'UPDATE') then
                          case
                              when error_record_exceeds_max_size then
                                  jsonb_build_object(
                                      'record',
                                      (
                                          select jsonb_object_agg((c).name, (c).value)
                                          from unnest(columns) c
                                          where (c).is_selectable and (octet_length((c).value::text) <= 64)
                                      )
                                  )
                              else
                                  jsonb_build_object(
                                      'record',
                                      (select jsonb_object_agg((c).name, (c).value) from unnest(columns) c where (c).is_selectable)
                                  )
                          end
                      else '{}'::jsonb
                  end
                  -- Add "old_record" key for update and delete
                  || case
                      when action in ('UPDATE', 'DELETE') then
                          case
                              when error_record_exceeds_max_size then
                                  jsonb_build_object(
                                      'old_record',
                                      (
                                          select jsonb_object_agg((c).name, (c).value)
                                          from unnest(old_columns) c
                                          where (c).is_selectable and (octet_length((c).value::text) <= 64)
                                      )
                                  )
                              else
                                  jsonb_build_object(
                                      'old_record',
                                      (select jsonb_object_agg((c).name, (c).value) from unnest(old_columns) c where (c).is_selectable)
                                  )
                          end
                      else '{}'::jsonb
                  end;

                  -- Create the prepared statement
                  if is_rls_enabled and action <> 'DELETE' then
                      if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                          deallocate walrus_rls_stmt;
                      end if;
                      execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
                  end if;

                  visible_to_subscription_ids = '{}';

                  for subscription_id, claims in (
                          select
                              subs.subscription_id,
                              subs.claims
                          from
                              unnest(subscriptions) subs
                          where
                              subs.entity = entity_
                              and subs.claims_role = working_role
                              and realtime.is_visible_through_filters(columns, subs.filters)
                  ) loop

                      if not is_rls_enabled or action = 'DELETE' then
                          visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                      else
                          -- Check if RLS allows the role to see the record
                          perform
                              set_config('role', working_role::text, true),
                              set_config('request.jwt.claims', claims::text, true);

                          execute 'execute walrus_rls_stmt' into subscription_has_access;

                          if subscription_has_access then
                              visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                          end if;
                      end if;
                  end loop;

                  perform set_config('role', null, true);

                  return next (
                      output,
                      is_rls_enabled,
                      visible_to_subscription_ids,
                      case
                          when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                          else '{}'
                      end
                  )::realtime.wal_rls;

              end if;
          end loop;

          perform set_config('role', null, true);
      end;
    $$;


ALTER FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) OWNER TO "supabase_admin";

--
-- Name: cast("text", "regtype"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") RETURNS "jsonb"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
    declare
      res jsonb;
    begin
      execute format('select to_jsonb(%L::'|| type_::text || ')', val)  into res;
      return res;
    end
    $$;


ALTER FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") OWNER TO "supabase_admin";

--
-- Name: check_equality_op("realtime"."equality_op", "regtype", "text", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") RETURNS boolean
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
    /*
    Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
    */
    declare
      op_symbol text = (
        case
          when op = 'eq' then '='
          when op = 'neq' then '!='
          when op = 'lt' then '<'
          when op = 'lte' then '<='
          when op = 'gt' then '>'
          when op = 'gte' then '>='
          else 'UNKNOWN OP'
        end
      );
      res boolean;
    begin
      execute format('select %L::'|| type_::text || ' ' || op_symbol || ' %L::'|| type_::text, val_1, val_2) into res;
      return res;
    end;
    $$;


ALTER FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") OWNER TO "supabase_admin";

--
-- Name: is_visible_through_filters("realtime"."wal_column"[], "realtime"."user_defined_filter"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) RETURNS boolean
    LANGUAGE "sql" IMMUTABLE
    AS $$
        /*
        Should the record be visible (true) or filtered out (false) after *filters* are applied
        */
            select
                -- Default to allowed when no filters present
                coalesce(
                    sum(
                        realtime.check_equality_op(
                            op:=f.op,
                            type_:=coalesce(
                                col.type_oid::regtype, -- null when wal2json version <= 2.4
                                col.type_name::regtype
                            ),
                            -- cast jsonb to text
                            val_1:=col.value #>> '{}',
                            val_2:=f.value
                        )::int
                    ) = count(1),
                    true
                )
            from
                unnest(filters) f
                join unnest(columns) col
                    on f.column_name = col.name;
        $$;


ALTER FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) OWNER TO "supabase_admin";

--
-- Name: quote_wal2json("regclass"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."quote_wal2json"("entity" "regclass") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


ALTER FUNCTION "realtime"."quote_wal2json"("entity" "regclass") OWNER TO "supabase_admin";

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."subscription_check_filters"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
      col_names text[] = coalesce(
        array_agg(c.column_name order by c.ordinal_position),
        '{}'::text[]
      )
      from
        information_schema.columns c
      where
        format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
        and pg_catalog.has_column_privilege(
          (new.claims ->> 'role'),
          format('%I.%I', c.table_schema, c.table_name)::regclass,
          c.column_name,
          'SELECT'
        );
      filter realtime.user_defined_filter;
      col_type regtype;
    begin
      for filter in select * from unnest(new.filters) loop
        -- Filtered column is valid
        if not filter.column_name = any(col_names) then
          raise exception 'invalid column for filter %', filter.column_name;
        end if;

        -- Type is sanitized and safe for string interpolation
        col_type = (
          select atttypid::regtype
          from pg_catalog.pg_attribute
          where attrelid = new.entity
            and attname = filter.column_name
        );
        if col_type is null then
          raise exception 'failed to lookup type for column %', filter.column_name;
        end if;
        -- raises an exception if value is not coercable to type
        perform realtime.cast(filter.value, col_type);
      end loop;

      -- Apply consistent order to filters so the unique constraint on
      -- (subscription_id, entity, filters) can't be tricked by a different filter order
      new.filters = coalesce(
        array_agg(f order by f.column_name, f.op, f.value),
        '{}'
      ) from unnest(new.filters) f;

    return new;
  end;
  $$;


ALTER FUNCTION "realtime"."subscription_check_filters"() OWNER TO "supabase_admin";

--
-- Name: to_regrole("text"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."to_regrole"("role_name" "text") RETURNS "regrole"
    LANGUAGE "sql" IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION "realtime"."to_regrole"("role_name" "text") OWNER TO "supabase_admin";

--
-- Name: extension("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."extension"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
_parts text[];
_filename text;
BEGIN
	select string_to_array(name, '/') into _parts;
	select _parts[array_length(_parts,1)] into _filename;
	-- @todo return the last part instead of 2
	return split_part(_filename, '.', 2);
END
$$;


ALTER FUNCTION "storage"."extension"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: filename("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."filename"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION "storage"."filename"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: foldername("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."foldername"("name" "text") RETURNS "text"[]
    LANGUAGE "plpgsql"
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[1:array_length(_parts,1)-1];
END
$$;


ALTER FUNCTION "storage"."foldername"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_size_by_bucket"() RETURNS TABLE("size" bigint, "bucket_id" "text")
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::int) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION "storage"."get_size_by_bucket"() OWNER TO "supabase_storage_admin";

--
-- Name: search("text", "text", integer, integer, integer); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "offsets" integer DEFAULT 0) RETURNS TABLE("name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql"
    AS $$
BEGIN
	return query 
		with files_folders as (
			select path_tokens[levels] as folder
			from storage.objects
			where objects.name ilike prefix || '%'
			and bucket_id = bucketname
			GROUP by folder
			limit limits
			offset offsets
		) 
		select files_folders.folder as name, objects.id, objects.updated_at, objects.created_at, objects.last_accessed_at, objects.metadata from files_folders 
		left join storage.objects
		on prefix || files_folders.folder = objects.name and objects.bucket_id=bucketname;
END
$$;


ALTER FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer) OWNER TO "supabase_storage_admin";

SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."audit_log_entries" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "payload" "json",
    "created_at" timestamp with time zone,
    "ip_address" character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE "auth"."audit_log_entries" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "audit_log_entries"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."audit_log_entries" IS 'Auth: Audit trail for user actions.';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."identities" (
    "id" "text" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "identity_data" "jsonb" NOT NULL,
    "provider" "text" NOT NULL,
    "last_sign_in_at" timestamp with time zone,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone
);


ALTER TABLE "auth"."identities" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "identities"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."identities" IS 'Auth: Stores identities associated to a user.';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."instances" (
    "id" "uuid" NOT NULL,
    "uuid" "uuid",
    "raw_base_config" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone
);


ALTER TABLE "auth"."instances" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "instances"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."instances" IS 'Auth: Manages users across multiple sites.';


--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."refresh_tokens" (
    "instance_id" "uuid",
    "id" bigint NOT NULL,
    "token" character varying(255),
    "user_id" character varying(255),
    "revoked" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "parent" character varying(255)
);


ALTER TABLE "auth"."refresh_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "refresh_tokens"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."refresh_tokens" IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE "auth"."refresh_tokens_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "auth"."refresh_tokens_id_seq" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNED BY "auth"."refresh_tokens"."id";


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."schema_migrations" (
    "version" character varying(255) NOT NULL
);


ALTER TABLE "auth"."schema_migrations" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "schema_migrations"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."schema_migrations" IS 'Auth: Manages updates to the auth system.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."users" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "aud" character varying(255),
    "role" character varying(255),
    "email" character varying(255),
    "encrypted_password" character varying(255),
    "email_confirmed_at" timestamp with time zone,
    "invited_at" timestamp with time zone,
    "confirmation_token" character varying(255),
    "confirmation_sent_at" timestamp with time zone,
    "recovery_token" character varying(255),
    "recovery_sent_at" timestamp with time zone,
    "email_change_token_new" character varying(255),
    "email_change" character varying(255),
    "email_change_sent_at" timestamp with time zone,
    "last_sign_in_at" timestamp with time zone,
    "raw_app_meta_data" "jsonb",
    "raw_user_meta_data" "jsonb",
    "is_super_admin" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "phone" character varying(15) DEFAULT NULL::character varying,
    "phone_confirmed_at" timestamp with time zone,
    "phone_change" character varying(15) DEFAULT ''::character varying,
    "phone_change_token" character varying(255) DEFAULT ''::character varying,
    "phone_change_sent_at" timestamp with time zone,
    "confirmed_at" timestamp with time zone GENERATED ALWAYS AS (LEAST("email_confirmed_at", "phone_confirmed_at")) STORED,
    "email_change_token_current" character varying(255) DEFAULT ''::character varying,
    "email_change_confirm_status" smallint DEFAULT 0,
    "banned_until" timestamp with time zone,
    "reauthentication_token" character varying(255) DEFAULT ''::character varying,
    "reauthentication_sent_at" timestamp with time zone,
    CONSTRAINT "users_email_change_confirm_status_check" CHECK ((("email_change_confirm_status" >= 0) AND ("email_change_confirm_status" <= 2)))
);


ALTER TABLE "auth"."users" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "users"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."users" IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: logs; Type: TABLE; Schema: public; Owner: supabase_admin
--

CREATE TABLE "public"."logs" (
    "id" bigint NOT NULL,
    "time" timestamp with time zone DEFAULT "now"(),
    "pathname" "text",
    "status" smallint,
    "search" "text"
);


ALTER TABLE "public"."logs" OWNER TO "supabase_admin";

--
-- Name: TABLE "logs"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON TABLE "public"."logs" IS 'Logs';


--
-- Name: COLUMN "logs"."time"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."logs"."time" IS 'Timestamp';


--
-- Name: COLUMN "logs"."pathname"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."logs"."pathname" IS 'Path';


--
-- Name: COLUMN "logs"."status"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."logs"."status" IS 'HTTP Status Code';


--
-- Name: COLUMN "logs"."search"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."logs"."search" IS 'Search Params';


--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: public; Owner: supabase_admin
--

ALTER TABLE "public"."logs" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."logs_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: pings; Type: TABLE; Schema: public; Owner: supabase_admin
--

CREATE TABLE "public"."pings" (
    "id" bigint NOT NULL,
    "time" timestamp with time zone DEFAULT "now"() NOT NULL,
    "ip" "text",
    "step_from" smallint,
    "step_to" smallint,
    "tutorial" "text",
    "example" boolean,
    "playground" "text"
);


ALTER TABLE "public"."pings" OWNER TO "supabase_admin";

--
-- Name: TABLE "pings"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON TABLE "public"."pings" IS 'Analytics for tutorial usage';


--
-- Name: COLUMN "pings"."time"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."pings"."time" IS 'Timestamp';


--
-- Name: COLUMN "pings"."ip"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."pings"."ip" IS 'IP Address (MD5-hashed for privacy)';


--
-- Name: COLUMN "pings"."step_from"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."pings"."step_from" IS 'Going from this step';


--
-- Name: COLUMN "pings"."step_to"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."pings"."step_to" IS 'To this step';


--
-- Name: COLUMN "pings"."tutorial"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."pings"."tutorial" IS 'Tutorial Short Name';


--
-- Name: COLUMN "pings"."example"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."pings"."example" IS 'Is example or modified?';


--
-- Name: COLUMN "pings"."playground"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."pings"."playground" IS 'Which playground if applicable';


--
-- Name: pings_id_seq; Type: SEQUENCE; Schema: public; Owner: supabase_admin
--

ALTER TABLE "public"."pings" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."pings_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: state_env_id_seq; Type: SEQUENCE; Schema: public; Owner: supabase_admin
--

CREATE SEQUENCE "public"."state_env_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE "public"."state_env_id_seq" OWNER TO "supabase_admin";

--
-- Name: state; Type: TABLE; Schema: public; Owner: supabase_admin
--

CREATE TABLE "public"."state" (
    "id" integer DEFAULT "nextval"('"public"."state_env_id_seq"'::"regclass") NOT NULL,
    "user_id" "uuid" NOT NULL,
    "env" "jsonb",
    "progress" "jsonb"
);


ALTER TABLE "public"."state" OWNER TO "supabase_admin";

--
-- Name: TABLE "state"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON TABLE "public"."state" IS 'Saved state (env variables, tutorial progress, etc)';


--
-- Name: COLUMN "state"."env"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."state"."env" IS 'Environment Variables';


--
-- Name: COLUMN "state"."progress"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."state"."progress" IS 'Tutorial progress';


--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."schema_migrations" (
    "version" bigint NOT NULL,
    "inserted_at" timestamp(0) without time zone
);


ALTER TABLE "realtime"."schema_migrations" OWNER TO "supabase_admin";

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."subscription" (
    "id" bigint NOT NULL,
    "subscription_id" "uuid" NOT NULL,
    "entity" "regclass" NOT NULL,
    "filters" "realtime"."user_defined_filter"[] DEFAULT '{}'::"realtime"."user_defined_filter"[] NOT NULL,
    "claims" "jsonb" NOT NULL,
    "claims_role" "regrole" GENERATED ALWAYS AS ("realtime"."to_regrole"(("claims" ->> 'role'::"text"))) STORED NOT NULL,
    "created_at" timestamp without time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL
);


ALTER TABLE "realtime"."subscription" OWNER TO "supabase_admin";

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE "realtime"."subscription" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "realtime"."subscription_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "public" boolean DEFAULT false
);


ALTER TABLE "storage"."buckets" OWNER TO "supabase_storage_admin";

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."migrations" (
    "id" integer NOT NULL,
    "name" character varying(100) NOT NULL,
    "hash" character varying(40) NOT NULL,
    "executed_at" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE "storage"."migrations" OWNER TO "supabase_storage_admin";

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."objects" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "bucket_id" "text",
    "name" "text",
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "last_accessed_at" timestamp with time zone DEFAULT "now"(),
    "metadata" "jsonb",
    "path_tokens" "text"[] GENERATED ALWAYS AS ("string_to_array"("name", '/'::"text")) STORED
);


ALTER TABLE "storage"."objects" OWNER TO "supabase_storage_admin";

--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens" ALTER COLUMN "id" SET DEFAULT "nextval"('"auth"."refresh_tokens_id_seq"'::"regclass");


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."audit_log_entries" ("instance_id", "id", "payload", "created_at", "ip_address") FROM stdin;
00000000-0000-0000-0000-000000000000	9ff52dfb-71eb-439c-8e67-3adefb90b5d6	{"action":"user_confirmation_requested","actor_id":"bbfb9638-657a-4818-85e6-cc63fde3e33c","actor_username":"robert.aboukhalil@gmail.com","log_type":"user","timestamp":"2021-09-07T20:24:02Z"}	2021-09-07 20:24:02.689741+00	
00000000-0000-0000-0000-000000000000	c8d564e4-1d8a-4385-8f64-ef6968be2638	{"action":"user_signedup","actor_id":"bbfb9638-657a-4818-85e6-cc63fde3e33c","actor_username":"robert.aboukhalil@gmail.com","log_type":"team","timestamp":"2021-09-07T20:24:45Z"}	2021-09-07 20:24:45.415977+00	
00000000-0000-0000-0000-000000000000	c392b9fc-1f77-464f-a005-79f00f9cab5f	{"action":"login","actor_id":"bbfb9638-657a-4818-85e6-cc63fde3e33c","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-07T20:24:54Z"}	2021-09-07 20:24:54.384855+00	
00000000-0000-0000-0000-000000000000	1f4af204-c200-43f7-835d-acea9b3f2e04	{"action":"user_confirmation_requested","actor_id":"554c1cb5-aba2-4ce0-bdfd-70835fd85aca","actor_username":"robert.aboukhalil@gmail.com","log_type":"user","timestamp":"2021-09-07T20:28:35Z"}	2021-09-07 20:28:35.176303+00	
00000000-0000-0000-0000-000000000000	a612d8df-9bd2-46d1-91a3-cb20ca12b3fe	{"action":"user_signedup","actor_id":"554c1cb5-aba2-4ce0-bdfd-70835fd85aca","actor_username":"robert.aboukhalil@gmail.com","log_type":"team","timestamp":"2021-09-07T20:28:50Z"}	2021-09-07 20:28:50.921851+00	
00000000-0000-0000-0000-000000000000	aa09375e-259b-414b-855a-b6813fb1d7d4	{"action":"login","actor_id":"554c1cb5-aba2-4ce0-bdfd-70835fd85aca","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-07T20:28:59Z"}	2021-09-07 20:28:59.60367+00	
00000000-0000-0000-0000-000000000000	39a34e8e-ee52-4df3-9c14-0b93ecab1a31	{"action":"token_refreshed","actor_id":"554c1cb5-aba2-4ce0-bdfd-70835fd85aca","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T00:09:17Z"}	2021-09-08 00:09:17.532391+00	
00000000-0000-0000-0000-000000000000	9c04ee4c-1eec-49a8-b71e-dc5fefef136b	{"action":"token_revoked","actor_id":"554c1cb5-aba2-4ce0-bdfd-70835fd85aca","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T00:09:17Z"}	2021-09-08 00:09:17.533406+00	
00000000-0000-0000-0000-000000000000	4f7067aa-4976-498f-bd63-b15759747949	{"action":"token_refreshed","actor_id":"554c1cb5-aba2-4ce0-bdfd-70835fd85aca","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T01:12:26Z"}	2021-09-08 01:12:26.800703+00	
00000000-0000-0000-0000-000000000000	158b424b-4fa3-479f-a93c-c4aaed5e712f	{"action":"token_revoked","actor_id":"554c1cb5-aba2-4ce0-bdfd-70835fd85aca","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T01:12:26Z"}	2021-09-08 01:12:26.801777+00	
00000000-0000-0000-0000-000000000000	4ed6fb5b-64f9-4a15-a7a7-d10e065eb2dd	{"action":"token_refreshed","actor_id":"554c1cb5-aba2-4ce0-bdfd-70835fd85aca","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T14:29:06Z"}	2021-09-08 14:29:06.919667+00	
00000000-0000-0000-0000-000000000000	314f2b0c-1ee1-44f0-88a3-a6d40c4ac07c	{"action":"token_revoked","actor_id":"554c1cb5-aba2-4ce0-bdfd-70835fd85aca","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T14:29:06Z"}	2021-09-08 14:29:06.923337+00	
00000000-0000-0000-0000-000000000000	1fdcd3c6-436e-4bce-b14b-cbf7ee65c4be	{"action":"token_refreshed","actor_id":"554c1cb5-aba2-4ce0-bdfd-70835fd85aca","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-24T22:45:45Z"}	2021-09-24 22:45:45.283514+00	
00000000-0000-0000-0000-000000000000	82d9c701-8f6f-43da-988f-20cac946ca55	{"action":"token_revoked","actor_id":"554c1cb5-aba2-4ce0-bdfd-70835fd85aca","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-24T22:45:45Z"}	2021-09-24 22:45:45.284825+00	
00000000-0000-0000-0000-000000000000	df2d73ec-df94-49ad-8c30-79221440fd38	{"action":"logout","actor_id":"554c1cb5-aba2-4ce0-bdfd-70835fd85aca","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-24T22:46:39Z"}	2021-09-24 22:46:39.899237+00	
00000000-0000-0000-0000-000000000000	eb1f83ef-58f2-47f0-81c4-5cc89c261f7f	{"action":"user_confirmation_requested","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"user","timestamp":"2021-10-07T13:22:26Z"}	2021-10-07 13:22:26.731592+00	
00000000-0000-0000-0000-000000000000	dac6692c-a36b-4307-9bb2-4cbab4c35f62	{"action":"user_signedup","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"team","timestamp":"2021-10-07T13:22:44Z"}	2021-10-07 13:22:44.180156+00	
00000000-0000-0000-0000-000000000000	da6e5632-87c9-4ed0-9865-2622bbb757d6	{"action":"login","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"account","timestamp":"2021-10-07T13:22:56Z"}	2021-10-07 13:22:56.230781+00	
00000000-0000-0000-0000-000000000000	976d592d-2d4a-4371-b2ef-57834841695a	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-10-07T20:07:41Z"}	2021-10-07 20:07:41.548208+00	
00000000-0000-0000-0000-000000000000	e44d5597-9dec-4a97-b9f0-569f36f1211a	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-10-07T20:07:41Z"}	2021-10-07 20:07:41.549058+00	
00000000-0000-0000-0000-000000000000	39bb4482-89d6-41b3-99ce-5a70cc54abdf	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-10-08T01:10:02Z"}	2021-10-08 01:10:02.443971+00	
00000000-0000-0000-0000-000000000000	ad5d3a73-c950-4521-9739-791f83814cf0	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-10-08T01:10:02Z"}	2021-10-08 01:10:02.44478+00	
00000000-0000-0000-0000-000000000000	41d8d3de-7135-4ff4-b6df-c5cfbbdc3ce5	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-10-08T02:09:03Z"}	2021-10-08 02:09:03.795391+00	
00000000-0000-0000-0000-000000000000	00922e7e-f428-43d3-81ae-593249cd5862	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-10-08T02:09:03Z"}	2021-10-08 02:09:03.796211+00	
00000000-0000-0000-0000-000000000000	a32cde4d-45a0-4c40-99e6-67c708c44fbe	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-10-08T03:08:06Z"}	2021-10-08 03:08:06.852795+00	
00000000-0000-0000-0000-000000000000	a08dcd79-f141-4046-9361-b640648ae3ed	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-10-08T03:08:06Z"}	2021-10-08 03:08:06.853661+00	
00000000-0000-0000-0000-000000000000	9a7f3634-c9ec-4494-8dbe-634e3f94c4f0	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-10-08T04:07:16Z"}	2021-10-08 04:07:16.294572+00	
00000000-0000-0000-0000-000000000000	b584bb0f-5213-4b15-b5f0-fdb819fc533d	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-10-08T04:07:16Z"}	2021-10-08 04:07:16.297816+00	
00000000-0000-0000-0000-000000000000	f00f19bb-c1d5-455f-8778-3dd893453444	{"action":"login","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"account","timestamp":"2021-10-20T23:38:33Z"}	2021-10-20 23:38:33.869355+00	
00000000-0000-0000-0000-000000000000	69665872-0106-4f7d-9337-57adde8bf821	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-09T18:49:36Z"}	2021-11-09 18:49:36.693763+00	
00000000-0000-0000-0000-000000000000	43f38753-9e26-4327-b501-d8701db4ab01	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-09T18:49:36Z"}	2021-11-09 18:49:36.69482+00	
00000000-0000-0000-0000-000000000000	13c2f3f0-8c75-49ac-ac73-fa7ef1f21a92	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-09T20:09:42Z"}	2021-11-09 20:09:42.22241+00	
00000000-0000-0000-0000-000000000000	47b2b77f-819f-4878-8c29-6ed69b24d7dc	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-09T20:09:42Z"}	2021-11-09 20:09:42.223152+00	
00000000-0000-0000-0000-000000000000	f89a9570-a050-43d7-98ea-2dc16232e460	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-09T21:09:01Z"}	2021-11-09 21:09:01.010227+00	
00000000-0000-0000-0000-000000000000	56e76da5-aa92-4dce-ace6-07792777b79e	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-09T21:09:01Z"}	2021-11-09 21:09:01.010899+00	
00000000-0000-0000-0000-000000000000	4859b1ea-574a-42cc-8888-ed8b010d6f9e	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-09T22:51:14Z"}	2021-11-09 22:51:14.751262+00	
00000000-0000-0000-0000-000000000000	184a8367-225b-42f8-b5ac-00b59ad6ad06	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-09T22:51:14Z"}	2021-11-09 22:51:14.751966+00	
00000000-0000-0000-0000-000000000000	392e1c38-341b-49ee-a2e6-eb2cdcda9665	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T00:05:43Z"}	2021-11-10 00:05:43.40631+00	
00000000-0000-0000-0000-000000000000	56e3f4ca-0c5b-46b1-8d7d-aa7931a7f722	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T00:05:43Z"}	2021-11-10 00:05:43.40786+00	
00000000-0000-0000-0000-000000000000	c24ef76a-6994-4db4-a94b-cbbb57c7cb66	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T01:07:25Z"}	2021-11-10 01:07:25.282992+00	
00000000-0000-0000-0000-000000000000	8aadc69c-9362-45be-9ded-93d66e231811	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T01:07:25Z"}	2021-11-10 01:07:25.283711+00	
00000000-0000-0000-0000-000000000000	9bf78f2a-7a2d-4993-8b81-2376bc9bef24	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T02:42:10Z"}	2021-11-10 02:42:10.460605+00	
00000000-0000-0000-0000-000000000000	8946ab5c-3843-4738-9550-1a75db533bd7	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T02:42:10Z"}	2021-11-10 02:42:10.461366+00	
00000000-0000-0000-0000-000000000000	40fdaca1-af54-4d98-93c0-4257b1983e81	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T03:56:44Z"}	2021-11-10 03:56:44.720824+00	
00000000-0000-0000-0000-000000000000	5f7021b7-5874-4b70-85eb-5cbe036ccb6a	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T03:56:44Z"}	2021-11-10 03:56:44.721582+00	
00000000-0000-0000-0000-000000000000	2edb885e-5a97-4e7d-a67d-34ea926aa2db	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T04:55:47Z"}	2021-11-10 04:55:47.95607+00	
00000000-0000-0000-0000-000000000000	b9dcbfc6-51fe-49f4-8489-4adc3f16f957	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T04:55:47Z"}	2021-11-10 04:55:47.95682+00	
00000000-0000-0000-0000-000000000000	e58635b4-8753-4d51-80b9-f1dbdc6b78ac	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T15:39:51Z"}	2021-11-10 15:39:51.475096+00	
00000000-0000-0000-0000-000000000000	fe50ec10-2606-453e-89b7-b1ef57936aaf	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T15:39:51Z"}	2021-11-10 15:39:51.477858+00	
00000000-0000-0000-0000-000000000000	9f7a16e6-7ff7-4152-8011-1a3aa401c482	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T16:38:58Z"}	2021-11-10 16:38:58.086214+00	
00000000-0000-0000-0000-000000000000	206c25d9-2ba6-4c16-8f17-48e6726ba1c2	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T16:38:58Z"}	2021-11-10 16:38:58.086985+00	
00000000-0000-0000-0000-000000000000	5c45f6ff-1159-4c05-b0b5-4db7793bbfdb	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T17:46:28Z"}	2021-11-10 17:46:28.034792+00	
00000000-0000-0000-0000-000000000000	b38bd3fb-1532-4d28-80da-dd1dbc49cf5c	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T17:46:28Z"}	2021-11-10 17:46:28.035517+00	
00000000-0000-0000-0000-000000000000	699bb13c-a390-4448-a720-874ec958068e	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T18:45:38Z"}	2021-11-10 18:45:38.815378+00	
00000000-0000-0000-0000-000000000000	b89a2fc4-0424-4eae-b663-0c25172be120	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T18:45:38Z"}	2021-11-10 18:45:38.816142+00	
00000000-0000-0000-0000-000000000000	77193e84-ee46-4dd2-bed9-9ca3c9b7c08a	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T19:54:26Z"}	2021-11-10 19:54:26.458004+00	
00000000-0000-0000-0000-000000000000	4ba39947-ba59-4b9f-b410-edc5dbd5bba9	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T19:54:26Z"}	2021-11-10 19:54:26.458907+00	
00000000-0000-0000-0000-000000000000	d84d77ae-a5b9-4d2b-87e5-90cbd3a8fa98	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T20:54:52Z"}	2021-11-10 20:54:52.662301+00	
00000000-0000-0000-0000-000000000000	12055907-011a-4e7d-b54c-34a0a287ec64	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T20:54:52Z"}	2021-11-10 20:54:52.662994+00	
00000000-0000-0000-0000-000000000000	20a4fcfe-484b-4215-a211-dde1b3fc9892	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T21:53:54Z"}	2021-11-10 21:53:54.169535+00	
00000000-0000-0000-0000-000000000000	2a0e576e-cdb9-42dc-b34e-b0e9824afd86	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-10T21:53:54Z"}	2021-11-10 21:53:54.170219+00	
00000000-0000-0000-0000-000000000000	7fd688d5-6eee-4092-9b57-1aa14cc6fce9	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-11T00:04:52Z"}	2021-11-11 00:04:52.656871+00	
00000000-0000-0000-0000-000000000000	964d3215-40a4-4fd4-b429-327de64b3e92	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-11T00:04:52Z"}	2021-11-11 00:04:52.657632+00	
00000000-0000-0000-0000-000000000000	919bf40a-ff2f-4720-bd62-bcd12235c319	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-11T01:10:28Z"}	2021-11-11 01:10:28.357516+00	
00000000-0000-0000-0000-000000000000	97c9f315-dec7-4eac-bc19-f47986990e92	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-11T01:10:28Z"}	2021-11-11 01:10:28.358373+00	
00000000-0000-0000-0000-000000000000	6b63ced8-b623-4b38-99dc-c0c067a6179d	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-11T03:21:49Z"}	2021-11-11 03:21:49.063715+00	
00000000-0000-0000-0000-000000000000	bef80db3-032b-4431-ad27-8d60515e6613	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-11T03:21:49Z"}	2021-11-11 03:21:49.064438+00	
00000000-0000-0000-0000-000000000000	2cfba309-003e-4cc1-8220-ba574c1c042a	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-11T04:21:02Z"}	2021-11-11 04:21:02.996351+00	
00000000-0000-0000-0000-000000000000	2bc13e90-7332-4fea-b7f2-5b4bbbffec70	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-11T04:21:02Z"}	2021-11-11 04:21:02.997159+00	
00000000-0000-0000-0000-000000000000	e4e33de4-5e4f-4e01-b597-6f129eb71f58	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-13T00:51:14Z"}	2021-11-13 00:51:14.94781+00	
00000000-0000-0000-0000-000000000000	2c5b840c-26f8-42d1-a2b3-a84bcb9c9742	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-13T00:51:14Z"}	2021-11-13 00:51:14.950959+00	
00000000-0000-0000-0000-000000000000	9321df8a-e250-44ec-aa15-f6340532cd19	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-13T01:03:21Z"}	2021-11-13 01:03:21.698587+00	
00000000-0000-0000-0000-000000000000	a648fba1-1c95-420b-9f89-042427bc93f1	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-13T01:03:21Z"}	2021-11-13 01:03:21.699306+00	
00000000-0000-0000-0000-000000000000	1c4ea205-2492-4d51-8085-ad4c13e5f367	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-13T01:05:00Z"}	2021-11-13 01:05:00.823893+00	
00000000-0000-0000-0000-000000000000	07718426-3f30-4c02-9174-682ce9ddfd7a	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-13T01:05:00Z"}	2021-11-13 01:05:00.82454+00	
00000000-0000-0000-0000-000000000000	7abc14db-d394-4af5-917f-322a0e5d4ab5	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-23T21:02:00Z"}	2021-11-23 21:02:00.150478+00	
00000000-0000-0000-0000-000000000000	a1b63c91-8b5e-4a47-a3b0-97b3bcd467c5	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-23T21:02:00Z"}	2021-11-23 21:02:00.152341+00	
00000000-0000-0000-0000-000000000000	1dbc3716-c829-46a6-ab78-19f2db954932	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-25T17:42:55Z"}	2021-11-25 17:42:55.25382+00	
00000000-0000-0000-0000-000000000000	0319f149-b0d6-4337-b05e-959abeffc83f	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2021-11-25T17:42:55Z"}	2021-11-25 17:42:55.257255+00	
00000000-0000-0000-0000-000000000000	af87b927-c24e-46a4-955e-32765112eba7	{"action":"login","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"account","timestamp":"2022-04-20T02:19:39Z","traits":{"provider":"email"}}	2022-04-20 02:19:39.270578+00	
00000000-0000-0000-0000-000000000000	7de3cdef-4c0e-4f13-9f9e-bad7fdec203c	{"action":"token_refreshed","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2022-04-20T04:14:51Z"}	2022-04-20 04:14:51.311764+00	
00000000-0000-0000-0000-000000000000	8fdebf0b-af34-4483-9ffb-42015c952c82	{"action":"token_revoked","actor_id":"0c781f47-3894-4762-9ea9-5cad2715fa6c","actor_username":"robert.aboukhalil+2@gmail.com","log_type":"token","timestamp":"2022-04-20T04:14:51Z"}	2022-04-20 04:14:51.312724+00	
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."identities" ("id", "user_id", "identity_data", "provider", "last_sign_in_at", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."instances" ("id", "uuid", "raw_base_config", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."refresh_tokens" ("instance_id", "id", "token", "user_id", "revoked", "created_at", "updated_at", "parent") FROM stdin;
00000000-0000-0000-0000-000000000000	1	A1cxGrIC9QsvzxOYfZwB1Q	bbfb9638-657a-4818-85e6-cc63fde3e33c	f	2021-09-07 20:24:45.418333+00	2021-09-07 20:24:45.418333+00	\N
00000000-0000-0000-0000-000000000000	2	VGlutq3QBc16cHBINxS2hQ	bbfb9638-657a-4818-85e6-cc63fde3e33c	f	2021-09-07 20:24:54.386059+00	2021-09-07 20:24:54.386059+00	\N
00000000-0000-0000-0000-000000000000	9	GZLMIHO2oiULrU9oRpFa0A	0c781f47-3894-4762-9ea9-5cad2715fa6c	f	2021-10-07 13:22:44.183166+00	2021-10-07 13:22:44.183166+00	\N
00000000-0000-0000-0000-000000000000	10	pyUhRivL0Xd1gAMGFBM3ow	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-10-07 13:22:56.231726+00	2021-10-07 13:22:56.231726+00	\N
00000000-0000-0000-0000-000000000000	11	BWMCJTNuotdBNq3EXMwMkg	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-10-07 20:07:41.550838+00	2021-10-07 20:07:41.550838+00	\N
00000000-0000-0000-0000-000000000000	12	YEK5b3K2JEsfK0EMALPIKQ	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-10-08 01:10:02.445939+00	2021-10-08 01:10:02.445939+00	\N
00000000-0000-0000-0000-000000000000	13	x4ai9jxvfI0O0AceZli-Og	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-10-08 02:09:03.797442+00	2021-10-08 02:09:03.797442+00	\N
00000000-0000-0000-0000-000000000000	14	d21d_0PwPTChyUbw0L1xHw	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-10-08 03:08:06.854796+00	2021-10-08 03:08:06.854796+00	\N
00000000-0000-0000-0000-000000000000	15	5MQ9SWMivz0DPeBES-L5iQ	0c781f47-3894-4762-9ea9-5cad2715fa6c	f	2021-10-08 04:07:16.29994+00	2021-10-08 04:07:16.29994+00	\N
00000000-0000-0000-0000-000000000000	16	FSerX6XnXkQ_Y62C3ds1Kw	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-10-20 23:38:33.870684+00	2021-10-20 23:38:33.870684+00	\N
00000000-0000-0000-0000-000000000000	17	gmTygfvxoqx0aUneme76NA	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-09 18:49:36.696142+00	2021-11-09 18:49:36.696142+00	\N
00000000-0000-0000-0000-000000000000	18	gs3xa6ljYgjJ4eTOcn_uNw	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-09 20:09:42.224361+00	2021-11-09 20:09:42.224361+00	\N
00000000-0000-0000-0000-000000000000	19	fgbUwG_xtvPx85tbXEjJfg	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-09 21:09:01.011898+00	2021-11-09 21:09:01.011898+00	\N
00000000-0000-0000-0000-000000000000	20	Vg2dKy6XmE7cZm5zYElIxg	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-09 22:51:14.752875+00	2021-11-09 22:51:14.752875+00	\N
00000000-0000-0000-0000-000000000000	21	gTEkKeEBn-dxRBopAPSTrA	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-10 00:05:43.408905+00	2021-11-10 00:05:43.408905+00	\N
00000000-0000-0000-0000-000000000000	22	esns4PrVbumvXGlx0SwQiw	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-10 01:07:25.284612+00	2021-11-10 01:07:25.284612+00	\N
00000000-0000-0000-0000-000000000000	23	Ef5-aPRxzTTn44Z9sPVpKQ	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-10 02:42:10.462308+00	2021-11-10 02:42:10.462308+00	\N
00000000-0000-0000-0000-000000000000	24	2aR2MNAAiB4CPf9-yhD8Cw	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-10 03:56:44.722468+00	2021-11-10 03:56:44.722468+00	\N
00000000-0000-0000-0000-000000000000	25	3Jl7omifEAnq1t3LYSdC8w	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-10 04:55:47.957754+00	2021-11-10 04:55:47.957754+00	\N
00000000-0000-0000-0000-000000000000	26	Jzxep-5Tz4eegnSMA8jMQw	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-10 15:39:51.479444+00	2021-11-10 15:39:51.479444+00	\N
00000000-0000-0000-0000-000000000000	27	bq_6GoedBx_W7IKyAr4zTg	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-10 16:38:58.087864+00	2021-11-10 16:38:58.087864+00	\N
00000000-0000-0000-0000-000000000000	28	8-5n5EC9NmvhZVKR3Cc4GQ	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-10 17:46:28.036385+00	2021-11-10 17:46:28.036385+00	\N
00000000-0000-0000-0000-000000000000	29	cXAMwt6fSITbLY6LNGLHxQ	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-10 18:45:38.817001+00	2021-11-10 18:45:38.817001+00	\N
00000000-0000-0000-0000-000000000000	30	mhn7cdfX7nQzXZKqQvfucA	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-10 19:54:26.459751+00	2021-11-10 19:54:26.459751+00	\N
00000000-0000-0000-0000-000000000000	31	UPz0cnv20auIK4esTp3U_g	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-10 20:54:52.663864+00	2021-11-10 20:54:52.663864+00	\N
00000000-0000-0000-0000-000000000000	32	5J9shE8lk_MXYAzbEf9diQ	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-10 21:53:54.17107+00	2021-11-10 21:53:54.17107+00	\N
00000000-0000-0000-0000-000000000000	33	x-Jwq1GoExa5MCsrFwkCcQ	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-11 00:04:52.658501+00	2021-11-11 00:04:52.658501+00	\N
00000000-0000-0000-0000-000000000000	34	9nVe6Y1vbVnXFtNuO1Puiw	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-11 01:10:28.359356+00	2021-11-11 01:10:28.359356+00	\N
00000000-0000-0000-0000-000000000000	35	2BUjj7Kpiq8DNQ82hlSzmw	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-11 03:21:49.065297+00	2021-11-11 03:21:49.065297+00	\N
00000000-0000-0000-0000-000000000000	36	qbLoE0Xc2Jcdb8FEnYLRlQ	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-11 04:21:02.998109+00	2021-11-11 04:21:02.998109+00	\N
00000000-0000-0000-0000-000000000000	37	WHiZmn7WtGuEEijNbRnWDQ	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-13 00:51:14.95263+00	2021-11-13 00:51:14.95263+00	\N
00000000-0000-0000-0000-000000000000	38	JM1EAoI0ByqliX8GGHzsyw	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-13 01:03:21.700229+00	2021-11-13 01:03:21.700229+00	\N
00000000-0000-0000-0000-000000000000	39	802yl6jeSp5GQT_aPmaLFA	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-13 01:05:00.825482+00	2021-11-13 01:05:00.825482+00	\N
00000000-0000-0000-0000-000000000000	40	P2O75vHrxcoVqWz-OJgnvw	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2021-11-23 21:02:00.153871+00	2021-11-23 21:02:00.153871+00	\N
00000000-0000-0000-0000-000000000000	41	6m8movK84vJfC4aAUqsoug	0c781f47-3894-4762-9ea9-5cad2715fa6c	f	2021-11-25 17:42:55.259223+00	2021-11-25 17:42:55.259223+00	\N
00000000-0000-0000-0000-000000000000	42	aSbyd8Hm_X-_UyIJ7fSgFg	0c781f47-3894-4762-9ea9-5cad2715fa6c	t	2022-04-20 02:19:39.272809+00	2022-04-20 02:19:39.272812+00	\N
00000000-0000-0000-0000-000000000000	43	SyA6ZJVqVJbXyXkeKb6Gzg	0c781f47-3894-4762-9ea9-5cad2715fa6c	f	2022-04-20 04:14:51.314459+00	2022-04-20 04:14:51.314463+00	aSbyd8Hm_X-_UyIJ7fSgFg
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."schema_migrations" ("version") FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
00
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."users" ("instance_id", "id", "aud", "role", "email", "encrypted_password", "email_confirmed_at", "invited_at", "confirmation_token", "confirmation_sent_at", "recovery_token", "recovery_sent_at", "email_change_token_new", "email_change", "email_change_sent_at", "last_sign_in_at", "raw_app_meta_data", "raw_user_meta_data", "is_super_admin", "created_at", "updated_at", "phone", "phone_confirmed_at", "phone_change", "phone_change_token", "phone_change_sent_at", "email_change_token_current", "email_change_confirm_status", "banned_until", "reauthentication_token", "reauthentication_sent_at") FROM stdin;
00000000-0000-0000-0000-000000000000	554c1cb5-aba2-4ce0-bdfd-70835fd85aca	authenticated	authenticated	robert.aboukhalil@gmail.com	$2a$10$6ZoxGWzhDSeZ0twlehAWqu3DUvb166eeTRXTf3eZXHkGarNwmZ0Vq	2021-09-07 20:28:50.922833+00	\N		2021-09-07 20:28:35.177579+00		\N			\N	2021-09-07 20:28:59.606428+00	{"provider": "email"}	null	f	2021-09-07 20:28:35.172967+00	2021-09-07 20:28:35.172967+00	\N	\N			\N		0	\N		\N
00000000-0000-0000-0000-000000000000	0c781f47-3894-4762-9ea9-5cad2715fa6c	authenticated	authenticated	robert.aboukhalil+2@gmail.com	$2a$10$eWVXJlOB/0quZfr0ygWN0OXeNAMIZFNxaL2sWQF2H9wA/4v7GUiti	2021-10-07 13:22:44.181067+00	\N		2021-10-07 13:22:26.732768+00		\N			\N	2022-04-20 02:19:39.272769+00	{"provider": "email"}	null	f	2021-10-07 13:22:26.721771+00	2021-10-07 13:22:26.721771+00	\N	\N			\N		0	\N		\N
\.


--
-- Data for Name: logs; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY "public"."logs" ("id", "time", "pathname", "status", "search") FROM stdin;
1	2021-08-20 21:32:28.507429+00	/	200	\N
2	2021-08-20 21:32:28.586138+00	/build/bundle.css	200	\N
3	2021-08-20 21:32:28.593789+00	/build/bundle.js	200	\N
4	2021-08-20 21:32:28.762855+00	/images/cli.cropped.png	200	\N
5	2021-08-20 21:53:30.081667+00	/tutorials	200	?id=bowtie2-intro
6	2021-08-20 21:53:30.150221+00	/build/bundle.js	200	
7	2021-08-20 21:53:30.314956+00	/build/bootstrap.min.css.map	404	
8	2021-08-20 21:53:30.484341+00	/build/bundle.js.map	200	
9	2021-08-20 21:53:31.153489+00	/build/bundle.css	200	
10	2021-08-20 21:53:33.2123+00	/data/bowtie2-intro/reads_1.fq	200	
11	2021-08-20 21:53:33.228657+00	/data/bowtie2-intro/reads_1.fq	200	
12	2021-08-20 21:53:33.384398+00	/data/bowtie2-intro/reads_2.fq	200	
13	2021-08-20 21:53:33.412922+00	/data/bowtie2-intro/reads_2.fq	200	
14	2021-08-20 21:53:33.62676+00	/data/bowtie2-intro/longreads.fq	200	
15	2021-08-20 21:53:33.688432+00	/data/bowtie2-intro/longreads.fq	200	
16	2021-08-20 21:53:33.844172+00	/data/bowtie2-intro/r1.fq	404	
17	2021-08-20 21:53:37.457241+00	/data/bowtie2-intro/r1.fq	404	
18	2021-08-21 20:24:10.249688+00	/build/bundle.js	200	
19	2021-08-21 20:24:10.388102+00	/images/cli.cropped.png	200	
20	2021-08-23 00:14:55.557894+00	/build/bundle.css	200	
21	2021-08-23 00:14:55.65712+00	/build/bundle.js	200	
22	2021-08-23 00:14:56.006729+00	/images/cli.cropped.png	200	
23	2021-08-23 00:14:58.233233+00	/data/bedtools-intro/cpg.bed	200	
24	2021-08-23 00:14:58.37833+00	/data/bedtools-intro/exons.bed	200	
25	2021-08-23 00:14:58.579553+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
26	2021-08-23 00:14:58.737955+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
27	2021-08-23 00:14:58.907909+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
28	2021-08-23 00:14:59.09107+00	/data/bedtools-intro/gwas.bed	200	
29	2021-08-23 00:14:59.224437+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
30	2021-08-23 00:14:59.395224+00	/data/bedtools-intro/genome.txt	200	
31	2021-08-23 17:35:38.434441+00	/build/bundle.js	200	
32	2021-08-23 20:27:15.397817+00	/images/cli.cropped.png	200	
33	2021-08-23 20:27:27.408734+00	/build/bundle.css	200	
34	2021-08-23 20:27:27.442906+00	/build/bundle.js	200	
35	2021-08-23 20:27:27.433264+00	/	200	
36	2021-08-23 20:27:27.491951+00	/images/cli.cropped.png	200	
37	2021-08-24 19:07:58.131836+00	/images/cli.cropped.png	200	
38	2021-08-24 19:07:59.696603+00	/data/bedtools-intro/cpg.bed	200	
39	2021-08-24 19:07:59.865697+00	/data/bedtools-intro/exons.bed	200	
40	2021-08-24 19:08:00.058545+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
41	2021-08-24 19:08:00.246423+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
42	2021-08-24 19:08:00.435434+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
43	2021-08-24 19:08:00.67153+00	/data/bedtools-intro/gwas.bed	200	
44	2021-08-24 19:08:00.814838+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
45	2021-08-24 19:08:00.940713+00	/data/bedtools-intro/genome.txt	200	
46	2021-08-24 19:08:02.570326+00	/build/bundle.js	200	
47	2021-08-25 15:00:34.153195+00	/tutorials	200	?id=samtools-intro&step=6
48	2021-08-25 15:00:34.241627+00	/build/bundle.js	200	
49	2021-08-25 15:00:34.74513+00	/data/samtools-intro/sample.sam	200	
50	2021-08-25 15:00:34.842799+00	/data/samtools-intro/sample.sam	200	
51	2021-08-25 15:00:37.8211+00	/tutorials	200	?id=samtools-intro
52	2021-08-25 15:00:39.610424+00	/api/v1/ping	200	
53	2021-08-25 15:00:39.998425+00	/api/v1/ping	200	
54	2021-08-25 15:00:40.434179+00	/api/v1/ping	200	
55	2021-08-25 15:00:40.65684+00	/api/v1/ping	200	
56	2021-08-25 15:00:40.837816+00	/api/v1/ping	200	
57	2021-08-25 15:00:41.221849+00	/api/v1/ping	200	
58	2021-08-25 15:00:43.874633+00	/data/samtools-intro/sample.bam.bai	200	
59	2021-08-25 15:00:43.89004+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.e4fqu3sfpph
60	2021-08-25 15:00:43.970337+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.msrpt1sqzxs
61	2021-08-25 15:00:44.036281+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.t26c8d1790k
62	2021-08-25 15:00:44.082487+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.bfiydz8izol
63	2021-08-31 17:35:17.946606+00	/	200	
64	2021-08-31 17:35:18.084144+00	/build/bundle.css	200	
65	2021-08-31 17:35:18.088474+00	/build/bundle.js	200	
66	2021-08-31 17:35:18.475052+00	/images/cli.png	200	
67	2021-08-31 17:35:18.975204+00	/	200	
68	2021-08-31 17:35:19.045079+00	/build/bundle.js	200	
69	2021-08-31 17:35:19.053632+00	/build/bundle.css	200	
70	2021-08-31 17:35:19.118903+00	/images/cli.png	200	
71	2021-08-31 17:35:22.981492+00	/tutorials	200	?id=bowtie2-intro
72	2021-08-31 17:35:23.406608+00	/data/bowtie2-intro/reads_1.fq	200	
73	2021-08-31 17:35:23.475296+00	/data/bowtie2-intro/reads_1.fq	200	
74	2021-08-31 17:35:23.650409+00	/data/bowtie2-intro/reads_2.fq	200	
75	2021-08-31 17:35:23.704448+00	/data/bowtie2-intro/reads_2.fq	200	
76	2021-08-31 17:35:23.856528+00	/data/bowtie2-intro/longreads.fq	200	
77	2021-08-31 17:35:23.933782+00	/data/bowtie2-intro/longreads.fq	200	
78	2021-08-31 17:35:25.70491+00	/api/v1/ping	200	
79	2021-08-31 17:35:27.307711+00	/api/v1/ping	200	
80	2021-08-31 17:35:28.041932+00	/api/v1/ping	200	
81	2021-08-31 17:35:28.275463+00	/api/v1/ping	200	
82	2021-08-31 17:35:28.700563+00	/api/v1/ping	200	
83	2021-08-31 17:35:29.508577+00	/tutorials	200	?id=samtools-intro
84	2021-08-31 17:35:29.935867+00	/data/samtools-intro/sample.sam	200	
85	2021-08-31 17:35:29.995625+00	/data/samtools-intro/sample.sam	200	
86	2021-08-31 17:35:30.545776+00	/api/v1/ping	200	
87	2021-08-31 17:35:30.738796+00	/api/v1/ping	200	
88	2021-08-31 17:35:30.887922+00	/api/v1/ping	200	
89	2021-08-31 17:35:31.08314+00	/api/v1/ping	200	
90	2021-08-31 17:35:31.234871+00	/api/v1/ping	200	
91	2021-08-31 17:35:31.615248+00	/api/v1/ping	200	
92	2021-09-04 23:41:28.163676+00	/	200	
93	2021-09-04 23:41:28.47244+00	/build/bundle.js	200	
94	2021-09-04 23:41:28.486592+00	/build/bundle.css	200	
95	2021-09-07 20:05:03.318715+00	/build/bundle.js	200	
96	2021-09-07 20:05:03.318336+00	/build/bundle.css	200	
97	2021-09-07 20:05:03.59386+00	/images/cli.png	200	
98	2021-09-07 20:05:04.620705+00	/	200	
99	2021-09-07 20:05:04.690628+00	/build/bundle.css	200	
100	2021-09-07 20:05:04.692491+00	/build/bundle.js	200	
101	2021-09-07 20:05:04.775266+00	/images/cli.png	200	
102	2021-09-07 20:06:13.697834+00	/	200	
103	2021-09-07 20:06:13.747364+00	/build/bundle.css	200	
104	2021-09-07 20:06:13.75726+00	/build/bundle.js	200	
105	2021-09-07 20:06:15.891473+00	/	200	
106	2021-09-07 20:06:15.949061+00	/build/bundle.js	200	
107	2021-09-07 20:06:15.962537+00	/build/bundle.css	200	
108	2021-09-07 20:06:16.496075+00	/	200	
109	2021-09-07 20:06:16.582972+00	/build/bundle.js	200	
110	2021-09-07 20:06:16.591443+00	/build/bundle.css	200	
111	2021-09-07 20:06:16.909164+00	/	200	
112	2021-09-07 20:06:16.951241+00	/build/bundle.css	200	
113	2021-09-07 20:06:16.961324+00	/build/bundle.js	200	
114	2021-09-07 20:06:17.063201+00	/	200	
115	2021-09-07 20:06:17.117356+00	/build/bundle.css	200	
116	2021-09-07 20:06:17.134785+00	/build/bundle.js	200	
117	2021-09-07 20:06:17.217399+00	/	200	
118	2021-09-07 20:06:17.27476+00	/build/bundle.css	200	
119	2021-09-07 20:06:17.291654+00	/build/bundle.js	200	
120	2021-09-07 20:06:17.396092+00	/	200	
121	2021-09-07 20:06:17.448416+00	/build/bundle.js	200	
122	2021-09-07 20:06:17.461139+00	/build/bundle.css	200	
123	2021-09-07 20:06:17.639704+00	/	200	
124	2021-09-07 20:06:17.705832+00	/build/bundle.css	200	
125	2021-09-07 20:06:17.734215+00	/build/bundle.js	200	
126	2021-09-07 20:06:29.633099+00	/build/bootstrap.min.css.map	404	
127	2021-09-07 20:06:29.871256+00	/build/bundle.js.map	200	
128	2021-09-07 20:19:32.320368+00	/	200	
129	2021-09-07 20:19:32.438241+00	/build/bundle.js	200	
130	2021-09-07 20:19:32.444057+00	/build/bundle.css	200	
131	2021-09-07 20:19:34.216089+00	/build/bundle.js.map	200	
132	2021-09-07 20:19:34.323867+00	/build/bootstrap.min.css.map	404	
133	2021-09-07 20:19:35.184642+00	/	200	
134	2021-09-07 20:19:35.24475+00	/build/bundle.css	200	
135	2021-09-07 20:19:35.257639+00	/build/bundle.js	200	
136	2021-09-07 20:19:35.31239+00	/build/bootstrap.min.css.map	404	
137	2021-09-07 20:19:35.348824+00	/build/bundle.js.map	200	
138	2021-09-07 20:22:47.270012+00	/	200	
139	2021-09-07 20:22:47.336586+00	/build/bundle.css	200	
140	2021-09-07 20:22:47.559518+00	/build/bundle.js	200	
141	2021-09-07 20:22:47.642162+00	/build/bootstrap.min.css.map	404	
142	2021-09-07 20:22:47.765602+00	/images/cli.png	200	
143	2021-09-07 20:22:48.489966+00	/build/bundle.js.map	200	
144	2021-09-07 20:25:00.878048+00	/tutorials	200	?id=terminal-basics
145	2021-09-07 20:25:01.897559+00	/data/terminal-basics/orders.tsv	200	
146	2021-09-07 20:25:01.963794+00	/api/v1/ping	200	
147	2021-09-07 20:25:02.11991+00	/data/terminal-basics/ref.fa	200	
148	2021-09-07 20:25:02.309587+00	/data/terminal-basics/ref.fa.bak	200	
149	2021-09-07 20:25:03.951356+00	/tutorials	200	
150	2021-09-07 20:28:08.604479+00	/	200	
151	2021-09-07 20:28:08.645684+00	/build/bundle.css	200	
152	2021-09-07 20:28:08.655321+00	/build/bundle.js	200	
153	2021-09-07 20:28:08.890943+00	/images/cli.png	200	
154	2021-09-07 20:28:08.89389+00	/build/bundle.js.map	200	
155	2021-09-07 20:28:08.901395+00	/build/bootstrap.min.css.map	404	
156	2021-09-07 20:28:11.777171+00	/	200	
157	2021-09-07 20:28:11.830992+00	/build/bundle.css	200	
158	2021-09-07 20:28:11.839332+00	/build/bundle.js	200	
159	2021-09-07 20:28:11.890563+00	/build/bootstrap.min.css.map	404	
160	2021-09-07 20:28:11.952032+00	/build/bundle.js.map	200	
161	2021-09-07 20:28:11.955251+00	/images/cli.png	200	
162	2021-09-07 20:32:03.967548+00	/build/bundle.js.map	200	
163	2021-09-07 20:32:04.041079+00	/build/bootstrap.min.css.map	404	
164	2021-09-07 20:32:04.200641+00	/data/terminal-basics/orders.tsv	200	
165	2021-09-07 20:32:04.458036+00	/data/terminal-basics/ref.fa	200	
166	2021-09-07 20:32:04.610749+00	/data/terminal-basics/ref.fa.bak	200	
167	2021-09-07 20:32:04.925988+00	/api/v1/ping	200	
168	2021-09-07 20:32:05.070184+00	/api/v1/ping	200	
169	2021-09-07 20:32:05.215991+00	/api/v1/ping	200	
170	2021-09-08 00:09:19.988567+00	/tutorials	200	?id=jq-intro
171	2021-09-08 00:09:20.293493+00	/data/jq-intro/repo.json	200	
172	2021-09-08 00:09:20.348699+00	/data/jq-intro/repo.json	200	
173	2021-09-08 00:09:20.548253+00	/data/jq-intro/issues.json	200	
174	2021-09-08 00:09:20.590916+00	/data/jq-intro/issues.json	200	
175	2021-09-08 00:09:20.786164+00	/data/jq-intro/issue.json	200	
176	2021-09-08 00:09:20.839711+00	/data/jq-intro/issue.json	200	
177	2021-09-08 00:09:23.65731+00	/api/v1/ping	200	
178	2021-09-08 00:09:42.828007+00	/tutorials	200	?id=jq-intro&step=8
179	2021-09-08 00:09:42.88579+00	/build/bundle.css	200	
180	2021-09-08 00:09:43.005634+00	/build/bundle.js	404	
181	2021-09-08 00:09:44.28157+00	/tutorials	200	?id=jq-intro&step=8
182	2021-09-08 00:09:44.345603+00	/build/bundle.css	200	
183	2021-09-08 00:09:44.365484+00	/build/bundle.js	404	
184	2021-09-08 00:09:45.021159+00	/tutorials	200	?id=jq-intro&step=8
185	2021-09-08 00:09:45.084421+00	/build/bundle.css	200	
186	2021-09-08 00:09:45.096052+00	/build/bundle.js	404	
187	2021-09-08 00:09:46.269507+00	/build/bootstrap.min.css.map	404	
188	2021-09-08 00:09:46.889869+00	/tutorials	200	?id=jq-intro&step=8
189	2021-09-08 00:09:46.98607+00	/build/bundle.css	200	
190	2021-09-08 00:09:47.040188+00	/build/bundle.js	404	
191	2021-09-08 00:09:47.12751+00	/build/bootstrap.min.css.map	404	
192	2021-09-08 00:09:52.936629+00	/tutorials	200	?id=jq-intro&step=8
193	2021-09-08 00:09:53.16589+00	/build/bundle.css	200	
194	2021-09-08 00:09:53.197056+00	/build/bundle.js	200	
195	2021-09-08 00:09:53.229893+00	/build/bootstrap.min.css.map	404	
196	2021-09-08 00:09:53.362012+00	/build/bundle.js.map	200	
197	2021-09-08 00:11:13.40767+00	/api/v1/ping	200	
198	2021-09-08 00:11:28.328913+00	/tutorials	200	?id=terminal-basics&step=3
199	2021-09-08 00:11:28.987773+00	/data/terminal-basics/orders.tsv	200	
200	2021-09-08 00:11:29.2058+00	/data/terminal-basics/ref.fa	200	
201	2021-09-08 00:11:29.392519+00	/data/terminal-basics/ref.fa.bak	200	
202	2021-09-08 00:11:34.307179+00	/api/v1/ping	200	
203	2021-09-08 00:11:34.495898+00	/api/v1/ping	200	
204	2021-09-08 00:11:34.709456+00	/api/v1/ping	200	
205	2021-09-08 00:11:34.888863+00	/api/v1/ping	200	
206	2021-09-09 21:21:12.620334+00	/build/bundle.css	200	
207	2021-09-09 21:21:12.645007+00	/build/bundle.js	200	
208	2021-09-24 22:45:44.566992+00	/	200	
209	2021-09-24 22:45:44.831669+00	/build/bundle.css	200	
210	2021-09-24 22:45:44.855668+00	/build/bundle.js	200	
211	2021-09-24 22:45:45.200848+00	/images/cli.png	200	
212	2021-09-24 22:46:35.346809+00	/	200	
213	2021-09-24 22:46:35.564046+00	/build/bundle.js	200	
214	2021-09-24 22:46:35.599609+00	/build/bundle.css	200	
215	2021-09-24 22:46:35.827765+00	/images/cli.png	200	
216	2021-09-24 22:46:40.016785+00	/	200	
217	2021-09-24 22:46:40.506511+00	/	200	
218	2021-09-24 22:46:40.573973+00	/build/bundle.css	200	
219	2021-09-24 22:46:40.590782+00	/build/bundle.js	200	
220	2021-09-24 22:46:40.709587+00	/images/cli.png	200	
221	2021-09-24 22:46:42.103183+00	/tutorials	200	?id=rosalind
222	2021-09-24 22:46:42.361627+00	/images/rosalind.png	200	
223	2021-09-24 22:46:49.7493+00	/api/v1/ping	200	
224	2021-09-24 22:46:54.603914+00	/api/v1/ping	200	
225	2021-09-24 22:47:03.545196+00	/api/v1/ping	200	
226	2021-09-24 22:47:04.067721+00	/api/v1/ping	200	
227	2021-09-24 22:47:04.476444+00	/api/v1/ping	200	
228	2021-09-24 22:47:04.92416+00	/api/v1/ping	200	
229	2021-09-24 22:47:05.477912+00	/api/v1/ping	200	
230	2021-09-24 22:47:05.62096+00	/api/v1/ping	200	
231	2021-09-24 22:47:06.054765+00	/tutorials	200	?id=rosalind&step=2
232	2021-09-25 01:57:29.284251+00	/build/bundle.js	200	
233	2021-09-25 01:57:29.716762+00	/images/cli.png	200	
234	2021-09-25 01:57:59.736923+00	/	200	
235	2021-09-25 01:57:59.759578+00	/build/bundle.css	200	
236	2021-09-25 01:58:00.570118+00	/build/bundle.js	200	
237	2021-09-25 01:58:00.776595+00	/images/cli.png	200	
238	2021-09-25 01:58:03.209918+00	/rosalind	404	
239	2021-09-25 01:58:05.796264+00	/rosalind	404	
240	2021-09-25 01:58:06.300052+00	/rosalind	404	
241	2021-09-25 01:58:06.825157+00	/rosalind	404	
242	2021-09-25 01:58:06.982639+00	/rosalind	404	
243	2021-09-25 01:58:07.139998+00	/rosalind	404	
244	2021-09-25 01:58:07.282784+00	/rosalind	404	
245	2021-09-25 01:58:07.46116+00	/rosalind	404	
246	2021-09-25 01:58:07.605379+00	/rosalind	404	
247	2021-09-25 01:58:13.348539+00	/rosalind	404	
248	2021-09-25 01:59:26.541217+00	/rosalind	404	
249	2021-09-25 01:59:27.150736+00	/rosalind	404	
250	2021-09-25 01:59:27.48237+00	/rosalind	404	
251	2021-09-25 01:59:27.572816+00	/rosalind	404	
252	2021-09-25 01:59:27.774043+00	/rosalind	404	
253	2021-09-25 01:59:27.950259+00	/rosalind	404	
254	2021-09-25 01:59:28.070217+00	/rosalind	404	
255	2021-09-25 01:59:28.280207+00	/rosalind	404	
256	2021-09-25 01:59:37.736242+00	/rosalind/index.html	200	
257	2021-09-25 01:59:38.829362+00	/rosalind/index.html	200	
258	2021-09-25 01:59:39.113082+00	/build/bundle.css	200	
259	2021-09-25 01:59:39.277739+00	/build/bundle.js	200	
260	2021-09-25 01:59:39.54833+00	/images/rosalind.png	200	
261	2021-09-25 01:59:41.61165+00	/rosalind	404	
262	2021-09-25 01:59:42.418583+00	/rosalind	404	
263	2021-09-25 01:59:43.200416+00	/rosalind	404	
264	2021-09-25 01:59:45.147784+00	/rosalind/index.html	200	
265	2021-09-25 01:59:45.221259+00	/build/bundle.js	200	
266	2021-09-25 01:59:45.236572+00	/build/bundle.css	200	
267	2021-09-25 01:59:45.347978+00	/images/rosalind.png	200	
268	2021-09-25 02:01:44.814178+00	/rosalind	404	
269	2021-09-25 02:01:47.247785+00	/rosalind	404	
270	2021-09-25 02:01:49.565572+00	/rosalind	404	
271	2021-09-25 02:01:50.076177+00	/rosalind	404	
272	2021-09-25 02:01:50.392029+00	/rosalind	404	
273	2021-09-25 02:02:18.035077+00	/rosalind	200	
274	2021-09-25 02:02:18.081253+00	/build/bundle.js	200	
275	2021-09-25 02:02:18.107471+00	/build/bundle.css	200	
276	2021-09-25 02:02:18.298046+00	/images/rosalind.png	200	
277	2021-09-25 02:04:32.354096+00	/api/v1/ping	200	
278	2021-09-25 02:04:33.040942+00	/api/v1/ping	200	
279	2021-09-25 02:04:34.777647+00	/api/v1/ping	200	
280	2021-09-25 02:04:40.141523+00	/build/bootstrap.min.css.map	404	
281	2021-09-25 02:04:40.395936+00	/build/bundle.js.map	200	
282	2021-09-25 02:04:49.293742+00	/build/bootstrap.min.css.map	404	
283	2021-09-25 02:04:49.315889+00	/build/bundle.js.map	200	
284	2021-09-25 02:53:19.671409+00	/	200	
285	2021-09-25 02:53:19.719743+00	/build/bundle.css	200	
286	2021-09-25 02:53:19.733571+00	/build/bundle.js	200	
287	2021-09-25 02:53:19.87769+00	/images/cli.png	200	
288	2021-09-25 04:02:52.965433+00	/api/v1/ping	200	
289	2021-09-25 04:02:54.095+00	/api/v1/ping	200	
290	2021-09-25 04:03:57.353144+00	/api/v1/ping	200	
291	2021-09-25 04:10:42.482957+00	/api/v1/ping	200	
292	2021-09-25 04:10:50.380099+00	/api/v1/ping	200	
293	2021-09-25 04:10:52.153577+00	/api/v1/ping	200	
294	2021-09-25 04:10:53.005426+00	/api/v1/ping	200	
295	2021-09-25 04:10:53.811238+00	/api/v1/ping	200	
296	2021-09-25 04:10:55.804911+00	/rosalind	200	?step=0
297	2021-09-25 04:10:58.418723+00	/api/v1/ping	200	
298	2021-09-25 04:11:24.993697+00	/api/v1/ping	200	
299	2021-09-25 04:11:26.07616+00	/api/v1/ping	200	
300	2021-09-25 04:11:27.361094+00	/api/v1/ping	200	
301	2021-09-25 04:11:53.724844+00	/api/v1/ping	200	
302	2021-09-25 04:13:11.15022+00	/api/v1/ping	200	
303	2021-09-25 04:14:37.950132+00	/api/v1/ping	200	
304	2021-09-26 00:55:12.797508+00	/build/bundle.js	200	
305	2021-09-26 00:55:13.08388+00	/images/cli.png	200	
306	2021-09-28 00:54:45.132994+00	/	200	
307	2021-09-28 00:54:45.518802+00	/build/bundle.css	200	
308	2021-09-28 00:54:45.562086+00	/build/bundle.js	200	
309	2021-09-28 00:54:45.935931+00	/images/cli.png	200	
310	2021-09-28 00:54:46.576102+00	/rosalind	200	
311	2021-09-28 00:54:46.871835+00	/images/rosalind.png	200	
312	2021-09-28 03:29:18.768201+00	/rosalind	200	
313	2021-09-28 03:29:18.820611+00	/build/bundle.css	200	
314	2021-09-28 03:29:19.064888+00	/build/bundle.js	200	
315	2021-09-28 03:29:19.250023+00	/images/rosalind.png	200	
316	2021-09-29 22:21:38.93977+00	/build/bundle.js	200	
317	2021-09-29 22:21:38.939694+00	/build/bundle.css	200	
318	2021-10-04 00:35:54.450698+00	/	200	
319	2021-10-04 00:35:54.679213+00	/build/bundle.css	200	
320	2021-10-04 00:35:55.548385+00	/build/bundle.js	200	
321	2021-10-04 00:35:56.024149+00	/images/cli.png	200	
322	2021-10-04 00:35:56.808307+00	/rosalind	200	
323	2021-10-04 00:35:57.115913+00	/images/rosalind.png	200	
324	2021-10-04 00:35:57.822294+00	/rosalind	200	
325	2021-10-04 00:35:58.026949+00	/build/bundle.js	200	
326	2021-10-04 00:35:58.039358+00	/build/bundle.css	200	
327	2021-10-04 00:35:58.276335+00	/images/rosalind.png	200	
328	2021-10-04 01:50:58.300617+00	/build/bootstrap.min.css.map	404	
329	2021-10-04 01:50:58.854744+00	/build/bundle.js.map	200	
330	2021-10-04 01:51:03.890362+00	/	200	
331	2021-10-04 01:51:04.002909+00	/build/bootstrap.min.css.map	404	
332	2021-10-04 01:51:04.016817+00	/build/bundle.js.map	200	
333	2021-10-04 01:51:05.802123+00	/	200	
334	2021-10-04 01:51:05.92856+00	/build/bundle.js.map	200	
335	2021-10-04 01:51:05.93868+00	/build/bootstrap.min.css.map	404	
336	2021-10-04 05:42:40.185906+00	/build/bundle.js.map	200	
337	2021-10-04 05:42:40.48201+00	/build/bootstrap.min.css.map	404	
338	2021-10-04 05:42:40.581773+00	/	200	
339	2021-10-04 05:42:41.3438+00	/build/bundle.css	200	
340	2021-10-04 05:42:41.514523+00	/build/bootstrap.min.css.map	404	
341	2021-10-04 05:42:42.249567+00	/build/bundle.js	200	
342	2021-10-04 05:42:42.648907+00	/build/bundle.js.map	200	
343	2021-10-04 05:42:43.909895+00	/images/cli.png	200	
344	2021-10-04 05:42:44.611709+00	/	200	
345	2021-10-07 04:09:51.638137+00	/tutorials	200	
346	2021-10-07 04:09:51.93726+00	/build/bundle.css	200	
347	2021-10-07 04:09:51.997532+00	/build/bundle.js	200	
348	2021-10-07 04:09:53.557501+00	/tutorials	200	
349	2021-10-07 04:09:53.651549+00	/build/bundle.css	200	
350	2021-10-07 04:09:53.673734+00	/build/bundle.js	200	
351	2021-10-07 04:10:59.741907+00	/tutorials	200	
352	2021-10-07 04:10:59.857793+00	/build/bundle.css	200	
353	2021-10-07 04:11:00.053227+00	/build/bundle.js	200	
354	2021-10-07 04:11:02.281074+00	/tutorials	200	?id=awk-intro
355	2021-10-07 04:11:03.434658+00	/data/awk-intro/orders.tsv	200	
356	2021-10-07 04:11:03.500239+00	/data/awk-intro/orders.tsv	200	
357	2021-10-07 04:11:17.57738+00	/tutorials	304	?id=awk-intro
358	2021-10-07 04:11:19.585936+00	/tutorials	304	?id=awk-intro
359	2021-10-07 04:11:28.376627+00	/api/v1/ping	200	
360	2021-10-07 04:11:33.889093+00	/api/v1/ping	200	
361	2021-10-07 04:11:34.059391+00	/api/v1/ping	200	
362	2021-10-07 13:14:22.799603+00	/tutorials	200	?id=terminal-basics
363	2021-10-07 13:14:23.180814+00	/data/terminal-basics/orders.tsv	200	
364	2021-10-07 13:14:23.358798+00	/data/terminal-basics/ref.fa	200	
365	2021-10-07 13:14:23.575776+00	/data/terminal-basics/ref.fa.bak	200	
366	2021-10-07 13:14:23.682305+00	/data/terminal-basics/orders.tsv	200	
367	2021-10-07 13:14:23.816092+00	/data/terminal-basics/ref.fa	200	
368	2021-10-07 13:14:23.871996+00	/data/terminal-basics/ref.fa.bak	200	
369	2021-10-07 13:15:17.368183+00	/tutorials	304	?id=awk-intro
370	2021-10-07 13:15:22.346018+00	/build/bootstrap.min.css.map	404	
371	2021-10-07 13:15:22.956662+00	/build/bundle.js.map	200	
372	2021-10-07 13:15:26.021535+00	/tutorials	304	?id=awk-intro
373	2021-10-07 13:15:26.398136+00	/build/bundle.js.map	200	
374	2021-10-07 13:15:26.40844+00	/build/bootstrap.min.css.map	404	
375	2021-10-07 13:15:41.20264+00	/tutorials	304	?id=awk-intro
376	2021-10-07 13:15:41.477876+00	/build/bundle.js.map	200	
377	2021-10-07 13:15:41.839265+00	/build/bootstrap.min.css.map	404	
378	2021-10-07 13:15:52.906108+00	/tutorials	304	?id=awk-intro
379	2021-10-07 13:15:53.078646+00	/build/bundle.js.map	200	
380	2021-10-07 13:15:53.184972+00	/build/bootstrap.min.css.map	404	
381	2021-10-07 13:22:45.050491+00	/	200	
382	2021-10-07 13:22:45.762967+00	/images/cli.png	200	
383	2021-10-07 13:22:56.336018+00	/	304	
384	2021-10-07 13:23:03.27119+00	/data/awk-intro/orders.tsv	304	
385	2021-10-07 13:23:34.763183+00	/api/v1/ping	200	
386	2021-10-07 13:24:29.4062+00	/api/v1/ping	200	
387	2021-10-07 13:25:02.624416+00	/api/v1/ping	200	
388	2021-10-07 13:26:45.632837+00	/api/v1/ping	200	
389	2021-10-07 13:28:33.242993+00	/api/v1/ping	200	
390	2021-10-07 13:29:12.669805+00	/api/v1/ping	200	
391	2021-10-07 13:31:41.819786+00	/api/v1/ping	200	
392	2021-10-07 13:35:04.755394+00	/api/v1/ping	200	
393	2021-10-07 13:37:47.379945+00	/api/v1/ping	200	
394	2021-10-07 13:38:50.069688+00	/api/v1/ping	200	
395	2021-10-07 13:48:05.483799+00	/tutorials	200	?id=awk-intro&step=10
396	2021-10-07 13:48:05.85375+00	/data/awk-intro/orders.tsv	200	
397	2021-10-07 13:51:38.305558+00	/tutorials	200	?id=awk-intro&step=10
398	2021-10-07 13:51:38.369704+00	/build/bundle.css	200	
399	2021-10-07 13:51:38.571891+00	/build/bundle.js	200	
400	2021-10-07 13:51:39.401377+00	/data/awk-intro/orders.tsv	200	
401	2021-10-07 13:54:25.290036+00	/build/bootstrap.min.css.map	404	
402	2021-10-07 13:54:25.688016+00	/build/bundle.js.map	200	
403	2021-10-07 14:01:21.098582+00	/build/bootstrap.min.css.map	404	
404	2021-10-07 14:01:21.310745+00	/data/awk-intro/orders.tsv	200	
405	2021-10-07 14:01:21.345611+00	/build/bundle.js.map	200	
406	2021-10-07 14:01:25.679157+00	/api/v1/ping	200	
407	2021-10-07 14:01:31.62089+00	/api/v1/ping	200	
408	2021-10-07 14:01:40.471615+00	/api/v1/ping	200	
409	2021-10-07 14:02:05.068491+00	/api/v1/ping	200	
410	2021-10-07 14:02:05.876784+00	/api/v1/ping	200	
411	2021-10-07 14:02:10.010959+00	/api/v1/ping	200	
412	2021-10-07 14:02:14.945352+00	/api/v1/ping	200	
413	2021-10-07 14:03:19.664076+00	/api/v1/ping	200	
414	2021-10-07 14:03:38.667384+00	/api/v1/ping	200	
415	2021-10-07 14:03:39.000062+00	/api/v1/ping	200	
416	2021-10-07 14:03:41.754415+00	/api/v1/ping	200	
417	2021-10-07 20:07:39.511412+00	/playground	200	
418	2021-10-07 20:07:41.2353+00	/build/bundle.js	200	
419	2021-10-07 20:07:46.348032+00	/data/awk-intro/orders.tsv	200	
420	2021-10-07 20:07:49.644311+00	/api/v1/ping	200	
421	2021-10-07 20:07:54.366966+00	/api/v1/ping	200	
422	2021-10-08 01:10:01.808402+00	/	200	
423	2021-10-08 01:10:01.811047+00	/build/bundle.css	200	
424	2021-10-08 01:10:01.82221+00	/build/bundle.js	200	
425	2021-10-08 01:10:02.612175+00	/images/cli.png	200	
426	2021-10-08 01:10:04.814252+00	/tutorials	200	?id=awk-intro
427	2021-10-08 01:10:07.823638+00	/data/awk-intro/orders.tsv	200	
428	2021-10-08 01:10:25.401076+00	/tutorials	304	?id=awk-intro
429	2021-10-08 01:10:25.541311+00	/data/awk-intro/orders.tsv	200	
430	2021-10-08 01:10:25.611662+00	/data/awk-intro/orders.tsv	200	
431	2021-10-08 01:11:39.863701+00	/api/v1/ping	200	
432	2021-10-08 01:17:22.35769+00	/api/v1/ping	200	
433	2021-10-08 01:18:10.150764+00	/api/v1/ping	200	
434	2021-10-08 01:20:05.292394+00	/api/v1/ping	200	
435	2021-10-08 01:24:14.613642+00	/api/v1/ping	200	
436	2021-10-08 01:30:21.225916+00	/api/v1/ping	200	
437	2021-10-08 01:34:21.038882+00	/api/v1/ping	200	
438	2021-10-08 01:38:49.901631+00	/api/v1/ping	200	
439	2021-10-08 01:45:43.328899+00	/api/v1/ping	200	
440	2021-10-08 01:46:21.686362+00	/api/v1/ping	200	
441	2021-10-08 02:54:48.179427+00	/api/v1/ping	200	
442	2021-10-08 02:54:52.691083+00	/api/v1/ping	200	
443	2021-10-08 02:54:53.787516+00	/tutorials	200	?id=awk-intro&step=0
444	2021-10-08 02:54:53.861142+00	/build/bundle.css	200	
445	2021-10-08 02:54:54.509542+00	/build/bundle.js	200	
446	2021-10-08 02:54:55.192226+00	/data/awk-intro/orders.tsv	200	
447	2021-10-08 02:54:56.872418+00	/api/v1/ping	200	
448	2021-10-08 02:55:12.747873+00	/api/v1/ping	200	
449	2021-10-08 02:55:34.560122+00	/api/v1/ping	200	
450	2021-10-08 02:55:35.166678+00	/api/v1/ping	200	
451	2021-10-08 02:55:35.805471+00	/api/v1/ping	200	
452	2021-10-08 02:55:36.481816+00	/api/v1/ping	200	
453	2021-10-08 02:58:45.118008+00	/api/v1/ping	200	
454	2021-10-08 02:58:46.955272+00	/api/v1/ping	200	
455	2021-10-08 02:58:48.217292+00	/api/v1/ping	200	
456	2021-10-08 02:58:49.376313+00	/api/v1/ping	200	
457	2021-10-08 03:02:37.404655+00	/api/v1/ping	200	
458	2021-10-08 03:03:40.133986+00	/tutorials	200	?id=bedtools-intro
459	2021-10-08 03:03:41.894591+00	/data/bedtools-intro/cpg.bed	200	
460	2021-10-08 03:03:42.069968+00	/data/bedtools-intro/exons.bed	200	
461	2021-10-08 03:03:42.284442+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
462	2021-10-08 03:03:42.445793+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
463	2021-10-08 03:03:42.612729+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
464	2021-10-08 03:03:42.77915+00	/data/bedtools-intro/gwas.bed	200	
465	2021-10-08 03:03:42.959084+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
466	2021-10-08 03:03:43.123637+00	/data/bedtools-intro/genome.txt	200	
467	2021-10-08 03:03:43.279984+00	/data/bedtools-intro/cpg.bed	200	
468	2021-10-08 03:03:43.338364+00	/data/bedtools-intro/exons.bed	200	
469	2021-10-08 03:03:43.424293+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
470	2021-10-08 03:03:43.481696+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
471	2021-10-08 03:03:43.537564+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
472	2021-10-08 03:03:43.590247+00	/data/bedtools-intro/gwas.bed	200	
473	2021-10-08 03:03:43.658033+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
474	2021-10-08 03:03:43.713437+00	/data/bedtools-intro/genome.txt	200	
475	2021-10-08 03:03:45.76814+00	/api/v1/ping	200	
476	2021-10-08 03:03:53.409592+00	/api/v1/ping	200	
477	2021-10-08 03:03:55.862105+00	/images/cli.png	200	
478	2021-10-20 23:38:34.177989+00	/tutorials	200	?id=terminal-basics
479	2021-10-20 23:38:34.286423+00	/build/bundle.css	200	
480	2021-10-20 23:38:34.296813+00	/build/bundle.js	200	
481	2021-10-20 23:38:34.491812+00	/build/bundle.js.map	200	
482	2021-10-20 23:38:34.525012+00	/build/bootstrap.min.css.map	404	
483	2021-10-20 23:38:35.535065+00	/data/terminal-basics/orders.tsv	200	
484	2021-10-20 23:38:35.693277+00	/data/terminal-basics/ref.fa	200	
485	2021-10-20 23:38:35.882659+00	/data/terminal-basics/ref.fa.bak	200	
486	2021-11-09 18:49:36.09715+00	/	200	
487	2021-11-09 18:49:36.352135+00	/build/bundle.css	200	
488	2021-11-09 18:49:36.355722+00	/build/bundle.js	200	
489	2021-11-09 18:49:36.780439+00	/images/cli.png	200	
490	2021-11-09 18:49:37.608409+00	/	200	
491	2021-11-09 18:49:37.680259+00	/build/bundle.js	200	
492	2021-11-09 18:49:37.688399+00	/build/bundle.css	200	
493	2021-11-09 18:49:37.797718+00	/images/cli.png	200	
494	2021-11-09 18:49:56.832555+00	/playground	200	
495	2021-11-09 18:49:59.585158+00	/playground	304	
496	2021-11-09 18:50:04.88737+00	/playground	304	
497	2021-11-09 18:50:07.046544+00	/rosalind	200	
498	2021-11-09 18:50:07.297081+00	/images/rosalind.png	200	
499	2021-11-09 18:50:13.279607+00	/tutorials	200	?id=awk-intro
500	2021-11-09 18:50:14.524108+00	/data/awk-intro/orders.tsv	200	
501	2021-11-09 18:50:19.795129+00	/tutorials	200	?id=bedtools-intro&step=2
502	2021-11-09 18:50:20.841041+00	/data/bedtools-intro/cpg.bed	200	
503	2021-11-09 18:50:21.008426+00	/data/bedtools-intro/exons.bed	200	
504	2021-11-09 18:50:21.202753+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
505	2021-11-09 18:50:21.370924+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
506	2021-11-09 18:50:21.531259+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
507	2021-11-09 18:50:21.724118+00	/data/bedtools-intro/gwas.bed	200	
508	2021-11-09 18:50:21.934354+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
509	2021-11-09 18:50:22.146418+00	/data/bedtools-intro/genome.txt	200	
510	2021-11-09 18:50:22.870614+00	/api/v1/ping	200	
511	2021-11-09 18:50:27.170856+00	/tutorials	200	
512	2021-11-09 19:09:16.972061+00	/	200	
513	2021-11-09 19:09:17.045156+00	/build/bundle.css	200	
514	2021-11-09 19:09:17.058064+00	/build/bundle.js	200	
515	2021-11-09 19:09:17.318644+00	/images/cli.png	200	
516	2021-11-09 19:09:22.087103+00	/data/awk-intro/orders.tsv	200	
517	2021-11-09 19:09:25.032598+00	/api/v1/ping	200	
518	2021-11-09 19:09:25.162378+00	/api/v1/ping	200	
519	2021-11-09 19:12:59.020291+00	/build/bootstrap.min.css.map	404	
520	2021-11-09 19:12:59.286849+00	/build/bundle.js.map	200	
521	2021-11-09 19:21:46.020281+00	/build/bundle.js.map	200	
522	2021-11-09 19:21:46.088942+00	/build/bootstrap.min.css.map	404	
523	2021-11-09 19:21:48.181342+00	/	304	
524	2021-11-09 19:21:48.301465+00	/build/bundle.js.map	200	
525	2021-11-09 19:21:48.316119+00	/build/bootstrap.min.css.map	404	
526	2021-11-09 19:21:57.397182+00	/	304	
527	2021-11-09 20:26:40.123125+00	/	304	
528	2021-11-09 20:26:40.255512+00	/build/bundle.js.map	200	
529	2021-11-09 20:26:40.374496+00	/build/bootstrap.min.css.map	404	
530	2021-11-10 16:23:16.392667+00	/	200	
531	2021-11-10 16:23:16.649015+00	/build/bundle.css	200	
532	2021-11-10 16:23:16.687344+00	/build/bundle.js	200	
533	2021-11-10 16:23:16.935326+00	/build/bootstrap.min.css.map	404	
534	2021-11-10 16:23:17.128384+00	/images/cli.png	200	
535	2021-11-10 16:23:17.34874+00	/build/bundle.js.map	200	
536	2021-11-11 05:10:58.178013+00	/	304	
537	2021-11-11 05:10:58.275034+00	/build/bundle.js.map	200	
538	2021-11-11 05:10:58.391654+00	/build/bootstrap.min.css.map	404	
539	2021-11-13 00:51:14.237678+00	/	200	
540	2021-11-13 00:51:14.515646+00	/build/bundle.css	200	
541	2021-11-13 00:51:14.698436+00	/build/bundle.js	200	
542	2021-11-13 00:51:14.754886+00	/build/bootstrap.min.css.map	404	
543	2021-11-13 00:51:15.030082+00	/images/cli.png	200	
544	2021-11-13 00:51:15.228421+00	/build/bundle.js.map	200	
545	2021-11-13 00:52:42.019669+00	/	200	
546	2021-11-13 00:52:42.177828+00	/build/bundle.css	200	
547	2021-11-13 00:52:42.190591+00	/build/bundle.js	200	
548	2021-11-13 00:52:42.347663+00	/build/bootstrap.min.css.map	404	
549	2021-11-13 00:52:42.351393+00	/images/cli.png	200	
550	2021-11-13 00:52:42.356356+00	/build/bundle.js.map	200	
551	2021-11-13 01:03:21.30758+00	/	200	
552	2021-11-13 01:03:21.429063+00	/build/bundle.css	200	
553	2021-11-13 01:03:21.436084+00	/build/bundle.js	200	
554	2021-11-13 01:03:21.635241+00	/images/cli.png	200	
555	2021-11-13 01:03:21.648818+00	/build/bootstrap.min.css.map	404	
556	2021-11-13 01:03:21.649277+00	/build/bundle.js.map	200	
557	2021-11-13 01:04:47.186872+00	/	200	
558	2021-11-13 01:04:47.324739+00	/build/bundle.css	200	
559	2021-11-13 01:04:47.339067+00	/build/bundle.js	200	
560	2021-11-13 01:04:47.512284+00	/build/bootstrap.min.css.map	404	
561	2021-11-13 01:04:47.546974+00	/images/cli.png	200	
562	2021-11-13 01:04:47.56081+00	/build/bundle.js.map	200	
563	2021-11-13 01:05:00.561388+00	/	200	
564	2021-11-13 01:05:00.623428+00	/build/bundle.css	200	
565	2021-11-13 01:05:00.637059+00	/build/bundle.js	200	
566	2021-11-13 01:05:00.691665+00	/build/bootstrap.min.css.map	404	
567	2021-11-13 01:05:00.782673+00	/images/cli.png	200	
568	2021-11-13 01:05:00.795798+00	/build/bundle.js.map	200	
569	2021-11-13 01:05:21.289204+00	/	200	
570	2021-11-13 01:05:21.352658+00	/build/bundle.css	200	
571	2021-11-13 01:05:21.365867+00	/build/bundle.js	200	
572	2021-11-13 01:05:21.423046+00	/build/bootstrap.min.css.map	404	
573	2021-11-13 01:05:21.497295+00	/images/cli.png	200	
574	2021-11-13 01:05:21.507027+00	/build/bundle.js.map	200	
575	2021-11-13 01:16:08.989164+00	/tutorials	200	?id=terminal-basics
576	2021-11-13 01:16:09.237859+00	/build/bundle.css	200	
577	2021-11-13 01:16:09.385984+00	/build/bundle.js	200	
578	2021-11-13 01:16:09.481514+00	/build/bootstrap.min.css.map	404	
579	2021-11-13 01:16:10.117556+00	/build/bundle.js.map	200	
580	2021-11-13 01:16:11.57858+00	/data/terminal-basics/orders.tsv	200	
581	2021-11-13 01:16:11.771855+00	/data/terminal-basics/ref.fa	200	
582	2021-11-13 01:16:11.956285+00	/data/terminal-basics/ref.fa.bak	200	
583	2021-11-13 01:21:54.383847+00	/build/bundle.js.map	200	
584	2021-11-13 01:21:56.544026+00	/build/bundle.js.map	200	
585	2021-11-13 01:21:58.465318+00	/build/bundle.js.map	200	
586	2021-11-13 01:22:03.18278+00	/build/bundle.js.map	200	
587	2021-11-13 01:22:51.304473+00	/build/bundle.js.map	404	
588	2021-11-13 01:22:57.896415+00	/data/terminal-basics/orders.tsv	200	
589	2021-11-13 01:22:58.050064+00	/data/terminal-basics/ref.fa	200	
590	2021-11-13 01:22:58.227334+00	/data/terminal-basics/ref.fa.bak	200	
591	2021-11-13 01:23:00.541087+00	/build/bundle.js.map	404	
592	2021-11-13 01:23:00.61246+00	/build/bootstrap.min.css.map	404	
593	2021-11-17 16:04:17.345206+00	/	200	
594	2021-11-17 16:04:17.652544+00	/build/bundle.css	200	
595	2021-11-17 16:04:17.783217+00	/build/bundle.js	200	
596	2021-11-22 20:37:05.222189+00	/	200	
597	2021-11-22 20:37:05.553785+00	/build/bundle.css	200	
598	2021-11-22 20:37:05.594373+00	/build/bundle.js	200	
599	2021-11-23 21:01:59.81457+00	/build/bundle.js	200	
600	2021-11-23 21:01:59.814954+00	/build/bundle.css	200	
601	2021-11-23 21:02:00.293679+00	/images/cli.png	200	
602	2021-11-23 21:02:00.379874+00	/	200	
603	2021-11-23 21:02:02.764339+00	/tutorials	200	?id=awk-intro
604	2021-11-23 21:02:04.961977+00	/data/awk-intro/orders.tsv	200	
605	2021-11-23 21:02:18.416549+00	/api/v1/ping	200	
606	2021-11-23 21:02:38.130582+00	/tutorials	200	?id=awk-intro&step=6
607	2021-11-23 21:02:38.387503+00	/data/awk-intro/orders.tsv	200	
608	2021-11-25 17:42:54.585941+00	/tutorials	200	?id=awk-intro&step=6
609	2021-11-25 17:42:54.76277+00	/build/bundle.css	200	
610	2021-11-25 17:42:54.899256+00	/build/bundle.js	200	
611	2021-11-25 17:42:55.355202+00	/tutorials	304	?id=awk-intro&step=6
612	2021-11-25 17:42:57.902212+00	/data/awk-intro/orders.tsv	200	
613	2021-11-25 18:15:31.679479+00	/tutorials	200	?id=samtools-intro&step=6
614	2021-11-25 18:15:32.04295+00	/build/bootstrap.min.css.map	404	
615	2021-11-25 18:15:32.15223+00	/igv-ui.css.map	404	
616	2021-11-25 18:15:32.161075+00	/igv.css.map	404	
617	2021-11-25 18:15:32.317128+00	/data/samtools-intro/sample.sam	200	
618	2021-11-25 18:15:32.394902+00	/data/samtools-intro/sample.sam	200	
619	2021-11-25 18:16:28.088741+00	/tutorials	200	?id=samtools-intro&step=6
620	2021-11-25 18:16:28.150381+00	/build/bundle.css	200	
621	2021-11-25 18:16:28.240431+00	/build/bootstrap.min.css.map	404	
622	2021-11-25 18:16:28.391849+00	/build/bundle.js	200	
623	2021-11-25 18:16:28.77637+00	/igv-ui.css.map	404	
624	2021-11-25 18:16:28.788822+00	/igv.css.map	404	
625	2021-11-25 18:16:31.79167+00	/data/samtools-intro/sample.bam.bai	200	
626	2021-11-25 18:16:31.863898+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.24t5h9zvjzm
627	2021-11-25 18:16:31.896486+00	/data/samtools-intro/sample.bam	206	?someRandomSeed=0.aoox27fyj99
628	2021-11-25 18:16:31.95591+00	/data/samtools-intro/sample.bam	206	?someRandomSeed=0.tci78n7pvd9
629	2021-11-25 18:16:32.002007+00	/data/samtools-intro/sample.bam	206	?someRandomSeed=0.z7osoxmon3o
630	2022-04-20 02:18:22.510146+00	/tutorials	200	
631	2022-04-20 02:18:42.439123+00	/tutorials	200	
632	2022-04-20 02:18:42.511308+00	/build/bundle.js	200	
633	2022-04-20 02:18:42.51723+00	/build/bundle.css	200	
634	2022-04-20 02:18:46.109429+00	/tutorials	200	
635	2022-04-20 02:18:47.454094+00	/tutorials	200	
636	2022-04-20 02:18:48.181024+00	/tutorials	200	
637	2022-04-20 02:18:48.677271+00	/tutorials	200	
638	2022-04-20 02:18:48.787696+00	/tutorials	200	
639	2022-04-20 02:18:48.868389+00	/tutorials	200	
640	2022-04-20 02:18:48.994046+00	/tutorials	200	
641	2022-04-20 02:18:49.032985+00	/tutorials	200	
642	2022-04-20 02:18:49.105279+00	/tutorials	200	
643	2022-04-20 02:18:49.194886+00	/tutorials	200	
644	2022-04-20 02:18:49.300449+00	/tutorials	200	
645	2022-04-20 02:18:49.400529+00	/tutorials	200	
646	2022-04-20 02:18:49.475799+00	/tutorials	200	
647	2022-04-20 02:18:49.558886+00	/tutorials	200	
648	2022-04-20 02:18:49.638222+00	/tutorials	200	
649	2022-04-20 02:18:49.736318+00	/tutorials	200	
650	2022-04-20 02:18:49.817071+00	/tutorials	200	
651	2022-04-20 02:18:50.599851+00	/tutorials	200	
652	2022-04-20 02:18:51.903879+00	/tutorials	200	
653	2022-04-20 02:18:51.972535+00	/build/bundle.js	200	
654	2022-04-20 02:18:51.986461+00	/build/bundle.css	200	
655	2022-04-20 02:18:52.985792+00	/tutorials	200	
656	2022-04-20 02:18:53.070951+00	/build/bundle.css	200	
657	2022-04-20 02:18:53.358203+00	/build/bundle.js	200	
658	2022-04-20 02:19:00.615069+00	/build/bootstrap.min.css.map	404	
659	2022-04-20 02:19:01.870615+00	/tutorials	304	
660	2022-04-20 02:19:02.077265+00	/build/bootstrap.min.css.map	404	
661	2022-04-20 02:19:22.303072+00	/build/bootstrap.min.css.map	404	
662	2022-04-20 02:19:39.400225+00	/tutorials	304	
663	2022-04-20 02:19:39.478925+00	/build/bootstrap.min.css.map	404	
664	2022-04-20 02:19:43.047405+00	/tutorials	200	?id=fastp-intro
665	2022-04-20 02:19:46.918467+00	/data/fastp-intro/HG004_R1.fastq.gz	200	
666	2022-04-20 02:19:47.21014+00	/data/fastp-intro/HG004_R2.fastq.gz	200	
667	2022-04-20 02:19:47.309655+00	/data/fastp-intro/HG004_R1.fastq.gz	200	
668	2022-04-20 02:19:47.799451+00	/data/fastp-intro/HG004_R2.fastq.gz	200	
669	2022-04-20 02:20:51.675776+00	/api/v1/ping	200	
670	2022-04-20 02:21:02.580432+00	/api/v1/ping	200	
671	2022-04-20 02:21:39.950688+00	/api/v1/ping	200	
672	2022-04-20 02:22:04.703565+00	/api/v1/ping	200	
673	2022-04-20 02:22:27.556917+00	/api/v1/ping	200	
674	2022-04-20 02:22:39.813812+00	/api/v1/ping	200	
675	2022-04-20 02:23:03.662462+00	/api/v1/ping	200	
676	2022-04-20 02:23:39.215003+00	/api/v1/ping	200	
677	2022-04-20 02:23:50.153161+00	/api/v1/ping	200	
678	2022-04-20 02:25:18.259228+00	/api/v1/ping	200	
679	2022-04-20 02:25:41.724578+00	/api/v1/ping	200	
680	2022-04-20 02:25:43.191159+00	/api/v1/ping	200	
681	2022-04-20 04:14:50.769192+00	/tutorials	200	?id=fastp-intro&step=0
682	2022-04-20 04:14:51.422001+00	/data/fastp-intro/HG004_R1.fastq.gz	200	
683	2022-04-20 04:14:51.44494+00	/tutorials	304	?id=fastp-intro&step=0
684	2022-04-20 04:14:51.525489+00	/tutorials	200	?id=fastp-intro&step=0
685	2022-04-20 04:14:51.965269+00	/build/bundle.css	200	
686	2022-04-20 04:14:52.051879+00	/build/bundle.js	200	
687	2022-04-20 04:14:52.773734+00	/data/fastp-intro/HG004_R1.fastq.gz	200	
688	2022-04-20 04:16:03.35532+00	/api/v1/ping	200	
689	2022-04-20 04:17:54.095778+00	/api/v1/ping	200	
690	2022-04-20 04:20:53.99942+00	/api/v1/ping	200	
691	2022-04-20 04:22:05.238543+00	/api/v1/ping	200	
692	2022-04-20 04:22:46.642712+00	/tutorials	200	?id=jq-intro
693	2022-04-20 04:22:47.299678+00	/data/jq-intro/repo.json	200	
694	2022-04-20 04:22:47.355915+00	/data/jq-intro/repo.json	200	
695	2022-04-20 04:22:47.613811+00	/data/jq-intro/issues.json	200	
696	2022-04-20 04:22:47.673927+00	/data/jq-intro/issues.json	200	
697	2022-04-20 04:22:47.989013+00	/data/jq-intro/issue.json	200	
698	2022-04-20 04:22:48.100926+00	/data/jq-intro/issue.json	200	
699	2022-04-20 04:22:56.49753+00	/api/v1/ping	200	
700	2022-04-20 04:23:25.536504+00	/api/v1/ping	200	
701	2022-04-20 04:23:27.7233+00	/api/v1/ping	200	
702	2022-04-20 04:23:30.908908+00	/api/v1/ping	200	
703	2022-04-20 04:24:09.889737+00	/api/v1/ping	200	
704	2022-04-20 04:28:25.404013+00	/api/v1/ping	200	
705	2022-04-20 04:32:35.575897+00	/api/v1/ping	200	
706	2022-04-20 04:33:13.53672+00	/api/v1/ping	200	
707	2022-04-20 04:33:45.718914+00	/api/v1/ping	200	
708	2022-07-20 05:45:53.742988+00	/playgrounds	200	?id=awk
709	2022-07-20 05:49:05.62945+00	/playgrounds	200	?id=awk
710	2022-07-31 00:26:24.947824+00	/tutorials	200	
711	2022-07-31 00:26:51.681175+00	/tutorials	304	
712	2022-07-31 00:26:55.847343+00	/tutorials	200	
\.


--
-- Data for Name: pings; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY "public"."pings" ("id", "time", "ip", "step_from", "step_to", "tutorial", "example", "playground") FROM stdin;
1	2021-08-25 15:00:39.582616+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	0	1	samtools-intro	\N	\N
2	2021-08-25 15:00:39.954912+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	1	2	samtools-intro	\N	\N
3	2021-08-25 15:00:40.412647+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	2	3	samtools-intro	\N	\N
4	2021-08-25 15:00:40.611233+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	3	4	samtools-intro	\N	\N
5	2021-08-25 15:00:40.78563+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	4	5	samtools-intro	\N	\N
6	2021-08-25 15:00:41.195593+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	5	6	samtools-intro	\N	\N
7	2021-08-31 17:35:25.688888+00	44e601c784e0465c2a1c09f135ebac86	0	5	bowtie2-intro	\N	\N
8	2021-08-31 17:35:27.288408+00	44e601c784e0465c2a1c09f135ebac86	5	6	bowtie2-intro	\N	\N
9	2021-08-31 17:35:28.023586+00	44e601c784e0465c2a1c09f135ebac86	6	5	bowtie2-intro	\N	\N
10	2021-08-31 17:35:28.248697+00	44e601c784e0465c2a1c09f135ebac86	5	4	bowtie2-intro	\N	\N
11	2021-08-31 17:35:28.683278+00	44e601c784e0465c2a1c09f135ebac86	4	5	bowtie2-intro	\N	\N
12	2021-08-31 17:35:30.529674+00	44e601c784e0465c2a1c09f135ebac86	0	1	samtools-intro	\N	\N
13	2021-08-31 17:35:30.702399+00	44e601c784e0465c2a1c09f135ebac86	1	2	samtools-intro	\N	\N
14	2021-08-31 17:35:30.874424+00	44e601c784e0465c2a1c09f135ebac86	2	3	samtools-intro	\N	\N
15	2021-08-31 17:35:31.051646+00	44e601c784e0465c2a1c09f135ebac86	3	4	samtools-intro	\N	\N
16	2021-08-31 17:35:31.2211+00	44e601c784e0465c2a1c09f135ebac86	4	5	samtools-intro	\N	\N
17	2021-08-31 17:35:31.599345+00	44e601c784e0465c2a1c09f135ebac86	5	6	samtools-intro	\N	\N
18	2021-09-07 20:25:01.922482+00	f138e95352445fd8529580ed7af2532f	0	1	terminal-basics	\N	\N
19	2021-09-07 20:32:04.90319+00	f138e95352445fd8529580ed7af2532f	0	1	terminal-basics	\N	\N
20	2021-09-07 20:32:05.053781+00	f138e95352445fd8529580ed7af2532f	1	2	terminal-basics	\N	\N
21	2021-09-07 20:32:05.190979+00	f138e95352445fd8529580ed7af2532f	2	3	terminal-basics	\N	\N
22	2021-09-08 00:09:23.63357+00	f138e95352445fd8529580ed7af2532f	0	8	jq-intro	\N	\N
23	2021-09-08 00:11:13.386657+00	f138e95352445fd8529580ed7af2532f	8	9	jq-intro	\N	\N
24	2021-09-08 00:11:34.291887+00	f138e95352445fd8529580ed7af2532f	3	4	terminal-basics	\N	\N
25	2021-09-08 00:11:34.475964+00	f138e95352445fd8529580ed7af2532f	4	5	terminal-basics	\N	\N
26	2021-09-08 00:11:34.692027+00	f138e95352445fd8529580ed7af2532f	5	6	terminal-basics	\N	\N
27	2021-09-08 00:11:34.869609+00	f138e95352445fd8529580ed7af2532f	6	7	terminal-basics	\N	\N
28	2021-09-24 22:46:49.722703+00	073e4edfd893e8857d6c61ff6ef76b93	0	1	rosalind	\N	\N
29	2021-09-24 22:46:54.585243+00	073e4edfd893e8857d6c61ff6ef76b93	1	2	rosalind	\N	\N
30	2021-09-24 22:47:03.505408+00	073e4edfd893e8857d6c61ff6ef76b93	2	1	rosalind	\N	\N
31	2021-09-24 22:47:04.036377+00	073e4edfd893e8857d6c61ff6ef76b93	1	2	rosalind	\N	\N
32	2021-09-24 22:47:04.450891+00	073e4edfd893e8857d6c61ff6ef76b93	2	1	rosalind	\N	\N
33	2021-09-24 22:47:04.910933+00	073e4edfd893e8857d6c61ff6ef76b93	1	0	rosalind	\N	\N
34	2021-09-24 22:47:05.450654+00	073e4edfd893e8857d6c61ff6ef76b93	0	1	rosalind	\N	\N
35	2021-09-24 22:47:05.598864+00	073e4edfd893e8857d6c61ff6ef76b93	1	2	rosalind	\N	\N
36	2021-09-25 02:04:32.331098+00	073e4edfd893e8857d6c61ff6ef76b93	0	1	rosalind	\N	\N
37	2021-09-25 02:04:33.014805+00	073e4edfd893e8857d6c61ff6ef76b93	1	2	rosalind	\N	\N
38	2021-09-25 02:04:34.746625+00	073e4edfd893e8857d6c61ff6ef76b93	2	3	rosalind	\N	\N
39	2021-09-25 04:02:52.904153+00	4208e869962ee1b570b6d179426e8af9	0	1	rosalind	\N	\N
40	2021-09-25 04:02:54.046021+00	4208e869962ee1b570b6d179426e8af9	1	0	rosalind	\N	\N
41	2021-09-25 04:03:57.272216+00	4208e869962ee1b570b6d179426e8af9	0	1	rosalind	\N	\N
42	2021-09-25 04:10:42.388687+00	073e4edfd893e8857d6c61ff6ef76b93	1	0	rosalind	\N	\N
43	2021-09-25 04:10:50.356935+00	073e4edfd893e8857d6c61ff6ef76b93	0	1	rosalind	\N	\N
44	2021-09-25 04:10:52.135931+00	073e4edfd893e8857d6c61ff6ef76b93	1	2	rosalind	\N	\N
45	2021-09-25 04:10:52.964218+00	073e4edfd893e8857d6c61ff6ef76b93	2	1	rosalind	\N	\N
46	2021-09-25 04:10:53.788071+00	073e4edfd893e8857d6c61ff6ef76b93	1	0	rosalind	\N	\N
47	2021-09-25 04:10:58.400139+00	073e4edfd893e8857d6c61ff6ef76b93	0	1	rosalind	\N	\N
48	2021-09-25 04:11:24.958536+00	073e4edfd893e8857d6c61ff6ef76b93	0	1	rosalind	\N	\N
49	2021-09-25 04:11:26.052122+00	073e4edfd893e8857d6c61ff6ef76b93	1	2	rosalind	\N	\N
50	2021-09-25 04:11:27.34132+00	073e4edfd893e8857d6c61ff6ef76b93	2	1	rosalind	\N	\N
51	2021-09-25 04:11:53.681686+00	073e4edfd893e8857d6c61ff6ef76b93	1	2	rosalind	\N	\N
52	2021-09-25 04:13:11.122646+00	073e4edfd893e8857d6c61ff6ef76b93	2	3	rosalind	\N	\N
53	2021-09-25 04:14:37.923721+00	073e4edfd893e8857d6c61ff6ef76b93	3	4	rosalind	\N	\N
54	2021-10-07 04:11:28.358932+00	3f9a34908e7eda007b38cbe0febf769a	0	1	awk-intro	\N	\N
55	2021-10-07 04:11:33.874065+00	3f9a34908e7eda007b38cbe0febf769a	1	2	awk-intro	\N	\N
56	2021-10-07 04:11:34.036641+00	3f9a34908e7eda007b38cbe0febf769a	2	3	awk-intro	\N	\N
57	2021-10-07 13:23:34.730963+00	3f9a34908e7eda007b38cbe0febf769a	0	1	awk-intro	\N	\N
58	2021-10-07 13:24:29.3093+00	3f9a34908e7eda007b38cbe0febf769a	1	2	awk-intro	\N	\N
59	2021-10-07 13:25:02.586468+00	3f9a34908e7eda007b38cbe0febf769a	2	3	awk-intro	\N	\N
60	2021-10-07 13:26:45.601943+00	3f9a34908e7eda007b38cbe0febf769a	3	4	awk-intro	\N	\N
61	2021-10-07 13:28:33.221722+00	3f9a34908e7eda007b38cbe0febf769a	4	5	awk-intro	\N	\N
62	2021-10-07 13:29:12.585683+00	4208e869962ee1b570b6d179426e8af9	5	6	awk-intro	\N	\N
63	2021-10-07 13:31:41.737134+00	4208e869962ee1b570b6d179426e8af9	6	7	awk-intro	\N	\N
64	2021-10-07 13:35:04.711847+00	3f9a34908e7eda007b38cbe0febf769a	7	8	awk-intro	\N	\N
65	2021-10-07 13:37:47.35423+00	3f9a34908e7eda007b38cbe0febf769a	8	9	awk-intro	\N	\N
66	2021-10-07 13:38:50.039058+00	3f9a34908e7eda007b38cbe0febf769a	9	10	awk-intro	\N	\N
67	2021-10-07 14:01:25.646826+00	3f9a34908e7eda007b38cbe0febf769a	0	1	awk-intro	\N	\N
68	2021-10-07 14:01:31.591982+00	3f9a34908e7eda007b38cbe0febf769a	1	2	awk-intro	\N	\N
69	2021-10-07 14:01:40.455544+00	3f9a34908e7eda007b38cbe0febf769a	2	3	awk-intro	\N	\N
70	2021-10-07 14:02:05.031888+00	3f9a34908e7eda007b38cbe0febf769a	3	2	awk-intro	\N	\N
71	2021-10-07 14:02:05.862891+00	3f9a34908e7eda007b38cbe0febf769a	2	1	awk-intro	\N	\N
72	2021-10-07 14:02:09.993727+00	3f9a34908e7eda007b38cbe0febf769a	1	2	awk-intro	\N	\N
73	2021-10-07 14:02:14.930379+00	3f9a34908e7eda007b38cbe0febf769a	2	3	awk-intro	\N	\N
74	2021-10-07 14:03:19.599042+00	4208e869962ee1b570b6d179426e8af9	3	4	awk-intro	\N	\N
75	2021-10-07 14:03:38.629139+00	4208e869962ee1b570b6d179426e8af9	4	3	awk-intro	\N	\N
76	2021-10-07 14:03:38.955689+00	4208e869962ee1b570b6d179426e8af9	3	2	awk-intro	\N	\N
77	2021-10-07 14:03:41.708368+00	4208e869962ee1b570b6d179426e8af9	2	1	awk-intro	\N	\N
78	2021-10-07 20:07:49.615652+00	3f9a34908e7eda007b38cbe0febf769a	0	4	awk-intro	\N	\N
79	2021-10-07 20:07:54.337768+00	3f9a34908e7eda007b38cbe0febf769a	4	5	awk-intro	\N	\N
80	2021-10-08 01:11:39.833465+00	e6c46c373aaac40a48a9b887cfcadeda	0	1	awk-intro	\N	\N
81	2021-10-08 01:17:22.320871+00	e6c46c373aaac40a48a9b887cfcadeda	1	2	awk-intro	\N	\N
82	2021-10-08 01:18:10.122152+00	e6c46c373aaac40a48a9b887cfcadeda	2	3	awk-intro	\N	\N
83	2021-10-08 01:20:05.250909+00	e6c46c373aaac40a48a9b887cfcadeda	3	4	awk-intro	\N	\N
84	2021-10-08 01:24:14.564564+00	4208e869962ee1b570b6d179426e8af9	4	5	awk-intro	\N	\N
85	2021-10-08 01:30:21.177319+00	e6c46c373aaac40a48a9b887cfcadeda	5	6	awk-intro	\N	\N
86	2021-10-08 01:34:21.008012+00	e6c46c373aaac40a48a9b887cfcadeda	6	7	awk-intro	\N	\N
87	2021-10-08 01:38:49.870141+00	e6c46c373aaac40a48a9b887cfcadeda	7	8	awk-intro	\N	\N
88	2021-10-08 01:45:43.296298+00	e6c46c373aaac40a48a9b887cfcadeda	8	9	awk-intro	\N	\N
89	2021-10-08 01:46:21.655638+00	e6c46c373aaac40a48a9b887cfcadeda	9	10	awk-intro	\N	\N
90	2021-10-08 02:54:48.147963+00	e6c46c373aaac40a48a9b887cfcadeda	10	9	awk-intro	\N	\N
91	2021-10-08 02:54:52.675682+00	e6c46c373aaac40a48a9b887cfcadeda	9	0	awk-intro	\N	\N
92	2021-10-08 02:54:56.856205+00	e6c46c373aaac40a48a9b887cfcadeda	0	1	awk-intro	\N	\N
93	2021-10-08 02:55:12.711933+00	e6c46c373aaac40a48a9b887cfcadeda	1	2	awk-intro	\N	\N
94	2021-10-08 02:55:34.538836+00	e6c46c373aaac40a48a9b887cfcadeda	2	3	awk-intro	\N	\N
95	2021-10-08 02:55:35.145651+00	e6c46c373aaac40a48a9b887cfcadeda	3	4	awk-intro	\N	\N
96	2021-10-08 02:55:35.788682+00	e6c46c373aaac40a48a9b887cfcadeda	4	5	awk-intro	\N	\N
97	2021-10-08 02:55:36.464017+00	e6c46c373aaac40a48a9b887cfcadeda	5	6	awk-intro	\N	\N
98	2021-10-08 02:58:45.053249+00	e6c46c373aaac40a48a9b887cfcadeda	6	7	awk-intro	\N	\N
99	2021-10-08 02:58:46.929504+00	e6c46c373aaac40a48a9b887cfcadeda	7	8	awk-intro	\N	\N
100	2021-10-08 02:58:48.203532+00	e6c46c373aaac40a48a9b887cfcadeda	8	9	awk-intro	\N	\N
101	2021-10-08 02:58:49.363224+00	e6c46c373aaac40a48a9b887cfcadeda	9	10	awk-intro	\N	\N
102	2021-10-08 03:02:37.372603+00	e6c46c373aaac40a48a9b887cfcadeda	10	0	awk-intro	\N	\N
103	2021-10-08 03:03:45.741527+00	e6c46c373aaac40a48a9b887cfcadeda	0	1	bedtools-intro	\N	\N
104	2021-10-08 03:03:53.369964+00	e6c46c373aaac40a48a9b887cfcadeda	1	2	bedtools-intro	\N	\N
105	2021-11-09 18:50:22.83762+00	293eee74aea46f695f5fb8cf3d0c7d0b	2	3	bedtools-intro	\N	\N
106	2021-11-09 19:09:24.995774+00	293eee74aea46f695f5fb8cf3d0c7d0b	0	1	awk-intro	\N	\N
107	2021-11-09 19:09:25.134594+00	293eee74aea46f695f5fb8cf3d0c7d0b	1	2	awk-intro	\N	\N
108	2021-11-23 21:02:18.345348+00	dccd71a2038bdfdf5ad0f23d62882f4e	0	6	awk-intro	\N	\N
109	2022-04-20 02:20:51.437183+00	55d9c1934d21c2d42af0d5b0f51ebf7c	0	1	fastp-intro	\N	\N
110	2022-04-20 02:21:02.473396+00	55d9c1934d21c2d42af0d5b0f51ebf7c	1	2	fastp-intro	\N	\N
111	2022-04-20 02:21:39.867206+00	55d9c1934d21c2d42af0d5b0f51ebf7c	2	3	fastp-intro	\N	\N
112	2022-04-20 02:22:04.514305+00	55d9c1934d21c2d42af0d5b0f51ebf7c	3	4	fastp-intro	\N	\N
113	2022-04-20 02:22:27.371113+00	55d9c1934d21c2d42af0d5b0f51ebf7c	4	5	fastp-intro	\N	\N
114	2022-04-20 02:22:39.736608+00	55d9c1934d21c2d42af0d5b0f51ebf7c	5	6	fastp-intro	\N	\N
115	2022-04-20 02:23:03.484052+00	55d9c1934d21c2d42af0d5b0f51ebf7c	6	7	fastp-intro	\N	\N
116	2022-04-20 02:23:38.946189+00	55d9c1934d21c2d42af0d5b0f51ebf7c	7	8	fastp-intro	\N	\N
117	2022-04-20 02:23:50.055228+00	55d9c1934d21c2d42af0d5b0f51ebf7c	8	9	fastp-intro	\N	\N
118	2022-04-20 02:25:17.98235+00	55d9c1934d21c2d42af0d5b0f51ebf7c	9	0	fastp-intro	\N	\N
119	2022-04-20 02:25:41.454769+00	55d9c1934d21c2d42af0d5b0f51ebf7c	0	8	fastp-intro	\N	\N
120	2022-04-20 02:25:43.085732+00	55d9c1934d21c2d42af0d5b0f51ebf7c	8	0	fastp-intro	\N	\N
121	2022-04-20 04:16:03.285166+00	55d9c1934d21c2d42af0d5b0f51ebf7c	0	1	fastp-intro	\N	\N
122	2022-04-20 04:17:54.046275+00	55d9c1934d21c2d42af0d5b0f51ebf7c	1	2	fastp-intro	\N	\N
123	2022-04-20 04:20:53.946313+00	55d9c1934d21c2d42af0d5b0f51ebf7c	2	3	fastp-intro	\N	\N
124	2022-04-20 04:22:05.19685+00	55d9c1934d21c2d42af0d5b0f51ebf7c	3	4	fastp-intro	\N	\N
125	2022-04-20 04:22:56.438465+00	55d9c1934d21c2d42af0d5b0f51ebf7c	4	5	fastp-intro	\N	\N
126	2022-04-20 04:23:25.488886+00	55d9c1934d21c2d42af0d5b0f51ebf7c	5	6	fastp-intro	\N	\N
127	2022-04-20 04:23:27.670088+00	55d9c1934d21c2d42af0d5b0f51ebf7c	6	5	fastp-intro	\N	\N
128	2022-04-20 04:23:30.884014+00	55d9c1934d21c2d42af0d5b0f51ebf7c	5	6	fastp-intro	\N	\N
129	2022-04-20 04:24:09.843475+00	55d9c1934d21c2d42af0d5b0f51ebf7c	6	7	fastp-intro	\N	\N
130	2022-04-20 04:28:25.337743+00	a179ed91e136780066d833a3c1089527	7	8	fastp-intro	\N	\N
131	2022-04-20 04:32:35.493982+00	55d9c1934d21c2d42af0d5b0f51ebf7c	8	9	fastp-intro	\N	\N
132	2022-04-20 04:33:13.487862+00	55d9c1934d21c2d42af0d5b0f51ebf7c	9	8	fastp-intro	\N	\N
133	2022-04-20 04:33:45.650537+00	55d9c1934d21c2d42af0d5b0f51ebf7c	8	7	fastp-intro	\N	\N
135	2022-07-20 05:49:06.170841+00	1d0daa6952bd196092d92be35393a7eb	\N	\N	\N	t	awk
136	2022-07-20 05:49:19.965754+00	1d0daa6952bd196092d92be35393a7eb	\N	\N	\N	f	awk
137	2022-07-20 05:49:20.21595+00	1d0daa6952bd196092d92be35393a7eb	\N	\N	\N	f	awk
138	2022-07-20 05:49:20.323368+00	1d0daa6952bd196092d92be35393a7eb	\N	\N	\N	f	awk
139	2022-07-20 05:49:20.48481+00	1d0daa6952bd196092d92be35393a7eb	\N	\N	\N	f	awk
140	2022-07-20 05:49:20.573106+00	1d0daa6952bd196092d92be35393a7eb	\N	\N	\N	f	awk
\.


--
-- Data for Name: state; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY "public"."state" ("id", "user_id", "env", "progress") FROM stdin;
2	554c1cb5-aba2-4ce0-bdfd-70835fd85aca	\N	{"jq-intro": {"step": 9}, "terminal-basics": {"step": 7}}
3	0c781f47-3894-4762-9ea9-5cad2715fa6c	{"PS1": "\\\\u@\\\\h$ ", "HOME": "/shared/data", "USER": "robert"}	{"awk-intro": {"step": 10}, "fastp-intro": {"step": 9}, "bedtools-intro": {"step": 3}}
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."schema_migrations" ("version", "inserted_at") FROM stdin;
20211116024918	2021-12-01 08:07:37
20211116045059	2021-12-01 08:07:37
20211116050929	2021-12-01 08:07:37
20211116051442	2021-12-01 08:07:37
20211116212300	2021-12-01 08:07:37
20211116213355	2021-12-01 08:07:37
20211116213934	2021-12-01 08:07:37
20211116214523	2021-12-01 08:07:37
20211122062447	2021-12-01 08:07:37
20211124070109	2021-12-01 08:07:37
20211202204204	2021-12-04 07:37:48
20211202204605	2021-12-04 07:37:48
20211210212804	2022-04-20 02:18:17
20211228014915	2022-04-20 02:18:17
20220107221237	2022-04-20 02:18:17
20220228202821	2022-04-20 02:18:17
20220312004840	2022-04-20 02:18:17
20220603231003	2022-07-20 05:36:29
20220603232444	2022-07-20 05:36:29
20220615214548	2022-07-20 05:36:29
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."subscription" ("id", "subscription_id", "entity", "filters", "claims", "created_at") FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public") FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."migrations" ("id", "name", "hash", "executed_at") FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2021-08-20 21:28:01.3096
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2021-08-20 21:28:01.312738
2	pathtoken-column	49756be03be4c17bb85fe70d4a861f27de7e49ad	2021-08-20 21:28:01.315377
3	add-migrations-rls	bb5d124c53d68635a883e399426c6a5a25fc893d	2021-08-20 21:28:01.423871
4	add-size-functions	6d79007d04f5acd288c9c250c42d2d5fd286c54d	2021-08-20 21:28:01.426756
5	change-column-name-in-get-size	fd65688505d2ffa9fbdc58a944348dd8604d688c	2021-08-20 21:28:01.429857
6	add-rls-to-buckets	63e2bab75a2040fee8e3fb3f15a0d26f3380e9b6	2021-08-20 21:28:01.432846
7	add-public-to-buckets	82568934f8a4d9e0a85f126f6fb483ad8214c418	2021-08-20 21:28:01.435873
8	fix-search-function	1a43a40eddb525f2e2f26efd709e6c06e58e059c	2021-12-01 08:07:42.8405
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."objects" ("id", "bucket_id", "name", "owner", "created_at", "updated_at", "last_accessed_at", "metadata") FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('"auth"."refresh_tokens_id_seq"', 43, true);


--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: supabase_admin
--

SELECT pg_catalog.setval('"public"."logs_id_seq"', 712, true);


--
-- Name: pings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: supabase_admin
--

SELECT pg_catalog.setval('"public"."pings_id_seq"', 140, true);


--
-- Name: state_env_id_seq; Type: SEQUENCE SET; Schema: public; Owner: supabase_admin
--

SELECT pg_catalog.setval('"public"."state_env_id_seq"', 3, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_admin
--

SELECT pg_catalog.setval('"realtime"."subscription_id_seq"', 1, false);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."audit_log_entries"
    ADD CONSTRAINT "audit_log_entries_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_pkey" PRIMARY KEY ("provider", "id");


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."instances"
    ADD CONSTRAINT "instances_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_token_unique" UNIQUE ("token");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_email_key" UNIQUE ("email");


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_phone_key" UNIQUE ("phone");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");


--
-- Name: logs logs_pkey; Type: CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY "public"."logs"
    ADD CONSTRAINT "logs_pkey" PRIMARY KEY ("id");


--
-- Name: pings pings_pkey; Type: CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY "public"."pings"
    ADD CONSTRAINT "pings_pkey" PRIMARY KEY ("id");


--
-- Name: state state_env_pkey; Type: CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY "public"."state"
    ADD CONSTRAINT "state_env_pkey" PRIMARY KEY ("id");


--
-- Name: state unique_user_id; Type: CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY "public"."state"
    ADD CONSTRAINT "unique_user_id" UNIQUE ("user_id");


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."subscription"
    ADD CONSTRAINT "pk_subscription" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets"
    ADD CONSTRAINT "buckets_pkey" PRIMARY KEY ("id");


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_name_key" UNIQUE ("name");


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_pkey" PRIMARY KEY ("id");


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_pkey" PRIMARY KEY ("id");


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "audit_logs_instance_id_idx" ON "auth"."audit_log_entries" USING "btree" ("instance_id");


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "confirmation_token_idx" ON "auth"."users" USING "btree" ("confirmation_token") WHERE (("confirmation_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_current_idx" ON "auth"."users" USING "btree" ("email_change_token_current") WHERE (("email_change_token_current")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_new_idx" ON "auth"."users" USING "btree" ("email_change_token_new") WHERE (("email_change_token_new")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_user_id_idx" ON "auth"."identities" USING "btree" ("user_id");


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "reauthentication_token_idx" ON "auth"."users" USING "btree" ("reauthentication_token") WHERE (("reauthentication_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "recovery_token_idx" ON "auth"."users" USING "btree" ("recovery_token") WHERE (("recovery_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id");


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_user_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id", "user_id");


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_parent_idx" ON "auth"."refresh_tokens" USING "btree" ("parent");


--
-- Name: refresh_tokens_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_token_idx" ON "auth"."refresh_tokens" USING "btree" ("token");


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_email_idx" ON "auth"."users" USING "btree" ("instance_id", "lower"(("email")::"text"));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_idx" ON "auth"."users" USING "btree" ("instance_id");


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "ix_realtime_subscription_entity" ON "realtime"."subscription" USING "hash" ("entity");


--
-- Name: subscription_subscription_id_entity_filters_key; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX "subscription_subscription_id_entity_filters_key" ON "realtime"."subscription" USING "btree" ("subscription_id", "entity", "filters");


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bname" ON "storage"."buckets" USING "btree" ("name");


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bucketid_objname" ON "storage"."objects" USING "btree" ("bucket_id", "name");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "name_prefix_search" ON "storage"."objects" USING "btree" ("name" "text_pattern_ops");


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_admin
--

CREATE TRIGGER "tr_check_filters" BEFORE INSERT OR UPDATE ON "realtime"."subscription" FOR EACH ROW EXECUTE FUNCTION "realtime"."subscription_check_filters"();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_parent_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_parent_fkey" FOREIGN KEY ("parent") REFERENCES "auth"."refresh_tokens"("token");


--
-- Name: state state_env_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY "public"."state"
    ADD CONSTRAINT "state_env_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id");


--
-- Name: buckets buckets_owner_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets"
    ADD CONSTRAINT "buckets_owner_fkey" FOREIGN KEY ("owner") REFERENCES "auth"."users"("id");


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: objects objects_owner_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_owner_fkey" FOREIGN KEY ("owner") REFERENCES "auth"."users"("id");


--
-- Name: state INSERT; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY "INSERT" ON "public"."state" FOR INSERT WITH CHECK (("auth"."uid"() = "user_id"));


--
-- Name: state SELECT; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY "SELECT" ON "public"."state" FOR SELECT USING (("auth"."uid"() = "user_id"));


--
-- Name: state UPDATE; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY "UPDATE" ON "public"."state" FOR UPDATE USING (("auth"."uid"() = "user_id")) WITH CHECK (("auth"."uid"() = "user_id"));


--
-- Name: logs; Type: ROW SECURITY; Schema: public; Owner: supabase_admin
--

ALTER TABLE "public"."logs" ENABLE ROW LEVEL SECURITY;

--
-- Name: pings; Type: ROW SECURITY; Schema: public; Owner: supabase_admin
--

ALTER TABLE "public"."pings" ENABLE ROW LEVEL SECURITY;

--
-- Name: state; Type: ROW SECURITY; Schema: public; Owner: supabase_admin
--

ALTER TABLE "public"."state" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets" ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."objects" ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION "supabase_realtime" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";

--
-- Name: SCHEMA "auth"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "auth" TO "anon";
GRANT USAGE ON SCHEMA "auth" TO "authenticated";
GRANT USAGE ON SCHEMA "auth" TO "service_role";
GRANT ALL ON SCHEMA "auth" TO "supabase_auth_admin";
GRANT ALL ON SCHEMA "auth" TO "dashboard_user";
GRANT ALL ON SCHEMA "auth" TO "postgres";


--
-- Name: SCHEMA "extensions"; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA "extensions" TO "anon";
GRANT USAGE ON SCHEMA "extensions" TO "authenticated";
GRANT USAGE ON SCHEMA "extensions" TO "service_role";
GRANT ALL ON SCHEMA "extensions" TO "dashboard_user";


--
-- Name: SCHEMA "graphql_public"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "graphql_public" TO "postgres";
GRANT USAGE ON SCHEMA "graphql_public" TO "anon";
GRANT USAGE ON SCHEMA "graphql_public" TO "authenticated";
GRANT USAGE ON SCHEMA "graphql_public" TO "service_role";


--
-- Name: SCHEMA "public"; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";


--
-- Name: SCHEMA "realtime"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "realtime" TO "postgres";


--
-- Name: SCHEMA "storage"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT ALL ON SCHEMA "storage" TO "postgres";
GRANT USAGE ON SCHEMA "storage" TO "anon";
GRANT USAGE ON SCHEMA "storage" TO "authenticated";
GRANT USAGE ON SCHEMA "storage" TO "service_role";
GRANT ALL ON SCHEMA "storage" TO "supabase_storage_admin";
GRANT ALL ON SCHEMA "storage" TO "dashboard_user";


--
-- Name: FUNCTION "email"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."email"() TO "postgres";
GRANT ALL ON FUNCTION "auth"."email"() TO "dashboard_user";


--
-- Name: FUNCTION "jwt"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."jwt"() TO "postgres";
GRANT ALL ON FUNCTION "auth"."jwt"() TO "dashboard_user";


--
-- Name: FUNCTION "role"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."role"() TO "postgres";
GRANT ALL ON FUNCTION "auth"."role"() TO "dashboard_user";


--
-- Name: FUNCTION "uid"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."uid"() TO "postgres";
GRANT ALL ON FUNCTION "auth"."uid"() TO "dashboard_user";


--
-- Name: FUNCTION "get_built_schema_version"(); Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql"."get_built_schema_version"() TO "postgres";
GRANT ALL ON FUNCTION "graphql"."get_built_schema_version"() TO "anon";
GRANT ALL ON FUNCTION "graphql"."get_built_schema_version"() TO "authenticated";
GRANT ALL ON FUNCTION "graphql"."get_built_schema_version"() TO "service_role";


--
-- Name: FUNCTION "rebuild_on_ddl"(); Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql"."rebuild_on_ddl"() TO "postgres";
GRANT ALL ON FUNCTION "graphql"."rebuild_on_ddl"() TO "anon";
GRANT ALL ON FUNCTION "graphql"."rebuild_on_ddl"() TO "authenticated";
GRANT ALL ON FUNCTION "graphql"."rebuild_on_ddl"() TO "service_role";


--
-- Name: FUNCTION "rebuild_on_drop"(); Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql"."rebuild_on_drop"() TO "postgres";
GRANT ALL ON FUNCTION "graphql"."rebuild_on_drop"() TO "anon";
GRANT ALL ON FUNCTION "graphql"."rebuild_on_drop"() TO "authenticated";
GRANT ALL ON FUNCTION "graphql"."rebuild_on_drop"() TO "service_role";


--
-- Name: FUNCTION "rebuild_schema"(); Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql"."rebuild_schema"() TO "postgres";
GRANT ALL ON FUNCTION "graphql"."rebuild_schema"() TO "anon";
GRANT ALL ON FUNCTION "graphql"."rebuild_schema"() TO "authenticated";
GRANT ALL ON FUNCTION "graphql"."rebuild_schema"() TO "service_role";


--
-- Name: FUNCTION "variable_definitions_sort"("variable_definitions" "jsonb"); Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql"."variable_definitions_sort"("variable_definitions" "jsonb") TO "postgres";
GRANT ALL ON FUNCTION "graphql"."variable_definitions_sort"("variable_definitions" "jsonb") TO "anon";
GRANT ALL ON FUNCTION "graphql"."variable_definitions_sort"("variable_definitions" "jsonb") TO "authenticated";
GRANT ALL ON FUNCTION "graphql"."variable_definitions_sort"("variable_definitions" "jsonb") TO "service_role";


--
-- Name: FUNCTION "graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb"); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "postgres";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "anon";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "authenticated";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "service_role";


--
-- Name: FUNCTION "get_auth"("p_usename" "text"); Type: ACL; Schema: pgbouncer; Owner: postgres
--

REVOKE ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") TO "pgbouncer";


--
-- Name: FUNCTION "apply_rls"("wal" "jsonb", "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "dashboard_user";


--
-- Name: FUNCTION "cast"("val" "text", "type_" "regtype"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "dashboard_user";


--
-- Name: FUNCTION "check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "dashboard_user";


--
-- Name: FUNCTION "is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "dashboard_user";


--
-- Name: FUNCTION "quote_wal2json"("entity" "regclass"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "dashboard_user";


--
-- Name: FUNCTION "subscription_check_filters"(); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "dashboard_user";


--
-- Name: FUNCTION "to_regrole"("role_name" "text"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "extension"("name" "text"); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION "storage"."extension"("name" "text") TO "anon";
GRANT ALL ON FUNCTION "storage"."extension"("name" "text") TO "authenticated";
GRANT ALL ON FUNCTION "storage"."extension"("name" "text") TO "service_role";


--
-- Name: FUNCTION "filename"("name" "text"); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION "storage"."filename"("name" "text") TO "anon";
GRANT ALL ON FUNCTION "storage"."filename"("name" "text") TO "authenticated";
GRANT ALL ON FUNCTION "storage"."filename"("name" "text") TO "service_role";


--
-- Name: FUNCTION "foldername"("name" "text"); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION "storage"."foldername"("name" "text") TO "anon";
GRANT ALL ON FUNCTION "storage"."foldername"("name" "text") TO "authenticated";
GRANT ALL ON FUNCTION "storage"."foldername"("name" "text") TO "service_role";


--
-- Name: FUNCTION "search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer) TO "anon";
GRANT ALL ON FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer) TO "authenticated";
GRANT ALL ON FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer) TO "service_role";


--
-- Name: TABLE "audit_log_entries"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."audit_log_entries" TO "dashboard_user";
GRANT ALL ON TABLE "auth"."audit_log_entries" TO "postgres";


--
-- Name: TABLE "identities"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."identities" TO "postgres";
GRANT ALL ON TABLE "auth"."identities" TO "dashboard_user";


--
-- Name: TABLE "instances"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."instances" TO "dashboard_user";
GRANT ALL ON TABLE "auth"."instances" TO "postgres";


--
-- Name: TABLE "refresh_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."refresh_tokens" TO "dashboard_user";
GRANT ALL ON TABLE "auth"."refresh_tokens" TO "postgres";


--
-- Name: SEQUENCE "refresh_tokens_id_seq"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "postgres";
GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "dashboard_user";


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."schema_migrations" TO "dashboard_user";
GRANT ALL ON TABLE "auth"."schema_migrations" TO "postgres";


--
-- Name: TABLE "users"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."users" TO "dashboard_user";
GRANT ALL ON TABLE "auth"."users" TO "postgres";


--
-- Name: TABLE "pg_stat_statements"; Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON TABLE "extensions"."pg_stat_statements" TO "dashboard_user";


--
-- Name: TABLE "schema_version"; Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON TABLE "graphql"."schema_version" TO "postgres";
GRANT ALL ON TABLE "graphql"."schema_version" TO "anon";
GRANT ALL ON TABLE "graphql"."schema_version" TO "authenticated";
GRANT ALL ON TABLE "graphql"."schema_version" TO "service_role";


--
-- Name: SEQUENCE "seq_schema_version"; Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE "graphql"."seq_schema_version" TO "postgres";
GRANT ALL ON SEQUENCE "graphql"."seq_schema_version" TO "anon";
GRANT ALL ON SEQUENCE "graphql"."seq_schema_version" TO "authenticated";
GRANT ALL ON SEQUENCE "graphql"."seq_schema_version" TO "service_role";


--
-- Name: TABLE "logs"; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON TABLE "public"."logs" TO "postgres";
GRANT ALL ON TABLE "public"."logs" TO "anon";
GRANT ALL ON TABLE "public"."logs" TO "authenticated";
GRANT ALL ON TABLE "public"."logs" TO "service_role";


--
-- Name: SEQUENCE "logs_id_seq"; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE "public"."logs_id_seq" TO "postgres";
GRANT ALL ON SEQUENCE "public"."logs_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."logs_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."logs_id_seq" TO "service_role";


--
-- Name: TABLE "pings"; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON TABLE "public"."pings" TO "postgres";
GRANT ALL ON TABLE "public"."pings" TO "anon";
GRANT ALL ON TABLE "public"."pings" TO "authenticated";
GRANT ALL ON TABLE "public"."pings" TO "service_role";


--
-- Name: SEQUENCE "pings_id_seq"; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE "public"."pings_id_seq" TO "postgres";
GRANT ALL ON SEQUENCE "public"."pings_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."pings_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."pings_id_seq" TO "service_role";


--
-- Name: SEQUENCE "state_env_id_seq"; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE "public"."state_env_id_seq" TO "postgres";
GRANT ALL ON SEQUENCE "public"."state_env_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."state_env_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."state_env_id_seq" TO "service_role";


--
-- Name: TABLE "state"; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON TABLE "public"."state" TO "postgres";
GRANT ALL ON TABLE "public"."state" TO "anon";
GRANT ALL ON TABLE "public"."state" TO "authenticated";
GRANT ALL ON TABLE "public"."state" TO "service_role";


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."schema_migrations" TO "postgres";
GRANT ALL ON TABLE "realtime"."schema_migrations" TO "dashboard_user";


--
-- Name: TABLE "subscription"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."subscription" TO "postgres";
GRANT ALL ON TABLE "realtime"."subscription" TO "dashboard_user";


--
-- Name: SEQUENCE "subscription_id_seq"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "postgres";
GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "dashboard_user";


--
-- Name: TABLE "buckets"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."buckets" TO "anon";
GRANT ALL ON TABLE "storage"."buckets" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets" TO "postgres";


--
-- Name: TABLE "migrations"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."migrations" TO "anon";
GRANT ALL ON TABLE "storage"."migrations" TO "authenticated";
GRANT ALL ON TABLE "storage"."migrations" TO "service_role";
GRANT ALL ON TABLE "storage"."migrations" TO "postgres";


--
-- Name: TABLE "objects"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."objects" TO "anon";
GRANT ALL ON TABLE "storage"."objects" TO "authenticated";
GRANT ALL ON TABLE "storage"."objects" TO "service_role";
GRANT ALL ON TABLE "storage"."objects" TO "postgres";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES  TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS  TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES  TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES  TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS  TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES  TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES  TO "service_role";


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_graphql_placeholder" ON "sql_drop"
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION "extensions"."set_graphql_placeholder"();


ALTER EVENT TRIGGER "issue_graphql_placeholder" OWNER TO "supabase_admin";

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_cron_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE SCHEMA')
   EXECUTE FUNCTION "extensions"."grant_pg_cron_access"();


ALTER EVENT TRIGGER "issue_pg_cron_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_graphql_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE FUNCTION')
   EXECUTE FUNCTION "extensions"."grant_pg_graphql_access"();


ALTER EVENT TRIGGER "issue_pg_graphql_access" OWNER TO "supabase_admin";

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_ddl_watch" ON "ddl_command_end"
   EXECUTE FUNCTION "extensions"."pgrst_ddl_watch"();


ALTER EVENT TRIGGER "pgrst_ddl_watch" OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_drop_watch" ON "sql_drop"
   EXECUTE FUNCTION "extensions"."pgrst_drop_watch"();


ALTER EVENT TRIGGER "pgrst_drop_watch" OWNER TO "supabase_admin";

--
-- PostgreSQL database dump complete
--

