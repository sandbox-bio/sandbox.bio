--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 14.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP EVENT TRIGGER IF EXISTS "pgrst_drop_watch";
DROP EVENT TRIGGER IF EXISTS "pgrst_ddl_watch";
DROP EVENT TRIGGER IF EXISTS "issue_pg_graphql_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_cron_access";
DROP EVENT TRIGGER IF EXISTS "issue_graphql_placeholder";
DROP PUBLICATION IF EXISTS "supabase_realtime";
DROP POLICY IF EXISTS "UPDATE" ON "public"."state";
DROP POLICY IF EXISTS "SELECT" ON "public"."state";
DROP POLICY IF EXISTS "INSERT" ON "public"."state";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_owner_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_bucketId_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets" DROP CONSTRAINT IF EXISTS "buckets_owner_fkey";
ALTER TABLE IF EXISTS ONLY "public"."state" DROP CONSTRAINT IF EXISTS "state_env_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_parent_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_user_id_fkey";
DROP TRIGGER IF EXISTS "update_objects_updated_at" ON "storage"."objects";
DROP TRIGGER IF EXISTS "tr_check_filters" ON "realtime"."subscription";
DROP INDEX IF EXISTS "storage"."name_prefix_search";
DROP INDEX IF EXISTS "storage"."bucketid_objname";
DROP INDEX IF EXISTS "storage"."bname";
DROP INDEX IF EXISTS "realtime"."subscription_subscription_id_entity_filters_key";
DROP INDEX IF EXISTS "realtime"."ix_realtime_subscription_entity";
DROP INDEX IF EXISTS "auth"."users_instance_id_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_email_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_token_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_parent_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_user_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_idx";
DROP INDEX IF EXISTS "auth"."recovery_token_idx";
DROP INDEX IF EXISTS "auth"."reauthentication_token_idx";
DROP INDEX IF EXISTS "auth"."identities_user_id_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_new_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_current_idx";
DROP INDEX IF EXISTS "auth"."confirmation_token_idx";
DROP INDEX IF EXISTS "auth"."audit_logs_instance_id_idx";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_name_key";
ALTER TABLE IF EXISTS ONLY "storage"."buckets" DROP CONSTRAINT IF EXISTS "buckets_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."subscription" DROP CONSTRAINT IF EXISTS "pk_subscription";
ALTER TABLE IF EXISTS ONLY "public"."state" DROP CONSTRAINT IF EXISTS "unique_user_id";
ALTER TABLE IF EXISTS ONLY "public"."state" DROP CONSTRAINT IF EXISTS "state_env_pkey";
ALTER TABLE IF EXISTS ONLY "public"."pings" DROP CONSTRAINT IF EXISTS "pings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."logs" DROP CONSTRAINT IF EXISTS "logs_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_phone_key";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_email_key";
ALTER TABLE IF EXISTS ONLY "auth"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_token_unique";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."instances" DROP CONSTRAINT IF EXISTS "instances_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."audit_log_entries" DROP CONSTRAINT IF EXISTS "audit_log_entries_pkey";
ALTER TABLE IF EXISTS "public"."state" ALTER COLUMN "id" DROP DEFAULT;
ALTER TABLE IF EXISTS "auth"."refresh_tokens" ALTER COLUMN "id" DROP DEFAULT;
DROP TABLE IF EXISTS "storage"."objects";
DROP TABLE IF EXISTS "storage"."migrations";
DROP TABLE IF EXISTS "storage"."buckets";
DROP TABLE IF EXISTS "realtime"."subscription";
DROP TABLE IF EXISTS "realtime"."schema_migrations";
DROP SEQUENCE IF EXISTS "public"."state_env_id_seq";
DROP TABLE IF EXISTS "public"."state";
DROP TABLE IF EXISTS "public"."pings";
DROP TABLE IF EXISTS "public"."logs";
DROP TABLE IF EXISTS "auth"."users";
DROP TABLE IF EXISTS "auth"."schema_migrations";
DROP SEQUENCE IF EXISTS "auth"."refresh_tokens_id_seq";
DROP TABLE IF EXISTS "auth"."refresh_tokens";
DROP TABLE IF EXISTS "auth"."instances";
DROP TABLE IF EXISTS "auth"."identities";
DROP TABLE IF EXISTS "auth"."audit_log_entries";
DROP FUNCTION IF EXISTS "storage"."update_updated_at_column"();
DROP FUNCTION IF EXISTS "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text");
DROP FUNCTION IF EXISTS "storage"."get_size_by_bucket"();
DROP FUNCTION IF EXISTS "storage"."foldername"("name" "text");
DROP FUNCTION IF EXISTS "storage"."filename"("name" "text");
DROP FUNCTION IF EXISTS "storage"."extension"("name" "text");
DROP FUNCTION IF EXISTS "realtime"."to_regrole"("role_name" "text");
DROP FUNCTION IF EXISTS "realtime"."subscription_check_filters"();
DROP FUNCTION IF EXISTS "realtime"."quote_wal2json"("entity" "regclass");
DROP FUNCTION IF EXISTS "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]);
DROP FUNCTION IF EXISTS "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text");
DROP FUNCTION IF EXISTS "realtime"."cast"("val" "text", "type_" "regtype");
DROP FUNCTION IF EXISTS "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]);
DROP FUNCTION IF EXISTS "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "pgbouncer"."get_auth"("p_usename" "text");
DROP FUNCTION IF EXISTS "extensions"."set_graphql_placeholder"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_drop_watch"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_ddl_watch"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_graphql_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_cron_access"();
DROP FUNCTION IF EXISTS "auth"."uid"();
DROP FUNCTION IF EXISTS "auth"."role"();
DROP FUNCTION IF EXISTS "auth"."jwt"();
DROP FUNCTION IF EXISTS "auth"."email"();
DROP TYPE IF EXISTS "realtime"."wal_rls";
DROP TYPE IF EXISTS "realtime"."wal_column";
DROP TYPE IF EXISTS "realtime"."user_defined_filter";
DROP TYPE IF EXISTS "realtime"."equality_op";
DROP TYPE IF EXISTS "realtime"."action";
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS "pgjwt";
DROP EXTENSION IF EXISTS "pgcrypto";
DROP EXTENSION IF EXISTS "pg_stat_statements";
DROP SCHEMA IF EXISTS "storage";
DROP SCHEMA IF EXISTS "realtime";
DROP SCHEMA IF EXISTS "pgbouncer";
DROP SCHEMA IF EXISTS "graphql_public";
DROP EXTENSION IF EXISTS "pg_graphql";
DROP SCHEMA IF EXISTS "extensions";
DROP SCHEMA IF EXISTS "auth";
--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "auth";


ALTER SCHEMA "auth" OWNER TO "supabase_admin";

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "extensions";


ALTER SCHEMA "extensions" OWNER TO "postgres";

--
-- Name: pg_graphql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_graphql" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pg_graphql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pg_graphql" IS 'GraphQL support';


--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql_public";


ALTER SCHEMA "graphql_public" OWNER TO "supabase_admin";

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA "pgbouncer";


ALTER SCHEMA "pgbouncer" OWNER TO "pgbouncer";

--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "realtime";


ALTER SCHEMA "realtime" OWNER TO "supabase_admin";

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "storage";


ALTER SCHEMA "storage" OWNER TO "supabase_admin";

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pg_stat_statements"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pg_stat_statements" IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pgcrypto"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pgcrypto" IS 'cryptographic functions';


--
-- Name: pgjwt; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pgjwt" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pgjwt"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pgjwt" IS 'JSON Web Token API for Postgresql';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."action" AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE "realtime"."action" OWNER TO "supabase_admin";

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."equality_op" AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte'
);


ALTER TYPE "realtime"."equality_op" OWNER TO "supabase_admin";

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."user_defined_filter" AS (
	"column_name" "text",
	"op" "realtime"."equality_op",
	"value" "text"
);


ALTER TYPE "realtime"."user_defined_filter" OWNER TO "supabase_admin";

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."wal_column" AS (
	"name" "text",
	"type_name" "text",
	"type_oid" "oid",
	"value" "jsonb",
	"is_pkey" boolean,
	"is_selectable" boolean
);


ALTER TYPE "realtime"."wal_column" OWNER TO "supabase_admin";

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."wal_rls" AS (
	"wal" "jsonb",
	"is_rls_enabled" boolean,
	"subscription_ids" "uuid"[],
	"errors" "text"[]
);


ALTER TYPE "realtime"."wal_rls" OWNER TO "supabase_admin";

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."email"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  	coalesce(
		nullif(current_setting('request.jwt.claim.email', true), ''),
		(nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
	)::text
$$;


ALTER FUNCTION "auth"."email"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "email"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."email"() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."jwt"() RETURNS "jsonb"
    LANGUAGE "sql" STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION "auth"."jwt"() OWNER TO "supabase_auth_admin";

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."role"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  	coalesce(
		nullif(current_setting('request.jwt.claim.role', true), ''),
		(nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
	)::text
$$;


ALTER FUNCTION "auth"."role"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "role"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."role"() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."uid"() RETURNS "uuid"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  	coalesce(
		nullif(current_setting('request.jwt.claim.sub', true), ''),
		(nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
	)::uuid
$$;


ALTER FUNCTION "auth"."uid"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "uid"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."uid"() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: postgres
--

CREATE FUNCTION "extensions"."grant_pg_cron_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  schema_is_cron bool;
BEGIN
  schema_is_cron = (
    SELECT n.nspname = 'cron'
    FROM pg_event_trigger_ddl_commands() AS ev
    LEFT JOIN pg_catalog.pg_namespace AS n
      ON ev.objid = n.oid
  );

  IF schema_is_cron
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option; 

  END IF;

END;
$$;


ALTER FUNCTION "extensions"."grant_pg_cron_access"() OWNER TO "postgres";

--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: COMMENT; Schema: extensions; Owner: postgres
--

COMMENT ON FUNCTION "extensions"."grant_pg_cron_access"() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_graphql_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
DECLARE
    func_is_graphql_resolve bool;
BEGIN
    func_is_graphql_resolve = (
        SELECT n.proname = 'resolve'
        FROM pg_event_trigger_ddl_commands() AS ev
        LEFT JOIN pg_catalog.pg_proc AS n
        ON ev.objid = n.oid
    );

    IF func_is_graphql_resolve
    THEN

        -- Update public wrapper to pass all arguments through to the pg_graphql resolve func
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language sql
        as $$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

		-- This hook executes when `graphql.resolve` is created. That is not necessarily the last
		-- function in the extension so we need to grant permissions on existing entities AND
		-- update default permissions to any others that are created after `graphql.resolve`
        grant usage on schema graphql to postgres, anon, authenticated, service_role;
        grant select on all tables in schema graphql to postgres, anon, authenticated, service_role;
        grant execute on all functions in schema graphql to postgres, anon, authenticated, service_role;
        grant all on all sequences in schema graphql to postgres, anon, authenticated, service_role;
		alter default privileges in schema graphql grant all on tables to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on functions to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on sequences to postgres, anon, authenticated, service_role;
    END IF;

END;
$_$;


ALTER FUNCTION "extensions"."grant_pg_graphql_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_graphql_access"() IS 'Grants access to pg_graphql';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_ddl_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_ddl_watch"() OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_drop_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_drop_watch"() OWNER TO "supabase_admin";

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."set_graphql_placeholder"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION "extensions"."set_graphql_placeholder"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."set_graphql_placeholder"() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: get_auth("text"); Type: FUNCTION; Schema: pgbouncer; Owner: postgres
--

CREATE FUNCTION "pgbouncer"."get_auth"("p_usename" "text") RETURNS TABLE("username" "text", "password" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
    RAISE WARNING 'PgBouncer auth request: %', p_usename;

    RETURN QUERY
    SELECT usename::TEXT, passwd::TEXT FROM pg_catalog.pg_shadow
    WHERE usename = p_usename;
END;
$$;


ALTER FUNCTION "pgbouncer"."get_auth"("p_usename" "text") OWNER TO "postgres";

--
-- Name: apply_rls("jsonb", integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer DEFAULT (1024 * 1024)) RETURNS SETOF "realtime"."wal_rls"
    LANGUAGE "plpgsql"
    AS $$
      declare
          -- Regclass of the table e.g. public.notes
          entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

          -- I, U, D, T: insert, update ...
          action realtime.action = (
              case wal ->> 'action'
                  when 'I' then 'INSERT'
                  when 'U' then 'UPDATE'
                  when 'D' then 'DELETE'
                  else 'ERROR'
              end
          );

          -- Is row level security enabled for the table
          is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

          subscriptions realtime.subscription[] = array_agg(subs)
              from
                  realtime.subscription subs
              where
                  subs.entity = entity_;

          -- Subscription vars
          roles regrole[] = array_agg(distinct us.claims_role)
              from
                  unnest(subscriptions) us;

          working_role regrole;
          claimed_role regrole;
          claims jsonb;

          subscription_id uuid;
          subscription_has_access bool;
          visible_to_subscription_ids uuid[] = '{}';

          -- structured info for wal's columns
          columns realtime.wal_column[];
          -- previous identity values for update/delete
          old_columns realtime.wal_column[];

          error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

          -- Primary jsonb output for record
          output jsonb;

      begin
          perform set_config('role', null, true);

          columns =
              array_agg(
                  (
                      x->>'name',
                      x->>'type',
                      x->>'typeoid',
                      realtime.cast(
                          (x->'value') #>> '{}',
                          coalesce(
                              (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                              (x->>'type')::regtype
                          )
                      ),
                      (pks ->> 'name') is not null,
                      true
                  )::realtime.wal_column
              )
              from
                  jsonb_array_elements(wal -> 'columns') x
                  left join jsonb_array_elements(wal -> 'pk') pks
                      on (x ->> 'name') = (pks ->> 'name');

          old_columns =
              array_agg(
                  (
                      x->>'name',
                      x->>'type',
                      x->>'typeoid',
                      realtime.cast(
                          (x->'value') #>> '{}',
                          coalesce(
                              (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                              (x->>'type')::regtype
                          )
                      ),
                      (pks ->> 'name') is not null,
                      true
                  )::realtime.wal_column
              )
              from
                  jsonb_array_elements(wal -> 'identity') x
                  left join jsonb_array_elements(wal -> 'pk') pks
                      on (x ->> 'name') = (pks ->> 'name');

          for working_role in select * from unnest(roles) loop

              -- Update `is_selectable` for columns and old_columns
              columns =
                  array_agg(
                      (
                          c.name,
                          c.type_name,
                          c.type_oid,
                          c.value,
                          c.is_pkey,
                          pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                      )::realtime.wal_column
                  )
                  from
                      unnest(columns) c;

              old_columns =
                      array_agg(
                          (
                              c.name,
                              c.type_name,
                              c.type_oid,
                              c.value,
                              c.is_pkey,
                              pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                          )::realtime.wal_column
                      )
                      from
                          unnest(old_columns) c;

              if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
                  return next (
                      jsonb_build_object(
                          'schema', wal ->> 'schema',
                          'table', wal ->> 'table',
                          'type', action
                      ),
                      is_rls_enabled,
                      -- subscriptions is already filtered by entity
                      (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
                      array['Error 400: Bad Request, no primary key']
                  )::realtime.wal_rls;

              -- The claims role does not have SELECT permission to the primary key of entity
              elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
                  return next (
                      jsonb_build_object(
                          'schema', wal ->> 'schema',
                          'table', wal ->> 'table',
                          'type', action
                      ),
                      is_rls_enabled,
                      (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
                      array['Error 401: Unauthorized']
                  )::realtime.wal_rls;

              else
                  output = jsonb_build_object(
                      'schema', wal ->> 'schema',
                      'table', wal ->> 'table',
                      'type', action,
                      'commit_timestamp', to_char(
                          (wal ->> 'timestamp')::timestamptz,
                          'YYYY-MM-DD"T"HH24:MI:SS"Z"'
                      ),
                      'columns', (
                          select
                              jsonb_agg(
                                  jsonb_build_object(
                                      'name', pa.attname,
                                      'type', pt.typname
                                  )
                                  order by pa.attnum asc
                              )
                          from
                              pg_attribute pa
                              join pg_type pt
                                  on pa.atttypid = pt.oid
                          where
                              attrelid = entity_
                              and attnum > 0
                              and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
                      )
                  )
                  -- Add "record" key for insert and update
                  || case
                      when action in ('INSERT', 'UPDATE') then
                          case
                              when error_record_exceeds_max_size then
                                  jsonb_build_object(
                                      'record',
                                      (
                                          select jsonb_object_agg((c).name, (c).value)
                                          from unnest(columns) c
                                          where (c).is_selectable and (octet_length((c).value::text) <= 64)
                                      )
                                  )
                              else
                                  jsonb_build_object(
                                      'record',
                                      (select jsonb_object_agg((c).name, (c).value) from unnest(columns) c where (c).is_selectable)
                                  )
                          end
                      else '{}'::jsonb
                  end
                  -- Add "old_record" key for update and delete
                  || case
                      when action in ('UPDATE', 'DELETE') then
                          case
                              when error_record_exceeds_max_size then
                                  jsonb_build_object(
                                      'old_record',
                                      (
                                          select jsonb_object_agg((c).name, (c).value)
                                          from unnest(old_columns) c
                                          where (c).is_selectable and (octet_length((c).value::text) <= 64)
                                      )
                                  )
                              else
                                  jsonb_build_object(
                                      'old_record',
                                      (select jsonb_object_agg((c).name, (c).value) from unnest(old_columns) c where (c).is_selectable)
                                  )
                          end
                      else '{}'::jsonb
                  end;

                  -- Create the prepared statement
                  if is_rls_enabled and action <> 'DELETE' then
                      if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                          deallocate walrus_rls_stmt;
                      end if;
                      execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
                  end if;

                  visible_to_subscription_ids = '{}';

                  for subscription_id, claims in (
                          select
                              subs.subscription_id,
                              subs.claims
                          from
                              unnest(subscriptions) subs
                          where
                              subs.entity = entity_
                              and subs.claims_role = working_role
                              and realtime.is_visible_through_filters(columns, subs.filters)
                  ) loop

                      if not is_rls_enabled or action = 'DELETE' then
                          visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                      else
                          -- Check if RLS allows the role to see the record
                          perform
                              set_config('role', working_role::text, true),
                              set_config('request.jwt.claims', claims::text, true);

                          execute 'execute walrus_rls_stmt' into subscription_has_access;

                          if subscription_has_access then
                              visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                          end if;
                      end if;
                  end loop;

                  perform set_config('role', null, true);

                  return next (
                      output,
                      is_rls_enabled,
                      visible_to_subscription_ids,
                      case
                          when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                          else '{}'
                      end
                  )::realtime.wal_rls;

              end if;
          end loop;

          perform set_config('role', null, true);
      end;
    $$;


ALTER FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) OWNER TO "supabase_admin";

--
-- Name: build_prepared_statement_sql("text", "regclass", "realtime"."wal_column"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) RETURNS "text"
    LANGUAGE "sql"
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) OWNER TO "supabase_admin";

--
-- Name: cast("text", "regtype"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") RETURNS "jsonb"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
    declare
      res jsonb;
    begin
      execute format('select to_jsonb(%L::'|| type_::text || ')', val)  into res;
      return res;
    end
    $$;


ALTER FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") OWNER TO "supabase_admin";

--
-- Name: check_equality_op("realtime"."equality_op", "regtype", "text", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") RETURNS boolean
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
    /*
    Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
    */
    declare
      op_symbol text = (
        case
          when op = 'eq' then '='
          when op = 'neq' then '!='
          when op = 'lt' then '<'
          when op = 'lte' then '<='
          when op = 'gt' then '>'
          when op = 'gte' then '>='
          else 'UNKNOWN OP'
        end
      );
      res boolean;
    begin
      execute format('select %L::'|| type_::text || ' ' || op_symbol || ' %L::'|| type_::text, val_1, val_2) into res;
      return res;
    end;
    $$;


ALTER FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") OWNER TO "supabase_admin";

--
-- Name: is_visible_through_filters("realtime"."wal_column"[], "realtime"."user_defined_filter"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) RETURNS boolean
    LANGUAGE "sql" IMMUTABLE
    AS $$
        /*
        Should the record be visible (true) or filtered out (false) after *filters* are applied
        */
            select
                -- Default to allowed when no filters present
                coalesce(
                    sum(
                        realtime.check_equality_op(
                            op:=f.op,
                            type_:=coalesce(
                                col.type_oid::regtype, -- null when wal2json version <= 2.4
                                col.type_name::regtype
                            ),
                            -- cast jsonb to text
                            val_1:=col.value #>> '{}',
                            val_2:=f.value
                        )::int
                    ) = count(1),
                    true
                )
            from
                unnest(filters) f
                join unnest(columns) col
                    on f.column_name = col.name;
        $$;


ALTER FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) OWNER TO "supabase_admin";

--
-- Name: quote_wal2json("regclass"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."quote_wal2json"("entity" "regclass") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


ALTER FUNCTION "realtime"."quote_wal2json"("entity" "regclass") OWNER TO "supabase_admin";

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."subscription_check_filters"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
      col_names text[] = coalesce(
        array_agg(c.column_name order by c.ordinal_position),
        '{}'::text[]
      )
      from
        information_schema.columns c
      where
        format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
        and pg_catalog.has_column_privilege(
          (new.claims ->> 'role'),
          format('%I.%I', c.table_schema, c.table_name)::regclass,
          c.column_name,
          'SELECT'
        );
      filter realtime.user_defined_filter;
      col_type regtype;
    begin
      for filter in select * from unnest(new.filters) loop
        -- Filtered column is valid
        if not filter.column_name = any(col_names) then
          raise exception 'invalid column for filter %', filter.column_name;
        end if;

        -- Type is sanitized and safe for string interpolation
        col_type = (
          select atttypid::regtype
          from pg_catalog.pg_attribute
          where attrelid = new.entity
            and attname = filter.column_name
        );
        if col_type is null then
          raise exception 'failed to lookup type for column %', filter.column_name;
        end if;
        -- raises an exception if value is not coercable to type
        perform realtime.cast(filter.value, col_type);
      end loop;

      -- Apply consistent order to filters so the unique constraint on
      -- (subscription_id, entity, filters) can't be tricked by a different filter order
      new.filters = coalesce(
        array_agg(f order by f.column_name, f.op, f.value),
        '{}'
      ) from unnest(new.filters) f;

    return new;
  end;
  $$;


ALTER FUNCTION "realtime"."subscription_check_filters"() OWNER TO "supabase_admin";

--
-- Name: to_regrole("text"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."to_regrole"("role_name" "text") RETURNS "regrole"
    LANGUAGE "sql" IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION "realtime"."to_regrole"("role_name" "text") OWNER TO "supabase_admin";

--
-- Name: extension("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."extension"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
_parts text[];
_filename text;
BEGIN
	select string_to_array(name, '/') into _parts;
	select _parts[array_length(_parts,1)] into _filename;
	-- @todo return the last part instead of 2
	return split_part(_filename, '.', 2);
END
$$;


ALTER FUNCTION "storage"."extension"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: filename("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."filename"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION "storage"."filename"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: foldername("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."foldername"("name" "text") RETURNS "text"[]
    LANGUAGE "plpgsql"
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[1:array_length(_parts,1)-1];
END
$$;


ALTER FUNCTION "storage"."foldername"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_size_by_bucket"() RETURNS TABLE("size" bigint, "bucket_id" "text")
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::int) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION "storage"."get_size_by_bucket"() OWNER TO "supabase_storage_admin";

--
-- Name: search("text", "text", integer, integer, integer, "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "offsets" integer DEFAULT 0, "search" "text" DEFAULT ''::"text", "sortcolumn" "text" DEFAULT 'name'::"text", "sortorder" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
declare
  v_order_by text;
  v_sort_order text;
begin
  case
    when sortcolumn = 'name' then
      v_order_by = 'name';
    when sortcolumn = 'updated_at' then
      v_order_by = 'updated_at';
    when sortcolumn = 'created_at' then
      v_order_by = 'created_at';
    when sortcolumn = 'last_accessed_at' then
      v_order_by = 'last_accessed_at';
    else
      v_order_by = 'name';
  end case;

  case
    when sortorder = 'asc' then
      v_sort_order = 'asc';
    when sortorder = 'desc' then
      v_sort_order = 'desc';
    else
      v_sort_order = 'asc';
  end case;

  v_order_by = v_order_by || ' ' || v_sort_order;

  return query execute
    'with folders as (
       select path_tokens[$1] as folder
       from storage.objects
         where objects.name ilike $2 || $3 || ''%''
           and bucket_id = $4
           and array_length(regexp_split_to_array(objects.name, ''/''), 1) <> $1
       group by folder
       order by folder ' || v_sort_order || '
     )
     (select folder as "name",
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[$1] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where objects.name ilike $2 || $3 || ''%''
       and bucket_id = $4
       and array_length(regexp_split_to_array(objects.name, ''/''), 1) = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


ALTER FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text") OWNER TO "supabase_storage_admin";

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."update_updated_at_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION "storage"."update_updated_at_column"() OWNER TO "supabase_storage_admin";

SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."audit_log_entries" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "payload" "json",
    "created_at" timestamp with time zone,
    "ip_address" character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE "auth"."audit_log_entries" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "audit_log_entries"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."audit_log_entries" IS 'Auth: Audit trail for user actions.';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."identities" (
    "id" "text" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "identity_data" "jsonb" NOT NULL,
    "provider" "text" NOT NULL,
    "last_sign_in_at" timestamp with time zone,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone
);


ALTER TABLE "auth"."identities" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "identities"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."identities" IS 'Auth: Stores identities associated to a user.';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."instances" (
    "id" "uuid" NOT NULL,
    "uuid" "uuid",
    "raw_base_config" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone
);


ALTER TABLE "auth"."instances" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "instances"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."instances" IS 'Auth: Manages users across multiple sites.';


--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."refresh_tokens" (
    "instance_id" "uuid",
    "id" bigint NOT NULL,
    "token" character varying(255),
    "user_id" character varying(255),
    "revoked" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "parent" character varying(255)
);


ALTER TABLE "auth"."refresh_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "refresh_tokens"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."refresh_tokens" IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE "auth"."refresh_tokens_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "auth"."refresh_tokens_id_seq" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNED BY "auth"."refresh_tokens"."id";


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."schema_migrations" (
    "version" character varying(255) NOT NULL
);


ALTER TABLE "auth"."schema_migrations" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "schema_migrations"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."schema_migrations" IS 'Auth: Manages updates to the auth system.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."users" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "aud" character varying(255),
    "role" character varying(255),
    "email" character varying(255),
    "encrypted_password" character varying(255),
    "email_confirmed_at" timestamp with time zone,
    "invited_at" timestamp with time zone,
    "confirmation_token" character varying(255),
    "confirmation_sent_at" timestamp with time zone,
    "recovery_token" character varying(255),
    "recovery_sent_at" timestamp with time zone,
    "email_change_token_new" character varying(255),
    "email_change" character varying(255),
    "email_change_sent_at" timestamp with time zone,
    "last_sign_in_at" timestamp with time zone,
    "raw_app_meta_data" "jsonb",
    "raw_user_meta_data" "jsonb",
    "is_super_admin" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "phone" character varying(15) DEFAULT NULL::character varying,
    "phone_confirmed_at" timestamp with time zone,
    "phone_change" character varying(15) DEFAULT ''::character varying,
    "phone_change_token" character varying(255) DEFAULT ''::character varying,
    "phone_change_sent_at" timestamp with time zone,
    "confirmed_at" timestamp with time zone GENERATED ALWAYS AS (LEAST("email_confirmed_at", "phone_confirmed_at")) STORED,
    "email_change_token_current" character varying(255) DEFAULT ''::character varying,
    "email_change_confirm_status" smallint DEFAULT 0,
    "banned_until" timestamp with time zone,
    "reauthentication_token" character varying(255) DEFAULT ''::character varying,
    "reauthentication_sent_at" timestamp with time zone,
    CONSTRAINT "users_email_change_confirm_status_check" CHECK ((("email_change_confirm_status" >= 0) AND ("email_change_confirm_status" <= 2)))
);


ALTER TABLE "auth"."users" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "users"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."users" IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: logs; Type: TABLE; Schema: public; Owner: supabase_admin
--

CREATE TABLE "public"."logs" (
    "id" bigint NOT NULL,
    "time" timestamp with time zone DEFAULT "now"(),
    "pathname" "text",
    "status" smallint,
    "search" "text"
);


ALTER TABLE "public"."logs" OWNER TO "supabase_admin";

--
-- Name: TABLE "logs"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON TABLE "public"."logs" IS 'Logs';


--
-- Name: COLUMN "logs"."time"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."logs"."time" IS 'Timestamp';


--
-- Name: COLUMN "logs"."pathname"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."logs"."pathname" IS 'Path';


--
-- Name: COLUMN "logs"."status"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."logs"."status" IS 'HTTP Status Code';


--
-- Name: COLUMN "logs"."search"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."logs"."search" IS 'Search Params';


--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: public; Owner: supabase_admin
--

ALTER TABLE "public"."logs" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."logs_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: pings; Type: TABLE; Schema: public; Owner: supabase_admin
--

CREATE TABLE "public"."pings" (
    "id" bigint NOT NULL,
    "time" timestamp with time zone DEFAULT "now"() NOT NULL,
    "ip" "text",
    "step_from" smallint,
    "step_to" smallint,
    "tutorial" "text"
);


ALTER TABLE "public"."pings" OWNER TO "supabase_admin";

--
-- Name: TABLE "pings"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON TABLE "public"."pings" IS 'Analytics for tutorial usage';


--
-- Name: COLUMN "pings"."time"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."pings"."time" IS 'Timestamp';


--
-- Name: COLUMN "pings"."ip"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."pings"."ip" IS 'IP Address (MD5-hashed for privacy)';


--
-- Name: COLUMN "pings"."step_from"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."pings"."step_from" IS 'Going from this step';


--
-- Name: COLUMN "pings"."step_to"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."pings"."step_to" IS 'To this step';


--
-- Name: COLUMN "pings"."tutorial"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."pings"."tutorial" IS 'Tutorial Short Name';


--
-- Name: pings_id_seq; Type: SEQUENCE; Schema: public; Owner: supabase_admin
--

ALTER TABLE "public"."pings" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."pings_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: state; Type: TABLE; Schema: public; Owner: supabase_admin
--

CREATE TABLE "public"."state" (
    "id" integer NOT NULL,
    "user_id" "uuid" NOT NULL,
    "env" "jsonb",
    "progress" "jsonb"
);


ALTER TABLE "public"."state" OWNER TO "supabase_admin";

--
-- Name: TABLE "state"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON TABLE "public"."state" IS 'Saved state (env variables, tutorial progress, etc)';


--
-- Name: COLUMN "state"."env"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."state"."env" IS 'Environment Variables';


--
-- Name: COLUMN "state"."progress"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON COLUMN "public"."state"."progress" IS 'Tutorial progress';


--
-- Name: state_env_id_seq; Type: SEQUENCE; Schema: public; Owner: supabase_admin
--

CREATE SEQUENCE "public"."state_env_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "public"."state_env_id_seq" OWNER TO "supabase_admin";

--
-- Name: state_env_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: supabase_admin
--

ALTER SEQUENCE "public"."state_env_id_seq" OWNED BY "public"."state"."id";


--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."schema_migrations" (
    "version" bigint NOT NULL,
    "inserted_at" timestamp(0) without time zone
);


ALTER TABLE "realtime"."schema_migrations" OWNER TO "supabase_admin";

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."subscription" (
    "id" bigint NOT NULL,
    "subscription_id" "uuid" NOT NULL,
    "entity" "regclass" NOT NULL,
    "filters" "realtime"."user_defined_filter"[] DEFAULT '{}'::"realtime"."user_defined_filter"[] NOT NULL,
    "claims" "jsonb" NOT NULL,
    "claims_role" "regrole" GENERATED ALWAYS AS ("realtime"."to_regrole"(("claims" ->> 'role'::"text"))) STORED NOT NULL,
    "created_at" timestamp without time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL
);


ALTER TABLE "realtime"."subscription" OWNER TO "supabase_admin";

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE "realtime"."subscription" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "realtime"."subscription_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "public" boolean DEFAULT false
);


ALTER TABLE "storage"."buckets" OWNER TO "supabase_storage_admin";

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."migrations" (
    "id" integer NOT NULL,
    "name" character varying(100) NOT NULL,
    "hash" character varying(40) NOT NULL,
    "executed_at" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE "storage"."migrations" OWNER TO "supabase_storage_admin";

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."objects" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "bucket_id" "text",
    "name" "text",
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "last_accessed_at" timestamp with time zone DEFAULT "now"(),
    "metadata" "jsonb",
    "path_tokens" "text"[] GENERATED ALWAYS AS ("string_to_array"("name", '/'::"text")) STORED
);


ALTER TABLE "storage"."objects" OWNER TO "supabase_storage_admin";

--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens" ALTER COLUMN "id" SET DEFAULT "nextval"('"auth"."refresh_tokens_id_seq"'::"regclass");


--
-- Name: state id; Type: DEFAULT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY "public"."state" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."state_env_id_seq"'::"regclass");


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."audit_log_entries" ("instance_id", "id", "payload", "created_at", "ip_address") FROM stdin;
00000000-0000-0000-0000-000000000000	372d4919-35a2-4eb8-a42c-c51ff9617ee1	{"action":"user_confirmation_requested","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"user","timestamp":"2021-08-31T17:55:21Z"}	2021-08-31 17:55:21.708975+00	
00000000-0000-0000-0000-000000000000	a126e342-3187-4f01-8242-b97c48a67301	{"action":"user_signedup","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"team","timestamp":"2021-08-31T17:56:13Z"}	2021-08-31 17:56:13.398119+00	
00000000-0000-0000-0000-000000000000	c5f8dd41-4942-4663-acff-93738d82ec1b	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-08-31T17:58:26Z"}	2021-08-31 17:58:26.543496+00	
00000000-0000-0000-0000-000000000000	5719f5d6-493f-4b9d-bfbd-44a3f5a794bc	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-08-31T19:19:28Z"}	2021-08-31 19:19:28.80227+00	
00000000-0000-0000-0000-000000000000	d1cee274-1379-4b1b-a3af-5f7d0805cbcc	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-08-31T19:19:28Z"}	2021-08-31 19:19:28.80352+00	
00000000-0000-0000-0000-000000000000	108dafab-58d3-40ad-91df-e42e3c002278	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-08-31T20:18:49Z"}	2021-08-31 20:18:49.038814+00	
00000000-0000-0000-0000-000000000000	bee1a77c-acf0-4923-b304-c72962f78543	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-08-31T20:18:49Z"}	2021-08-31 20:18:49.039738+00	
00000000-0000-0000-0000-000000000000	c85c9955-282e-42d7-b467-2a1ffe237b59	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-08-31T22:04:45Z"}	2021-08-31 22:04:45.366468+00	
00000000-0000-0000-0000-000000000000	c8d81ba0-b0ff-48f2-90ef-7b393d110106	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-08-31T22:04:45Z"}	2021-08-31 22:04:45.367444+00	
00000000-0000-0000-0000-000000000000	a25f3560-94aa-441d-906e-9bf4426c6380	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-08-31T22:29:14Z"}	2021-08-31 22:29:14.80871+00	
00000000-0000-0000-0000-000000000000	f0c1aa3e-0322-4240-a72c-d637859a2c5d	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-08-31T22:43:57Z"}	2021-08-31 22:43:57.258407+00	
00000000-0000-0000-0000-000000000000	9df10e3c-910d-450a-8edd-5e7bbe264e1d	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-08-31T22:45:52Z"}	2021-08-31 22:45:52.437609+00	
00000000-0000-0000-0000-000000000000	a607c588-9af9-4ccd-9e64-5cc4b39e4741	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-08-31T22:51:42Z"}	2021-08-31 22:51:42.491979+00	
00000000-0000-0000-0000-000000000000	1ecf0260-9d6c-4899-bc9b-01460c05905d	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-08-31T22:52:36Z"}	2021-08-31 22:52:36.252654+00	
00000000-0000-0000-0000-000000000000	037e083b-b7a5-48ba-b9b8-748c0c248a7b	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-08-31T23:00:47Z"}	2021-08-31 23:00:47.205093+00	
00000000-0000-0000-0000-000000000000	cc2eed7e-911e-4119-853b-9b9491a13a62	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-08-31T23:01:42Z"}	2021-08-31 23:01:42.199605+00	
00000000-0000-0000-0000-000000000000	79bbe9b8-4a33-42b5-ac8d-e682d64d1f2d	{"action":"user_confirmation_requested","actor_id":"5b37e8d3-965f-4265-a659-afa94d9e9359","actor_username":"robert.aboukhalil+test@gmail.com","log_type":"user","timestamp":"2021-08-31T23:05:24Z"}	2021-08-31 23:05:24.396692+00	
00000000-0000-0000-0000-000000000000	2b1ac7a4-3183-4633-a55f-be4860c7c157	{"action":"user_signedup","actor_id":"5b37e8d3-965f-4265-a659-afa94d9e9359","actor_username":"robert.aboukhalil+test@gmail.com","log_type":"team","timestamp":"2021-08-31T23:08:28Z"}	2021-08-31 23:08:28.885933+00	
00000000-0000-0000-0000-000000000000	569a74cb-9e35-405a-82c9-f51da8ad9596	{"action":"logout","actor_id":"5b37e8d3-965f-4265-a659-afa94d9e9359","actor_username":"robert.aboukhalil+test@gmail.com","log_type":"account","timestamp":"2021-08-31T23:08:44Z"}	2021-08-31 23:08:44.363125+00	
00000000-0000-0000-0000-000000000000	2b150742-20bd-40fb-98d5-59939d773bc8	{"action":"user_confirmation_requested","actor_id":"541bca09-99f1-4fb0-8834-4fac4953fbf0","actor_username":"robert.aboukhalil+test@gmail.com","log_type":"user","timestamp":"2021-08-31T23:09:12Z"}	2021-08-31 23:09:12.294362+00	
00000000-0000-0000-0000-000000000000	b9250265-0d63-4b64-a7f7-8c17f743e3bd	{"action":"user_confirmation_requested","actor_id":"2777ab77-d307-431e-8344-fcefbd67a6bb","actor_username":"robert.aboukhalil+test2@gmail.com","log_type":"user","timestamp":"2021-08-31T23:09:54Z"}	2021-08-31 23:09:54.008548+00	
00000000-0000-0000-0000-000000000000	8049d957-ab52-48f4-ae1d-f4eaf096a105	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-08-31T23:10:13Z"}	2021-08-31 23:10:13.815909+00	
00000000-0000-0000-0000-000000000000	533ba33b-1311-4738-9240-7f308e38ebd7	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-08-31T23:13:33Z"}	2021-08-31 23:13:33.028552+00	
00000000-0000-0000-0000-000000000000	6894e3be-6250-4bc3-83e8-ba8a397955af	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-08-31T23:13:58Z"}	2021-08-31 23:13:58.1247+00	
00000000-0000-0000-0000-000000000000	57461f64-5608-417f-930b-3015d1edf76e	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-08-31T23:14:02Z"}	2021-08-31 23:14:02.607505+00	
00000000-0000-0000-0000-000000000000	d1c58346-2f7b-469c-b9b1-d93051f481d2	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-08-31T23:14:06Z"}	2021-08-31 23:14:06.540602+00	
00000000-0000-0000-0000-000000000000	35f861d2-8403-46cc-b02f-0a09957a42f6	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-08-31T23:14:48Z"}	2021-08-31 23:14:48.645827+00	
00000000-0000-0000-0000-000000000000	b257f432-3a53-4244-8c39-e315c0134375	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-08-31T23:14:54Z"}	2021-08-31 23:14:54.330164+00	
00000000-0000-0000-0000-000000000000	55b38c4c-90bf-4f1a-b7e2-28a85470aa24	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-08-31T23:35:01Z"}	2021-08-31 23:35:01.129186+00	
00000000-0000-0000-0000-000000000000	43375e79-ce75-49bb-af92-d602e4d47599	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-08-31T23:35:03Z"}	2021-08-31 23:35:03.934279+00	
00000000-0000-0000-0000-000000000000	25ea9017-feed-4551-837d-9583e8b40600	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-08-31T23:41:36Z"}	2021-08-31 23:41:36.963461+00	
00000000-0000-0000-0000-000000000000	a68fe74b-72ca-4acc-9134-f22949750734	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-08-31T23:41:40Z"}	2021-08-31 23:41:40.438735+00	
00000000-0000-0000-0000-000000000000	fc5dd11b-f60d-4270-8bf5-0fb2c703b3ce	{"action":"user_invited","actor_id":"00000000-0000-0000-0000-000000000000","actor_username":"","log_type":"team","timestamp":"2021-08-31T23:53:11Z","traits":{"user_email":"robert.aboukhalil@yahoo.com","user_id":"7bc09320-2922-4f85-b614-44f9369c3733"}}	2021-08-31 23:53:11.490937+00	
00000000-0000-0000-0000-000000000000	50c56c8a-b13f-40c0-a473-799ec52126ae	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-08-31T23:59:26Z"}	2021-08-31 23:59:26.863616+00	
00000000-0000-0000-0000-000000000000	e099296d-9b9a-4f59-a9e7-b69b8d65684a	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-08-31T23:59:32Z"}	2021-08-31 23:59:32.771546+00	
00000000-0000-0000-0000-000000000000	081165bb-b1f0-4023-aed5-b517a2b30744	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T00:18:39Z"}	2021-09-01 00:18:39.352465+00	
00000000-0000-0000-0000-000000000000	951af52d-1714-4763-8e16-fdf6f00a558f	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T00:20:55Z"}	2021-09-01 00:20:55.101543+00	
00000000-0000-0000-0000-000000000000	007f050d-6411-4a48-bf0a-faffb53991be	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T00:21:50Z"}	2021-09-01 00:21:50.506263+00	
00000000-0000-0000-0000-000000000000	b2e81f9d-ed5c-4389-9a50-9b31a1102730	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T02:40:57Z"}	2021-09-01 02:40:57.747869+00	
00000000-0000-0000-0000-000000000000	9ce1558c-d0be-4227-aada-6b30dc93bedb	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T02:41:07Z"}	2021-09-01 02:41:07.257055+00	
00000000-0000-0000-0000-000000000000	e81768ad-3ee4-4eac-ba3a-bef061dc4f4b	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T02:41:44Z"}	2021-09-01 02:41:44.751963+00	
00000000-0000-0000-0000-000000000000	b785b948-2bde-41a0-80a8-9dcb5efe3819	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T03:21:23Z"}	2021-09-01 03:21:23.485459+00	
00000000-0000-0000-0000-000000000000	50c89af8-60dc-4788-aee7-0170a4ece5ce	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T03:45:56Z"}	2021-09-01 03:45:56.528464+00	
00000000-0000-0000-0000-000000000000	c4340504-cf07-4676-a10d-c42356b247f0	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T03:46:32Z"}	2021-09-01 03:46:32.965102+00	
00000000-0000-0000-0000-000000000000	ecd25c23-50c9-4b90-8827-6b37e668c600	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T03:46:37Z"}	2021-09-01 03:46:37.463021+00	
00000000-0000-0000-0000-000000000000	625cfa7b-7792-48c4-a70b-b2bd8660474e	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T03:47:16Z"}	2021-09-01 03:47:16.444617+00	
00000000-0000-0000-0000-000000000000	ce8b6a4f-c511-41e4-8ae1-7125dc83dc36	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T03:47:23Z"}	2021-09-01 03:47:23.595322+00	
00000000-0000-0000-0000-000000000000	f2137b76-dbb0-43ba-a7c7-e8189d9be0ce	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T03:48:53Z"}	2021-09-01 03:48:53.328528+00	
00000000-0000-0000-0000-000000000000	0e37f065-9c11-4992-a700-0d8f79a3a85d	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T03:48:56Z"}	2021-09-01 03:48:56.829093+00	
00000000-0000-0000-0000-000000000000	1f195149-1490-427d-9997-1c957d94c52a	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T03:53:11Z"}	2021-09-01 03:53:11.647797+00	
00000000-0000-0000-0000-000000000000	43ff522a-98c0-4749-a367-e112273fc9f1	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T03:53:15Z"}	2021-09-01 03:53:15.326062+00	
00000000-0000-0000-0000-000000000000	58167383-56ad-419b-b157-c02f636b1847	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T03:55:05Z"}	2021-09-01 03:55:05.404857+00	
00000000-0000-0000-0000-000000000000	00ab3efd-2db8-43e0-8943-9aa2cea947fe	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T03:55:08Z"}	2021-09-01 03:55:08.387828+00	
00000000-0000-0000-0000-000000000000	cd25adb7-6485-48e8-a492-1d536559ffd4	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T03:57:34Z"}	2021-09-01 03:57:34.398543+00	
00000000-0000-0000-0000-000000000000	9c427029-7420-445f-94b6-600fa8ba2d2a	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T04:00:22Z"}	2021-09-01 04:00:22.94245+00	
00000000-0000-0000-0000-000000000000	49e1f244-729a-48ed-b17a-5951a1a0ad23	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T04:09:18Z"}	2021-09-01 04:09:18.356615+00	
00000000-0000-0000-0000-000000000000	debae603-090b-4a43-8612-e3473bb4d2ef	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T04:09:29Z"}	2021-09-01 04:09:29.027929+00	
00000000-0000-0000-0000-000000000000	1d728de1-d4f0-4e18-8d3e-86159f41c2fb	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T04:09:53Z"}	2021-09-01 04:09:53.344247+00	
00000000-0000-0000-0000-000000000000	42a022c5-3aca-46cd-8a7e-8d4ad4478f54	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T04:10:01Z"}	2021-09-01 04:10:01.531114+00	
00000000-0000-0000-0000-000000000000	3f91a363-9cb4-4494-acbc-ed1f03cfca2d	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T04:10:07Z"}	2021-09-01 04:10:07.946551+00	
00000000-0000-0000-0000-000000000000	48b65976-81cd-4091-ad32-d3a1c5945ab9	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T04:14:25Z"}	2021-09-01 04:14:25.345821+00	
00000000-0000-0000-0000-000000000000	905ed8cd-f1ef-45fb-bda4-90a5e9465f36	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T04:14:50Z"}	2021-09-01 04:14:50.826517+00	
00000000-0000-0000-0000-000000000000	f7636f4a-cda4-45ba-830a-50f541531584	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T04:16:17Z"}	2021-09-01 04:16:17.762115+00	
00000000-0000-0000-0000-000000000000	1bacaf8f-64cd-40d0-a278-3929d73b0bf5	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T04:16:30Z"}	2021-09-01 04:16:30.599856+00	
00000000-0000-0000-0000-000000000000	88224da5-faa5-4c1b-bbea-ba0d28eab692	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T04:16:38Z"}	2021-09-01 04:16:38.158945+00	
00000000-0000-0000-0000-000000000000	5f2d4f3c-2d3c-47a2-8332-d276a027e301	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T04:20:29Z"}	2021-09-01 04:20:29.074486+00	
00000000-0000-0000-0000-000000000000	7c6a643d-fe3d-4644-91a7-e4262ef82f87	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T04:21:05Z"}	2021-09-01 04:21:05.09089+00	
00000000-0000-0000-0000-000000000000	c6ef50ea-86c7-411a-9f7e-fe7ea31af9e6	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T04:21:07Z"}	2021-09-01 04:21:07.116201+00	
00000000-0000-0000-0000-000000000000	082f904d-1b4b-4647-8d5f-7f313dc04472	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T04:22:57Z"}	2021-09-01 04:22:57.073129+00	
00000000-0000-0000-0000-000000000000	bb2df122-d813-423b-95df-b606c0120184	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T04:23:12Z"}	2021-09-01 04:23:12.509856+00	
00000000-0000-0000-0000-000000000000	bde9727d-3a3c-4a90-b9d1-9e3b7879c8f1	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T04:23:25Z"}	2021-09-01 04:23:25.784464+00	
00000000-0000-0000-0000-000000000000	84aaf451-6828-48b3-8171-1924145b182d	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T16:36:01Z"}	2021-09-01 16:36:01.795431+00	
00000000-0000-0000-0000-000000000000	cf0e0eb3-59a0-4eb4-8a94-4e2d9c28b8e8	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T16:46:27Z"}	2021-09-01 16:46:27.378756+00	
00000000-0000-0000-0000-000000000000	34dd75c3-c061-4ce2-8d56-8c880018c000	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T16:46:38Z"}	2021-09-01 16:46:38.419027+00	
00000000-0000-0000-0000-000000000000	ecbf4795-8a76-4363-975a-497fa5681796	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-01T17:46:37Z"}	2021-09-01 17:46:37.535842+00	
00000000-0000-0000-0000-000000000000	8895221f-ba0c-4dd1-baec-cf780e0b1f85	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-01T17:46:37Z"}	2021-09-01 17:46:37.537422+00	
00000000-0000-0000-0000-000000000000	15644b84-bc58-4926-b123-eccb510ecc0f	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T18:05:45Z"}	2021-09-01 18:05:45.849367+00	
00000000-0000-0000-0000-000000000000	5ab1b5f1-b371-4ad2-81ca-fdedecccb59d	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T18:05:52Z"}	2021-09-01 18:05:52.853806+00	
00000000-0000-0000-0000-000000000000	0d36fc07-580f-4b75-8eb3-7b2595bd8491	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-01T19:10:49Z"}	2021-09-01 19:10:49.449769+00	
00000000-0000-0000-0000-000000000000	1803e965-67f8-4a54-9bab-9cdd748cb365	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-01T19:10:49Z"}	2021-09-01 19:10:49.45073+00	
00000000-0000-0000-0000-000000000000	bddfd704-3e0d-4365-9a9e-01c88866b4d3	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T19:45:27Z"}	2021-09-01 19:45:27.357982+00	
00000000-0000-0000-0000-000000000000	2f377be9-7540-4c6a-b41c-4e689c29dba7	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T19:46:06Z"}	2021-09-01 19:46:06.989375+00	
00000000-0000-0000-0000-000000000000	1e3c4830-eba7-46f6-9622-8f260456edb9	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T19:53:50Z"}	2021-09-01 19:53:50.292338+00	
00000000-0000-0000-0000-000000000000	03692aa4-cd2f-45b7-b9fd-4b2aa1ec9f2c	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T19:55:02Z"}	2021-09-01 19:55:02.528318+00	
00000000-0000-0000-0000-000000000000	ae416f88-884f-4cdb-b78e-2c44ad39603c	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T19:55:24Z"}	2021-09-01 19:55:24.630623+00	
00000000-0000-0000-0000-000000000000	e8feba05-06a5-4ea2-8f8b-8b0609399fea	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T20:13:08Z"}	2021-09-01 20:13:08.815436+00	
00000000-0000-0000-0000-000000000000	002e067a-bf7e-4f22-b35a-8170b6676f15	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-01T21:14:00Z"}	2021-09-01 21:14:00.262662+00	
00000000-0000-0000-0000-000000000000	f35da923-6e96-4569-bf73-391aafe380d4	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-01T21:14:00Z"}	2021-09-01 21:14:00.26378+00	
00000000-0000-0000-0000-000000000000	3b15e50a-5933-47d6-a7d3-a9de4009b8aa	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-01T22:13:08Z"}	2021-09-01 22:13:08.822281+00	
00000000-0000-0000-0000-000000000000	ce5977f0-9b78-45ec-a44a-6ef59476ecfc	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-01T22:13:08Z"}	2021-09-01 22:13:08.823298+00	
00000000-0000-0000-0000-000000000000	4f289d06-f952-41d1-a3d5-f489ddf34dd8	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-01T23:01:41Z"}	2021-09-01 23:01:41.119073+00	
00000000-0000-0000-0000-000000000000	4b3a408e-b7f9-4f83-bea8-29a6590685a5	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-01T23:01:41Z"}	2021-09-01 23:01:41.120088+00	
00000000-0000-0000-0000-000000000000	ad63ddaa-d4e0-451d-b276-ea6470435a1b	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T23:01:56Z"}	2021-09-01 23:01:56.305926+00	
00000000-0000-0000-0000-000000000000	a2a7b285-98a0-4861-88cd-c87a58792951	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T23:02:00Z"}	2021-09-01 23:02:00.922545+00	
00000000-0000-0000-0000-000000000000	2e2b8016-cf03-4e17-bbdb-e16405fc9914	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T23:02:11Z"}	2021-09-01 23:02:11.656999+00	
00000000-0000-0000-0000-000000000000	0d094c61-c7c0-4d5c-ac97-e96e166230a3	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-01T23:02:34Z"}	2021-09-01 23:02:34.413033+00	
00000000-0000-0000-0000-000000000000	7cc5a178-46dc-4db6-aa86-e97e1b05959e	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-02T00:01:33Z"}	2021-09-02 00:01:33.8177+00	
00000000-0000-0000-0000-000000000000	86188180-8361-499a-a8eb-1df3ee5b4cef	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-02T00:01:33Z"}	2021-09-02 00:01:33.81873+00	
00000000-0000-0000-0000-000000000000	c277c273-7017-461f-a892-fcb16c4d802b	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-02T01:30:58Z"}	2021-09-02 01:30:58.345471+00	
00000000-0000-0000-0000-000000000000	3ebdc382-eb8d-4779-a738-609c2aa0802e	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-02T01:30:58Z"}	2021-09-02 01:30:58.346464+00	
00000000-0000-0000-0000-000000000000	64ccd04d-5e7c-4054-a392-f4b2783badf3	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T01:53:17Z"}	2021-09-02 01:53:17.69393+00	
00000000-0000-0000-0000-000000000000	0c749080-82cd-459a-bba9-8368303968e7	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T02:01:32Z"}	2021-09-02 02:01:32.600481+00	
00000000-0000-0000-0000-000000000000	c3b5d308-bfe3-44a7-8b32-535640262d94	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-02T03:01:49Z"}	2021-09-02 03:01:49.86491+00	
00000000-0000-0000-0000-000000000000	c51a6285-ecd9-4825-a853-6b1cab63a0d6	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-02T03:01:49Z"}	2021-09-02 03:01:49.865919+00	
00000000-0000-0000-0000-000000000000	ccbb6501-c35a-400b-98dd-06f5e85df9ac	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T03:13:16Z"}	2021-09-02 03:13:16.247646+00	
00000000-0000-0000-0000-000000000000	8a1034b2-da62-4e42-bb9c-16e0457e6e28	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T03:25:38Z"}	2021-09-02 03:25:38.679967+00	
00000000-0000-0000-0000-000000000000	7a7e6e35-598f-429c-bbdb-56b9cd9b23b7	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T03:38:05Z"}	2021-09-02 03:38:05.128795+00	
00000000-0000-0000-0000-000000000000	f135ba0a-19f9-414a-8e2f-cb0e3586ea5e	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T03:38:36Z"}	2021-09-02 03:38:36.65945+00	
00000000-0000-0000-0000-000000000000	c41a20bc-828d-43b8-bcec-f94266c2ad1c	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T03:39:14Z"}	2021-09-02 03:39:14.833225+00	
00000000-0000-0000-0000-000000000000	2e142598-87c7-425b-9a41-21227d314375	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T03:39:26Z"}	2021-09-02 03:39:26.495161+00	
00000000-0000-0000-0000-000000000000	2508d2e5-3c24-47e9-ac26-638365d29178	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T03:39:34Z"}	2021-09-02 03:39:34.403508+00	
00000000-0000-0000-0000-000000000000	f8434f61-5b13-4675-a745-3170e3f3a4f5	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T03:39:48Z"}	2021-09-02 03:39:48.742646+00	
00000000-0000-0000-0000-000000000000	7cdba64a-20cb-4de1-8e8c-c569b21220e9	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T04:32:22Z"}	2021-09-02 04:32:22.52827+00	
00000000-0000-0000-0000-000000000000	67609688-a327-4f0c-93f8-c919fc26d7e6	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T04:33:21Z"}	2021-09-02 04:33:21.931445+00	
00000000-0000-0000-0000-000000000000	278006e9-15bb-4d50-a074-87c8436ab8de	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T04:33:38Z"}	2021-09-02 04:33:38.040659+00	
00000000-0000-0000-0000-000000000000	169ff020-011f-4d71-9521-0024cbd64b6d	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T04:37:20Z"}	2021-09-02 04:37:20.489492+00	
00000000-0000-0000-0000-000000000000	ec0b016e-b869-4c67-a482-20a4772504c8	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T04:40:49Z"}	2021-09-02 04:40:49.259753+00	
00000000-0000-0000-0000-000000000000	f87fed74-934c-4a6b-82c1-c216cfe997bc	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T04:44:25Z"}	2021-09-02 04:44:25.436118+00	
00000000-0000-0000-0000-000000000000	c7b4b4c3-6027-4bd4-8731-081a9ab60d7d	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T04:44:46Z"}	2021-09-02 04:44:46.975285+00	
00000000-0000-0000-0000-000000000000	5cb520a6-5329-4cec-8cff-4ce0d989378a	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T04:45:13Z"}	2021-09-02 04:45:13.408275+00	
00000000-0000-0000-0000-000000000000	5d045e2b-0013-4c9c-b81d-dea2e8146b9a	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T04:45:18Z"}	2021-09-02 04:45:18.699653+00	
00000000-0000-0000-0000-000000000000	5aa28618-9252-4eb8-aa81-e2ad0ac97ecf	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T04:45:28Z"}	2021-09-02 04:45:28.701781+00	
00000000-0000-0000-0000-000000000000	dcd4d302-5d94-4b95-b8df-4b4fbd730340	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T04:45:32Z"}	2021-09-02 04:45:32.075161+00	
00000000-0000-0000-0000-000000000000	a094cfa6-4061-4e3e-8719-1ae341013b6e	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T04:45:36Z"}	2021-09-02 04:45:36.713151+00	
00000000-0000-0000-0000-000000000000	60327ad1-aa96-4fdc-8dec-04a6a3d16068	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T04:45:43Z"}	2021-09-02 04:45:43.408064+00	
00000000-0000-0000-0000-000000000000	2f847c5c-6726-48d1-85db-fc66a20eca88	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T04:47:09Z"}	2021-09-02 04:47:09.715912+00	
00000000-0000-0000-0000-000000000000	ad484afb-71e4-449d-91cb-de89e2993f83	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T04:47:15Z"}	2021-09-02 04:47:15.070442+00	
00000000-0000-0000-0000-000000000000	b297f1d0-e7c3-4401-8317-010b85837c2a	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T04:48:04Z"}	2021-09-02 04:48:04.879289+00	
00000000-0000-0000-0000-000000000000	e54b76b3-f2db-4860-bd59-a49dff792758	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T04:48:08Z"}	2021-09-02 04:48:08.858367+00	
00000000-0000-0000-0000-000000000000	cfa9e462-000c-4338-86ca-e196e99454d5	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T15:27:25Z"}	2021-09-02 15:27:25.946943+00	
00000000-0000-0000-0000-000000000000	87beee30-929e-4fcd-9acd-92f157134590	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T15:29:35Z"}	2021-09-02 15:29:35.762178+00	
00000000-0000-0000-0000-000000000000	a4a18560-0ddd-49fa-8080-167274e9d065	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T15:30:34Z"}	2021-09-02 15:30:34.17792+00	
00000000-0000-0000-0000-000000000000	016d735d-843c-448a-87c6-3ca47156cc70	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T15:31:38Z"}	2021-09-02 15:31:38.30012+00	
00000000-0000-0000-0000-000000000000	ec5f4126-bf20-4397-b150-510f33801951	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T15:31:46Z"}	2021-09-02 15:31:46.452602+00	
00000000-0000-0000-0000-000000000000	c4940605-b9d2-46cb-86c9-b7e05e5a9235	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T15:33:36Z"}	2021-09-02 15:33:36.232173+00	
00000000-0000-0000-0000-000000000000	02786b63-ca9d-4780-953d-4a12663b6c8e	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T15:33:39Z"}	2021-09-02 15:33:39.082569+00	
00000000-0000-0000-0000-000000000000	846c9b05-7b5c-49d3-a9d6-1345d29f053c	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T16:05:16Z"}	2021-09-02 16:05:16.386902+00	
00000000-0000-0000-0000-000000000000	d3296866-3aad-405f-97f5-05c9175e0a80	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T16:18:28Z"}	2021-09-02 16:18:28.238331+00	
00000000-0000-0000-0000-000000000000	4b55beca-785f-43da-8559-427269f2c841	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T16:19:05Z"}	2021-09-02 16:19:05.94608+00	
00000000-0000-0000-0000-000000000000	4311cc31-3bcb-404a-b2e8-c029dacfddd3	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T16:20:06Z"}	2021-09-02 16:20:06.596806+00	
00000000-0000-0000-0000-000000000000	d2440af7-309b-4f3e-9b86-5da0774caf7a	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T16:28:23Z"}	2021-09-02 16:28:23.350105+00	
00000000-0000-0000-0000-000000000000	1bce28b9-a26b-47e8-95c4-0069e985adb0	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T16:28:33Z"}	2021-09-02 16:28:33.32148+00	
00000000-0000-0000-0000-000000000000	dd484935-2be8-4c69-abae-36b49b9fa5e5	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T16:51:10Z"}	2021-09-02 16:51:10.998443+00	
00000000-0000-0000-0000-000000000000	f62ecb9a-902c-42df-996d-8d0b56a98591	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T16:51:14Z"}	2021-09-02 16:51:14.988372+00	
00000000-0000-0000-0000-000000000000	11f1dc5e-fa60-4918-a190-33a3939c6c01	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T16:54:21Z"}	2021-09-02 16:54:21.651535+00	
00000000-0000-0000-0000-000000000000	847c3ce9-e092-4683-af83-bd9bdec881e6	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T16:55:24Z"}	2021-09-02 16:55:24.414852+00	
00000000-0000-0000-0000-000000000000	b4a5e286-4a6f-4435-944a-d383f18b405b	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-02T19:11:15Z"}	2021-09-02 19:11:15.635398+00	
00000000-0000-0000-0000-000000000000	227e3c6c-3ef3-4f40-80fa-3f5e1a29b51d	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-02T19:11:15Z"}	2021-09-02 19:11:15.636643+00	
00000000-0000-0000-0000-000000000000	26011d5a-9d3d-4a76-a539-5bed69a40912	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-02T20:12:01Z"}	2021-09-02 20:12:01.726941+00	
00000000-0000-0000-0000-000000000000	3d29b998-df9a-4d6f-b79b-2a9e0b037f9d	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-02T20:12:01Z"}	2021-09-02 20:12:01.728063+00	
00000000-0000-0000-0000-000000000000	67932a0b-f3e4-4c8f-abba-4b6a9cf1fed7	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-02T21:11:02Z"}	2021-09-02 21:11:02.301322+00	
00000000-0000-0000-0000-000000000000	41cc82e0-ff1f-440f-9348-d72f182866f8	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-02T21:11:02Z"}	2021-09-02 21:11:02.30229+00	
00000000-0000-0000-0000-000000000000	bc054c84-7c1b-416f-8bdf-83185c81e914	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-02T22:10:01Z"}	2021-09-02 22:10:01.930343+00	
00000000-0000-0000-0000-000000000000	ddc0dc17-dc41-4f89-9e85-15b16d28f16a	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-02T22:10:01Z"}	2021-09-02 22:10:01.931354+00	
00000000-0000-0000-0000-000000000000	a275fc29-24f1-4e4d-a236-261989e399d8	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T22:38:15Z"}	2021-09-02 22:38:15.922109+00	
00000000-0000-0000-0000-000000000000	db21384e-71b0-4fa6-b235-b9146ed53524	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T22:41:15Z"}	2021-09-02 22:41:15.244478+00	
00000000-0000-0000-0000-000000000000	0e3d2134-2db8-400d-9d51-6b81996467e8	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-02T23:40:14Z"}	2021-09-02 23:40:14.680084+00	
00000000-0000-0000-0000-000000000000	0b0bdf81-da59-42d5-ace8-16f56bd5bcc2	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-02T23:40:14Z"}	2021-09-02 23:40:14.681108+00	
00000000-0000-0000-0000-000000000000	4fec5541-1f6e-46a1-8a60-153280a969eb	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T23:41:08Z"}	2021-09-02 23:41:08.07361+00	
00000000-0000-0000-0000-000000000000	a6a91e38-d005-4f41-99b8-a9cef9cce9cf	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T23:42:46Z"}	2021-09-02 23:42:46.547597+00	
00000000-0000-0000-0000-000000000000	c08c014d-9826-48ce-8997-5bd5a56ab472	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T23:43:04Z"}	2021-09-02 23:43:04.504158+00	
00000000-0000-0000-0000-000000000000	4b9b2af2-b3c4-444b-aad9-83cad1c4bbcb	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T23:43:15Z"}	2021-09-02 23:43:15.226938+00	
00000000-0000-0000-0000-000000000000	0dffa417-c570-413f-b4bd-360d6f4f34b9	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T23:44:25Z"}	2021-09-02 23:44:25.716015+00	
00000000-0000-0000-0000-000000000000	3fd2b432-d3d9-439c-81fe-a2e5234d1cdf	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-02T23:44:49Z"}	2021-09-02 23:44:49.213352+00	
00000000-0000-0000-0000-000000000000	533f9303-488c-4aae-a462-d27ff1c68675	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-03T02:42:58Z"}	2021-09-03 02:42:58.097463+00	
00000000-0000-0000-0000-000000000000	3de0c55a-0151-4891-a31d-15458462768d	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T02:50:01Z"}	2021-09-03 02:50:01.54445+00	
00000000-0000-0000-0000-000000000000	ee355bfe-3955-48c4-863d-cff9f2f9ab40	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T02:50:01Z"}	2021-09-03 02:50:01.546092+00	
00000000-0000-0000-0000-000000000000	b4edbca0-2d16-4ff6-a96a-486f495b7539	{"action":"user_confirmation_requested","actor_id":"10059d53-1fb5-4200-acf0-6d31b44056fe","actor_username":"maria.nattestad@gmail.com","log_type":"user","timestamp":"2021-09-03T02:53:04Z"}	2021-09-03 02:53:04.873495+00	
00000000-0000-0000-0000-000000000000	34aa3d5f-6225-454b-b5ee-105739bf7d09	{"action":"user_confirmation_requested","actor_id":"c661f0e6-f87d-4782-827a-bfbb2de14b6f","actor_username":"lunexa@gmail.com","log_type":"user","timestamp":"2021-09-03T02:55:20Z"}	2021-09-03 02:55:20.357273+00	
00000000-0000-0000-0000-000000000000	539f521a-6f1b-4bb2-95dc-9c6ea4625688	{"action":"user_signedup","actor_id":"c661f0e6-f87d-4782-827a-bfbb2de14b6f","actor_username":"lunexa@gmail.com","log_type":"team","timestamp":"2021-09-03T02:55:50Z"}	2021-09-03 02:55:50.865819+00	
00000000-0000-0000-0000-000000000000	5a837e9c-1087-4f2e-991a-98a6d4e4d71f	{"action":"login","actor_id":"c661f0e6-f87d-4782-827a-bfbb2de14b6f","actor_username":"lunexa@gmail.com","log_type":"account","timestamp":"2021-09-03T02:56:01Z"}	2021-09-03 02:56:01.586782+00	
00000000-0000-0000-0000-000000000000	9d6b4807-7e67-4849-91cb-2b27b4b205ff	{"action":"logout","actor_id":"c661f0e6-f87d-4782-827a-bfbb2de14b6f","actor_username":"lunexa@gmail.com","log_type":"account","timestamp":"2021-09-03T02:57:59Z"}	2021-09-03 02:57:59.915815+00	
00000000-0000-0000-0000-000000000000	7c0f29c4-6f3f-407e-a056-f13e905c94d1	{"action":"login","actor_id":"c661f0e6-f87d-4782-827a-bfbb2de14b6f","actor_username":"lunexa@gmail.com","log_type":"account","timestamp":"2021-09-03T02:58:08Z"}	2021-09-03 02:58:08.483632+00	
00000000-0000-0000-0000-000000000000	959da13b-bdbc-4e4f-acd6-b6f3983be041	{"action":"logout","actor_id":"c661f0e6-f87d-4782-827a-bfbb2de14b6f","actor_username":"lunexa@gmail.com","log_type":"account","timestamp":"2021-09-03T02:58:18Z"}	2021-09-03 02:58:18.973071+00	
00000000-0000-0000-0000-000000000000	5d4a7ee7-19c2-4fb5-8265-034e678c4c87	{"action":"login","actor_id":"c661f0e6-f87d-4782-827a-bfbb2de14b6f","actor_username":"lunexa@gmail.com","log_type":"account","timestamp":"2021-09-03T02:59:39Z"}	2021-09-03 02:59:39.826863+00	
00000000-0000-0000-0000-000000000000	4991647b-92d7-4494-bb84-221feac4a41b	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T03:49:03Z"}	2021-09-03 03:49:03.095341+00	
00000000-0000-0000-0000-000000000000	e68e052e-2aac-469b-978a-282a2ab72b68	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T03:49:03Z"}	2021-09-03 03:49:03.096343+00	
00000000-0000-0000-0000-000000000000	f0d66921-a9a8-4ba6-ba72-fe15ce799219	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T05:06:10Z"}	2021-09-03 05:06:10.013044+00	
00000000-0000-0000-0000-000000000000	99c07369-f329-4435-a1da-47bdcadc6e14	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T05:06:10Z"}	2021-09-03 05:06:10.013992+00	
00000000-0000-0000-0000-000000000000	832b6f76-0be5-4c93-a2f3-36f5cb5c99f8	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T15:56:31Z"}	2021-09-03 15:56:31.02212+00	
00000000-0000-0000-0000-000000000000	95fa6db3-15a8-4db7-9d98-4b0aa4ce4816	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T15:56:31Z"}	2021-09-03 15:56:31.024791+00	
00000000-0000-0000-0000-000000000000	fced4e65-575e-448c-9d30-7d85f634a284	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T16:55:30Z"}	2021-09-03 16:55:30.73791+00	
00000000-0000-0000-0000-000000000000	0e454061-97d2-4705-9e18-637184784ecd	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T16:55:30Z"}	2021-09-03 16:55:30.738886+00	
00000000-0000-0000-0000-000000000000	8f7fd17d-c272-470b-8332-e75bcccdf4af	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T17:54:49Z"}	2021-09-03 17:54:49.679947+00	
00000000-0000-0000-0000-000000000000	fc16a5af-7c24-4733-90ee-1f8b4ea16ed1	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T17:54:49Z"}	2021-09-03 17:54:49.681099+00	
00000000-0000-0000-0000-000000000000	13cbabb6-2423-45cb-962c-61643cf17441	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T19:29:20Z"}	2021-09-03 19:29:20.145148+00	
00000000-0000-0000-0000-000000000000	3ddc5518-dde7-45bc-ae41-c9529a9aac60	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T19:29:20Z"}	2021-09-03 19:29:20.146167+00	
00000000-0000-0000-0000-000000000000	5f560ea1-b100-4d14-bf6f-0277535ee5f1	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T20:28:20Z"}	2021-09-03 20:28:20.560561+00	
00000000-0000-0000-0000-000000000000	a6617304-e08a-4d5a-a54e-10c248a63699	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T20:28:20Z"}	2021-09-03 20:28:20.561549+00	
00000000-0000-0000-0000-000000000000	99688420-06ee-4db9-99ab-730ccc030ee0	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T21:27:21Z"}	2021-09-03 21:27:21.586345+00	
00000000-0000-0000-0000-000000000000	f87f06a3-68fd-44ef-a7cd-2648e6bbf5fe	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T21:27:21Z"}	2021-09-03 21:27:21.587319+00	
00000000-0000-0000-0000-000000000000	ed6bbcff-ab69-406d-a7ee-52ad275399df	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T22:26:23Z"}	2021-09-03 22:26:23.434084+00	
00000000-0000-0000-0000-000000000000	66a38087-2ee2-43cd-8dc8-a79ebfc30622	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T22:26:23Z"}	2021-09-03 22:26:23.435183+00	
00000000-0000-0000-0000-000000000000	ed9dbe78-98e6-4e5d-9f99-a998cabb1df1	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T23:25:23Z"}	2021-09-03 23:25:23.049823+00	
00000000-0000-0000-0000-000000000000	85308bdf-3371-485d-9187-d80e3562915b	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-03T23:25:23Z"}	2021-09-03 23:25:23.050891+00	
00000000-0000-0000-0000-000000000000	ab3c2f0a-4a7e-4b50-9034-4856759a9712	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-04T01:26:35Z"}	2021-09-04 01:26:35.179455+00	
00000000-0000-0000-0000-000000000000	d7e6ec92-f8d7-4f7c-b89a-c9281da0ce47	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-04T01:26:35Z"}	2021-09-04 01:26:35.180661+00	
00000000-0000-0000-0000-000000000000	153cccf4-4257-4223-a107-b7e0fea829c3	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-04T04:00:09Z"}	2021-09-04 04:00:09.441591+00	
00000000-0000-0000-0000-000000000000	73ef5eba-3b6e-4df4-83b0-fb8a48adba9b	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-04T04:00:09Z"}	2021-09-04 04:00:09.442547+00	
00000000-0000-0000-0000-000000000000	7122faff-18b9-4b19-ace8-b65a00723bc7	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-04T04:59:20Z"}	2021-09-04 04:59:20.777077+00	
00000000-0000-0000-0000-000000000000	a1b5cef7-e76f-4db5-aa74-5f4ceb4f08ab	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-04T04:59:20Z"}	2021-09-04 04:59:20.778046+00	
00000000-0000-0000-0000-000000000000	a53b0ea5-3351-413e-86c1-7ba2c4e4bece	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-04T12:49:26Z"}	2021-09-04 12:49:26.719649+00	
00000000-0000-0000-0000-000000000000	d64088fa-1016-4fa9-86d5-50ac1ee86364	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-04T12:49:26Z"}	2021-09-04 12:49:26.720659+00	
00000000-0000-0000-0000-000000000000	f13f0193-af4d-42aa-b851-fae7875eeac2	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-04T14:04:45Z"}	2021-09-04 14:04:45.981392+00	
00000000-0000-0000-0000-000000000000	2187d93e-f362-4b15-88e4-f16f4750d912	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-04T14:04:45Z"}	2021-09-04 14:04:45.984313+00	
00000000-0000-0000-0000-000000000000	641b933f-c934-47cf-8d94-4c441aaa6f47	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-04T15:07:52Z"}	2021-09-04 15:07:52.26065+00	
00000000-0000-0000-0000-000000000000	54592b4f-efbf-4c0e-91a8-035fde206b00	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-04T15:07:52Z"}	2021-09-04 15:07:52.261604+00	
00000000-0000-0000-0000-000000000000	d0660024-561e-40dc-bf4e-0d237d0c059f	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-04T21:38:28Z"}	2021-09-04 21:38:28.399064+00	
00000000-0000-0000-0000-000000000000	f1870a09-d3e9-459b-b745-6b09a95ff6cc	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-04T21:38:28Z"}	2021-09-04 21:38:28.400105+00	
00000000-0000-0000-0000-000000000000	435cce31-950a-4d38-9ace-39b6d330970a	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-04T22:50:31Z"}	2021-09-04 22:50:31.351357+00	
00000000-0000-0000-0000-000000000000	67fc7db0-6e95-4bf3-9e6c-b9fecef9426e	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-04T22:50:31Z"}	2021-09-04 22:50:31.352378+00	
00000000-0000-0000-0000-000000000000	d35e39df-e2dd-4962-84f0-847d16aa9a71	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-04T23:49:32Z"}	2021-09-04 23:49:32.235112+00	
00000000-0000-0000-0000-000000000000	b3ec20c5-4716-4a46-941b-06053b44ab32	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-04T23:49:32Z"}	2021-09-04 23:49:32.236148+00	
00000000-0000-0000-0000-000000000000	19757d6d-2950-4c36-85f9-8a21afff19c3	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-05T13:44:45Z"}	2021-09-05 13:44:45.631128+00	
00000000-0000-0000-0000-000000000000	210e617e-ea12-46ac-8d10-67807ea6fd6b	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-05T13:44:45Z"}	2021-09-05 13:44:45.635176+00	
00000000-0000-0000-0000-000000000000	34c7263e-c0bd-4cde-b6b8-c2ed2bac0eb7	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-05T15:38:28Z"}	2021-09-05 15:38:28.084372+00	
00000000-0000-0000-0000-000000000000	c8911c3c-3b70-40e9-9695-b55dabe565dc	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-05T15:38:28Z"}	2021-09-05 15:38:28.085349+00	
00000000-0000-0000-0000-000000000000	310ebf87-ce61-4930-aeff-f2be4b12b7bb	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-06T20:52:53Z"}	2021-09-06 20:52:53.198898+00	
00000000-0000-0000-0000-000000000000	71e4f61f-55b6-4259-9afd-54ec857cfb57	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-06T20:52:53Z"}	2021-09-06 20:52:53.203045+00	
00000000-0000-0000-0000-000000000000	dab460e0-1853-437c-b9cc-489959248a5e	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-06T21:57:06Z"}	2021-09-06 21:57:06.770678+00	
00000000-0000-0000-0000-000000000000	73c3b671-27e7-4b6f-85ff-fdf6cba1d437	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-06T22:56:08Z"}	2021-09-06 22:56:08.42681+00	
00000000-0000-0000-0000-000000000000	e09e9abb-4b38-4fbe-ae73-2c716264db00	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-06T22:56:08Z"}	2021-09-06 22:56:08.427835+00	
00000000-0000-0000-0000-000000000000	99387c5f-f87a-412c-aa5f-0680657431d7	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-07T00:54:22Z"}	2021-09-07 00:54:22.660868+00	
00000000-0000-0000-0000-000000000000	2ccaa479-33b8-415e-bac7-2d704f07c012	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-07T00:54:22Z"}	2021-09-07 00:54:22.661862+00	
00000000-0000-0000-0000-000000000000	4c642af8-0129-48bb-b7da-e5ee8a2d66ad	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-07T02:26:38Z"}	2021-09-07 02:26:38.961827+00	
00000000-0000-0000-0000-000000000000	a5f4f6ce-5614-4495-9681-3e1a94058d20	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-07T02:26:38Z"}	2021-09-07 02:26:38.962955+00	
00000000-0000-0000-0000-000000000000	c58207d3-cc26-4257-973a-0bf4e0e7923e	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-07T02:45:45Z"}	2021-09-07 02:45:45.508796+00	
00000000-0000-0000-0000-000000000000	9398650a-da96-410f-a88e-50a317395e47	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-07T04:05:42Z"}	2021-09-07 04:05:42.68741+00	
00000000-0000-0000-0000-000000000000	4487d607-5d8f-462e-8a04-d344e332aad0	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-07T17:29:32Z"}	2021-09-07 17:29:32.452814+00	
00000000-0000-0000-0000-000000000000	ae6ace8f-3fb6-4b2a-ba00-8004efa598da	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-07T17:29:32Z"}	2021-09-07 17:29:32.457086+00	
00000000-0000-0000-0000-000000000000	3678039a-fdb8-4a3f-8839-ccc26883d3d0	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-07T18:28:33Z"}	2021-09-07 18:28:33.368399+00	
00000000-0000-0000-0000-000000000000	a89f9757-6180-4b9e-b584-b35e7039044f	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-07T18:28:33Z"}	2021-09-07 18:28:33.369374+00	
00000000-0000-0000-0000-000000000000	483af582-1977-4993-a921-323ebecd9003	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-07T19:34:47Z"}	2021-09-07 19:34:47.403181+00	
00000000-0000-0000-0000-000000000000	7faf66de-f17c-4ec3-a25b-c2ea7854440c	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-07T19:34:47Z"}	2021-09-07 19:34:47.404269+00	
00000000-0000-0000-0000-000000000000	c3f8f990-9ef2-4cc6-90cc-84c7e1d0aad8	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-07T19:35:05Z"}	2021-09-07 19:35:05.857502+00	
00000000-0000-0000-0000-000000000000	7d6b5aa9-08e3-4696-a396-a93771de666f	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-07T19:35:13Z"}	2021-09-07 19:35:13.821871+00	
00000000-0000-0000-0000-000000000000	256e7d78-6d44-434c-affe-bcc02fda7d3e	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-07T19:35:32Z"}	2021-09-07 19:35:32.111769+00	
00000000-0000-0000-0000-000000000000	8c985059-7df8-4e3e-9217-b7697d16d49a	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-07T19:36:31Z"}	2021-09-07 19:36:31.995215+00	
00000000-0000-0000-0000-000000000000	cfad3bf7-47a8-44d8-bb79-435d9aa790a0	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-07T19:42:50Z"}	2021-09-07 19:42:50.785151+00	
00000000-0000-0000-0000-000000000000	0075ce51-2ff7-4aeb-af54-614bd10da0e1	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-07T19:43:53Z"}	2021-09-07 19:43:53.000588+00	
00000000-0000-0000-0000-000000000000	3e942031-4961-48e5-a0eb-da3c71b4da6b	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-07T20:32:19Z"}	2021-09-07 20:32:19.611302+00	
00000000-0000-0000-0000-000000000000	b9b7714e-46e4-4933-8384-f214f3977c00	{"action":"user_confirmation_requested","actor_id":"a0d6e407-fbfa-4129-9da7-0a4e7e071995","actor_username":"robert.aboukhalil+test@gmail.com","log_type":"user","timestamp":"2021-09-07T20:37:46Z"}	2021-09-07 20:37:46.652926+00	
00000000-0000-0000-0000-000000000000	3294a88d-a4df-4560-abcd-d4d2c84f8860	{"action":"user_confirmation_requested","actor_id":"a0d6e407-fbfa-4129-9da7-0a4e7e071995","actor_username":"robert.aboukhalil+test@gmail.com","log_type":"user","timestamp":"2021-09-07T20:39:07Z"}	2021-09-07 20:39:07.771246+00	
00000000-0000-0000-0000-000000000000	93fe290b-477b-4390-9d92-d691a51885bc	{"action":"token_refreshed","actor_id":"c661f0e6-f87d-4782-827a-bfbb2de14b6f","actor_username":"lunexa@gmail.com","log_type":"token","timestamp":"2021-09-07T23:15:12Z"}	2021-09-07 23:15:12.65477+00	
00000000-0000-0000-0000-000000000000	df3bc74d-4584-4feb-9b75-2fa950fe86bd	{"action":"token_revoked","actor_id":"c661f0e6-f87d-4782-827a-bfbb2de14b6f","actor_username":"lunexa@gmail.com","log_type":"token","timestamp":"2021-09-07T23:15:12Z"}	2021-09-07 23:15:12.655815+00	
00000000-0000-0000-0000-000000000000	bde125d1-5f54-40c0-8378-b27fcfe9b23a	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-08T00:04:17Z"}	2021-09-08 00:04:17.206253+00	
00000000-0000-0000-0000-000000000000	10449e09-bde2-4903-b466-659f846a2e35	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T01:07:22Z"}	2021-09-08 01:07:22.089414+00	
00000000-0000-0000-0000-000000000000	947311c2-1b2e-4c43-94f6-a239532ca030	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T01:07:22Z"}	2021-09-08 01:07:22.090581+00	
00000000-0000-0000-0000-000000000000	593059d7-a335-4f00-ab1c-aa011b31430b	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T14:23:51Z"}	2021-09-08 14:23:51.595834+00	
00000000-0000-0000-0000-000000000000	09aa8ae4-54e2-495f-9b9a-95f43ee5820d	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T14:23:51Z"}	2021-09-08 14:23:51.599096+00	
00000000-0000-0000-0000-000000000000	1205f32b-6f60-48e2-84c9-e45fc4c683ea	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T15:22:53Z"}	2021-09-08 15:22:53.067966+00	
00000000-0000-0000-0000-000000000000	0d0a5266-7f40-4442-bf3e-b0263738ea7c	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T15:22:53Z"}	2021-09-08 15:22:53.06906+00	
00000000-0000-0000-0000-000000000000	1d4f3ab2-c687-4376-912a-64860a48af88	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T16:21:54Z"}	2021-09-08 16:21:54.855502+00	
00000000-0000-0000-0000-000000000000	05c85cb6-67e8-4c1d-9c37-79dc68419b33	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T16:21:54Z"}	2021-09-08 16:21:54.856568+00	
00000000-0000-0000-0000-000000000000	e61eb57d-43bc-44ac-b111-256b7f55f3fc	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-08T17:10:37Z"}	2021-09-08 17:10:37.337486+00	
00000000-0000-0000-0000-000000000000	23a66bc1-cd74-48ee-83fd-7cfc9907e5e5	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-08T17:12:52Z"}	2021-09-08 17:12:52.362858+00	
00000000-0000-0000-0000-000000000000	6e4b008f-3872-499d-acd2-8fb5133cfd26	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T18:22:53Z"}	2021-09-08 18:22:53.560276+00	
00000000-0000-0000-0000-000000000000	dae05bfa-a48f-4793-82b3-02275823caeb	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T18:22:53Z"}	2021-09-08 18:22:53.561363+00	
00000000-0000-0000-0000-000000000000	f03fd14e-cad5-4283-88c8-cbd7a0e189e5	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T19:21:54Z"}	2021-09-08 19:21:54.016246+00	
00000000-0000-0000-0000-000000000000	67b5f6de-1e5c-4bd2-b6aa-bcace2a57b94	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T19:21:54Z"}	2021-09-08 19:21:54.017374+00	
00000000-0000-0000-0000-000000000000	1f518c51-2651-43e4-b7f2-cc6f4cb6502c	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T21:23:10Z"}	2021-09-08 21:23:10.472086+00	
00000000-0000-0000-0000-000000000000	99bbdd30-99a3-42f6-a810-19b36e611161	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T21:23:10Z"}	2021-09-08 21:23:10.473161+00	
00000000-0000-0000-0000-000000000000	0f70fb64-89b1-4612-bdff-7ee9312cb06c	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T22:22:46Z"}	2021-09-08 22:22:46.113773+00	
00000000-0000-0000-0000-000000000000	bd4b991c-34ed-427f-9386-adce07a36e46	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T22:22:46Z"}	2021-09-08 22:22:46.114858+00	
00000000-0000-0000-0000-000000000000	cfe9e56e-2fd2-48b4-a26e-a09742fa4b0a	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T23:21:46Z"}	2021-09-08 23:21:46.982421+00	
00000000-0000-0000-0000-000000000000	1a908667-d4c2-45fb-8fc4-b805c0969af0	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-08T23:21:46Z"}	2021-09-08 23:21:46.98348+00	
00000000-0000-0000-0000-000000000000	a3d851bf-469a-44dd-80c4-b23eda430564	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T00:36:07Z"}	2021-09-09 00:36:07.819979+00	
00000000-0000-0000-0000-000000000000	692a8470-98a6-44f7-b7e6-ca1672069881	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T00:36:07Z"}	2021-09-09 00:36:07.821056+00	
00000000-0000-0000-0000-000000000000	0d7aa63c-5f01-431c-ae78-5d6818754d88	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T03:14:15Z"}	2021-09-09 03:14:15.935282+00	
00000000-0000-0000-0000-000000000000	85d0e1f9-baf0-47a2-b938-d9b5de40b8c9	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T03:14:15Z"}	2021-09-09 03:14:15.93636+00	
00000000-0000-0000-0000-000000000000	6ffab4a5-a575-4b3a-9e7d-327767d6052a	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T04:13:15Z"}	2021-09-09 04:13:15.660263+00	
00000000-0000-0000-0000-000000000000	6fda2597-8223-414b-a0d7-f41dd9f8ad7b	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T04:13:15Z"}	2021-09-09 04:13:15.661466+00	
00000000-0000-0000-0000-000000000000	965df1dc-15aa-41f1-accf-12e6c00f7428	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T14:51:24Z"}	2021-09-09 14:51:24.08447+00	
00000000-0000-0000-0000-000000000000	2579e33d-c085-45ef-a33c-75cf2f2190cb	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T14:51:24Z"}	2021-09-09 14:51:24.086493+00	
00000000-0000-0000-0000-000000000000	b0b2fb44-8dcd-44e3-ae8a-3f759cc12148	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T15:50:24Z"}	2021-09-09 15:50:24.591825+00	
00000000-0000-0000-0000-000000000000	574aa5d3-9467-4777-9d51-83c2aff81c93	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T15:50:24Z"}	2021-09-09 15:50:24.592838+00	
00000000-0000-0000-0000-000000000000	4ba806d1-5f2c-4501-b220-97a8e37559bf	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T16:49:25Z"}	2021-09-09 16:49:25.498696+00	
00000000-0000-0000-0000-000000000000	8b5bf3c9-b3c6-485b-872e-df12fd48de58	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T16:49:25Z"}	2021-09-09 16:49:25.499708+00	
00000000-0000-0000-0000-000000000000	c19af5ea-d411-4fda-a034-30caa699ac93	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T17:48:40Z"}	2021-09-09 17:48:40.151055+00	
00000000-0000-0000-0000-000000000000	aef30622-c0e4-4509-9666-c049c83e4889	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T17:48:40Z"}	2021-09-09 17:48:40.152162+00	
00000000-0000-0000-0000-000000000000	1d711fc8-31d0-4c4a-abd4-b3bc2027f143	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T19:43:48Z"}	2021-09-09 19:43:48.537859+00	
00000000-0000-0000-0000-000000000000	bf9d0d0a-8ea8-497a-8aa0-8e2976b18dd0	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T19:43:48Z"}	2021-09-09 19:43:48.538922+00	
00000000-0000-0000-0000-000000000000	e1eff840-60db-41de-bd29-b7dc6222a9f6	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T20:42:49Z"}	2021-09-09 20:42:49.605058+00	
00000000-0000-0000-0000-000000000000	f35ac15a-eeb0-41bf-b6b1-1ade176adb9f	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T20:42:49Z"}	2021-09-09 20:42:49.606056+00	
00000000-0000-0000-0000-000000000000	926d9655-7588-450d-b3a7-a7ed43c518a4	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T21:41:54Z"}	2021-09-09 21:41:54.447238+00	
00000000-0000-0000-0000-000000000000	1a6101cf-a7c7-4e8c-b84f-f0ad70be23f0	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T21:41:54Z"}	2021-09-09 21:41:54.448333+00	
00000000-0000-0000-0000-000000000000	8fac6506-e4b4-4cfa-a578-5d3f0069d11e	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T22:40:54Z"}	2021-09-09 22:40:54.561486+00	
00000000-0000-0000-0000-000000000000	4f19e93b-b74b-4c57-97f3-7d3e30b4b778	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-09T22:40:54Z"}	2021-09-09 22:40:54.562578+00	
00000000-0000-0000-0000-000000000000	5ff7baeb-e3db-4189-81e3-20c685569a6a	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T04:28:35Z"}	2021-09-10 04:28:35.788647+00	
00000000-0000-0000-0000-000000000000	b4a4e806-7ffb-4af3-87c8-7ad74da0cc1e	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T04:28:35Z"}	2021-09-10 04:28:35.789741+00	
00000000-0000-0000-0000-000000000000	b4f6a01e-e75f-4fee-84d3-7d34889b94ba	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T13:47:40Z"}	2021-09-10 13:47:40.095096+00	
00000000-0000-0000-0000-000000000000	272b4f6a-549a-46d1-afda-48d15594d841	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T13:47:40Z"}	2021-09-10 13:47:40.099578+00	
00000000-0000-0000-0000-000000000000	5a59cd20-236e-4369-b5c2-481cbe79ed6c	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T14:46:53Z"}	2021-09-10 14:46:53.792076+00	
00000000-0000-0000-0000-000000000000	1b45916f-5bd5-4087-87aa-5e5dfae8d8f7	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T14:46:53Z"}	2021-09-10 14:46:53.793051+00	
00000000-0000-0000-0000-000000000000	ff6005af-9061-4097-8f2b-c1e905717529	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T15:45:54Z"}	2021-09-10 15:45:54.332159+00	
00000000-0000-0000-0000-000000000000	52bbf21e-12f0-4470-a482-a198333cda44	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T15:45:54Z"}	2021-09-10 15:45:54.333304+00	
00000000-0000-0000-0000-000000000000	006aace4-da76-489f-be83-dd6ea6e14f54	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T16:50:42Z"}	2021-09-10 16:50:42.223557+00	
00000000-0000-0000-0000-000000000000	2886dd0d-a0c9-4d28-9fbf-926c3339e0de	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T16:50:42Z"}	2021-09-10 16:50:42.224575+00	
00000000-0000-0000-0000-000000000000	e0073cd4-22a4-4581-83ff-9df8b48fbe5f	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T17:49:42Z"}	2021-09-10 17:49:42.698022+00	
00000000-0000-0000-0000-000000000000	07f6fba2-de05-4ecb-b599-6504a906cf0a	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T17:49:42Z"}	2021-09-10 17:49:42.699068+00	
00000000-0000-0000-0000-000000000000	1659b5ee-8187-466f-88f3-ac1481be3b90	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T19:02:15Z"}	2021-09-10 19:02:15.410368+00	
00000000-0000-0000-0000-000000000000	8c03a73b-362c-40df-9e42-593c9839e51b	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T19:02:15Z"}	2021-09-10 19:02:15.411348+00	
00000000-0000-0000-0000-000000000000	6be7d0dd-4c06-4c09-a3b2-33b24468bfec	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T20:21:57Z"}	2021-09-10 20:21:57.497898+00	
00000000-0000-0000-0000-000000000000	8cdcc1e2-3ce3-4818-9978-fa089d65d080	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T20:21:57Z"}	2021-09-10 20:21:57.498978+00	
00000000-0000-0000-0000-000000000000	33259fa1-5db8-4b75-a064-0d9d8a797506	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T21:21:00Z"}	2021-09-10 21:21:00.082826+00	
00000000-0000-0000-0000-000000000000	213373d9-d5ed-4597-8583-8470b68836e8	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T21:21:00Z"}	2021-09-10 21:21:00.084025+00	
00000000-0000-0000-0000-000000000000	7d549b55-1551-4cb6-9449-b1deb11eb29e	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T22:38:15Z"}	2021-09-10 22:38:15.847802+00	
00000000-0000-0000-0000-000000000000	8889ab27-699d-49f6-aabc-d2a9061dbcac	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T22:38:15Z"}	2021-09-10 22:38:15.848877+00	
00000000-0000-0000-0000-000000000000	8f16c609-2392-4cc9-8a02-95b2de3c5cea	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T23:37:15Z"}	2021-09-10 23:37:15.815571+00	
00000000-0000-0000-0000-000000000000	2e2480eb-563f-4fad-8e8c-f61552e019f1	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-10T23:37:15Z"}	2021-09-10 23:37:15.816615+00	
00000000-0000-0000-0000-000000000000	ce504778-c867-4a02-906b-33c0219abcf4	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-11T00:36:15Z"}	2021-09-11 00:36:15.970012+00	
00000000-0000-0000-0000-000000000000	348753f4-ee7a-4ba3-85d3-198be103d5b3	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-11T00:36:15Z"}	2021-09-11 00:36:15.971017+00	
00000000-0000-0000-0000-000000000000	5452c3cb-ed51-408b-b26e-50bf126a1a7b	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-11T02:27:51Z"}	2021-09-11 02:27:51.038888+00	
00000000-0000-0000-0000-000000000000	9feeca57-8940-472e-ac67-514be569347b	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-11T02:27:51Z"}	2021-09-11 02:27:51.039971+00	
00000000-0000-0000-0000-000000000000	a28524e7-524d-400b-9cdd-67644f0d64c8	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-11T03:26:52Z"}	2021-09-11 03:26:52.283783+00	
00000000-0000-0000-0000-000000000000	6fdaaf51-c05c-4cb6-a37a-70f27d886750	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-11T03:26:52Z"}	2021-09-11 03:26:52.286515+00	
00000000-0000-0000-0000-000000000000	9db816da-7264-449d-92c7-55da5fe9245b	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-11T04:25:53Z"}	2021-09-11 04:25:53.346557+00	
00000000-0000-0000-0000-000000000000	9f141abb-ff5a-4cbd-bcf6-e6934cd3e8df	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-11T04:25:53Z"}	2021-09-11 04:25:53.347668+00	
00000000-0000-0000-0000-000000000000	0d7d9201-4b98-4e13-835e-2185903713ec	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-11T16:12:44Z"}	2021-09-11 16:12:44.9514+00	
00000000-0000-0000-0000-000000000000	243659bf-0ad5-4a26-b0b3-a73a8679c031	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-11T16:12:44Z"}	2021-09-11 16:12:44.954527+00	
00000000-0000-0000-0000-000000000000	7ca0bd70-f436-4f84-9b79-40975a82389f	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-11T17:11:46Z"}	2021-09-11 17:11:46.044046+00	
00000000-0000-0000-0000-000000000000	e5d181b8-96a5-45fb-8560-2464b4caebf5	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-11T17:11:46Z"}	2021-09-11 17:11:46.045354+00	
00000000-0000-0000-0000-000000000000	2941169b-da9c-43fe-b971-429456af3287	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-11T18:10:47Z"}	2021-09-11 18:10:47.414093+00	
00000000-0000-0000-0000-000000000000	09c31491-5697-4ec9-919a-75bc59372882	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-11T18:10:47Z"}	2021-09-11 18:10:47.415317+00	
00000000-0000-0000-0000-000000000000	5992126e-4e52-4b6b-b794-6cca46d1625e	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-11T19:35:52Z"}	2021-09-11 19:35:52.140038+00	
00000000-0000-0000-0000-000000000000	ee45801d-c2d9-4e59-aa4b-d33dab9d2096	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-11T19:35:52Z"}	2021-09-11 19:35:52.141008+00	
00000000-0000-0000-0000-000000000000	e3668339-e0fa-4662-b604-5f6ece2ce8cd	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-11T22:50:20Z"}	2021-09-11 22:50:20.771982+00	
00000000-0000-0000-0000-000000000000	8d13fa03-11a0-437a-bfba-57060db96408	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-11T22:50:20Z"}	2021-09-11 22:50:20.773025+00	
00000000-0000-0000-0000-000000000000	cd461af2-e4b9-4bec-ba8e-1a552ac54a1d	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-11T23:49:21Z"}	2021-09-11 23:49:21.931652+00	
00000000-0000-0000-0000-000000000000	b37ed135-2504-42ca-ae69-53b8f732f561	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-11T23:49:21Z"}	2021-09-11 23:49:21.932878+00	
00000000-0000-0000-0000-000000000000	41b1eda1-2927-418e-a8a3-18608c88fd5c	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-12T00:52:54Z"}	2021-09-12 00:52:54.875825+00	
00000000-0000-0000-0000-000000000000	52e11319-9360-4c34-a8b4-ec5f80fc6ed7	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-12T00:52:54Z"}	2021-09-12 00:52:54.876833+00	
00000000-0000-0000-0000-000000000000	971b633f-b59c-4944-bdbf-9df7fbd03e89	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-12T01:57:02Z"}	2021-09-12 01:57:02.623847+00	
00000000-0000-0000-0000-000000000000	17d02b63-9979-45c7-af71-6cf0bda02fb9	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-12T01:57:02Z"}	2021-09-12 01:57:02.62494+00	
00000000-0000-0000-0000-000000000000	028cd3b4-71c2-4b66-9afd-04db11c01db2	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-12T05:19:59Z"}	2021-09-12 05:19:59.457946+00	
00000000-0000-0000-0000-000000000000	6cd92b98-7ea8-4e66-9735-a389eb9472df	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-12T05:19:59Z"}	2021-09-12 05:19:59.459122+00	
00000000-0000-0000-0000-000000000000	8791ebb6-fdb9-4920-976e-486016e6697c	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-12T14:57:24Z"}	2021-09-12 14:57:24.951893+00	
00000000-0000-0000-0000-000000000000	782bbd3f-52f3-48fd-a69d-0d41a5dd2911	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-12T14:57:24Z"}	2021-09-12 14:57:24.954982+00	
00000000-0000-0000-0000-000000000000	dc9ea9fe-9075-49f4-9626-dc962b5f2d33	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-12T15:56:25Z"}	2021-09-12 15:56:25.429948+00	
00000000-0000-0000-0000-000000000000	e01bc745-0d37-4966-82e6-3fac8dd4909a	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-12T15:56:25Z"}	2021-09-12 15:56:25.430931+00	
00000000-0000-0000-0000-000000000000	9f2b25d8-c78e-4490-b90a-952256eb862c	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-12T16:55:24Z"}	2021-09-12 16:55:24.779509+00	
00000000-0000-0000-0000-000000000000	a9b86a02-a897-49c6-843d-914ec906fc3b	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-12T16:55:24Z"}	2021-09-12 16:55:24.780654+00	
00000000-0000-0000-0000-000000000000	3a0369f5-56d3-4d6c-a36c-6753765c4c2d	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-12T20:47:03Z"}	2021-09-12 20:47:03.342214+00	
00000000-0000-0000-0000-000000000000	b25572d8-e773-4c3e-bf49-bb3e700ae2d6	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-12T20:47:03Z"}	2021-09-12 20:47:03.343317+00	
00000000-0000-0000-0000-000000000000	c97e2ed5-6aac-41c7-ba47-d4bfa5f8df1d	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-12T21:46:03Z"}	2021-09-12 21:46:03.312417+00	
00000000-0000-0000-0000-000000000000	b55f3f33-312a-4279-b7a9-20db398187b8	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-12T21:46:03Z"}	2021-09-12 21:46:03.313394+00	
00000000-0000-0000-0000-000000000000	8a54abe6-26de-4bdf-a27b-745d3f5019f4	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-12T23:00:33Z"}	2021-09-12 23:00:33.664678+00	
00000000-0000-0000-0000-000000000000	a3200650-66c9-4708-a7fd-69561b8caf68	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-12T23:00:33Z"}	2021-09-12 23:00:33.665761+00	
00000000-0000-0000-0000-000000000000	8afaccf2-a5ab-4d22-8f68-efc3699039c8	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-12T23:59:33Z"}	2021-09-12 23:59:33.892652+00	
00000000-0000-0000-0000-000000000000	c8cf58b5-b694-447b-80a6-da50adbd2bc3	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-12T23:59:33Z"}	2021-09-12 23:59:33.893825+00	
00000000-0000-0000-0000-000000000000	e881e5f5-e6fe-42af-8353-fa6c27fe25c0	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-13T00:58:34Z"}	2021-09-13 00:58:34.026563+00	
00000000-0000-0000-0000-000000000000	87266ae6-36e1-45e5-b573-2e75beabd965	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-13T00:58:34Z"}	2021-09-13 00:58:34.027615+00	
00000000-0000-0000-0000-000000000000	8eace30e-a6a8-4bef-8966-2356b9cacd36	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-13T03:29:28Z"}	2021-09-13 03:29:28.389149+00	
00000000-0000-0000-0000-000000000000	1c6e7b98-5b59-4237-9e91-4b33419175bd	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-13T03:29:28Z"}	2021-09-13 03:29:28.390154+00	
00000000-0000-0000-0000-000000000000	c80ad98b-517d-4fdd-9641-c86465cc9b65	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-13T04:28:28Z"}	2021-09-13 04:28:28.010427+00	
00000000-0000-0000-0000-000000000000	caa19f70-925f-4dc3-aaf6-7764359c116b	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-13T04:28:28Z"}	2021-09-13 04:28:28.011416+00	
00000000-0000-0000-0000-000000000000	316071a1-59d8-400f-b47e-6ddc589f1b9f	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-13T05:27:29Z"}	2021-09-13 05:27:29.392843+00	
00000000-0000-0000-0000-000000000000	ee2e123c-aa4f-43b3-bfbd-e890857d8734	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-13T05:27:29Z"}	2021-09-13 05:27:29.393886+00	
00000000-0000-0000-0000-000000000000	94c768e2-bea8-443c-883c-bb485b37b61b	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-13T14:06:15Z"}	2021-09-13 14:06:15.128535+00	
00000000-0000-0000-0000-000000000000	5d4b0bc6-5cbe-46fc-ba1b-1fef2f60cc28	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-13T14:06:15Z"}	2021-09-13 14:06:15.131189+00	
00000000-0000-0000-0000-000000000000	545761e1-ba99-4798-9f83-78400b5a8c07	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-15T02:50:21Z"}	2021-09-15 02:50:21.998544+00	
00000000-0000-0000-0000-000000000000	d7c8189b-691a-4497-b598-2dcf12fedd84	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-15T02:50:22Z"}	2021-09-15 02:50:22.000429+00	
00000000-0000-0000-0000-000000000000	57288b2d-862c-42b5-973d-821c7ea7e688	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-15T03:15:37Z"}	2021-09-15 03:15:37.025018+00	
00000000-0000-0000-0000-000000000000	fe6f3f37-3e33-4b6d-aa64-3461f758fde7	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-18T02:01:47Z"}	2021-09-18 02:01:47.672546+00	
00000000-0000-0000-0000-000000000000	80f88a0a-014b-4d16-b040-34a55c6ca245	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-18T04:26:49Z"}	2021-09-18 04:26:49.815812+00	
00000000-0000-0000-0000-000000000000	5a341558-9fc2-430d-a409-4d873b4c165e	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-18T04:26:49Z"}	2021-09-18 04:26:49.816845+00	
00000000-0000-0000-0000-000000000000	8ebf6b33-3ae7-4f6f-aee0-2b76e7f2d323	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-18T15:22:37Z"}	2021-09-18 15:22:37.121649+00	
00000000-0000-0000-0000-000000000000	6ddcd7bc-99f0-4770-bf0b-575383709b2c	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-18T15:22:37Z"}	2021-09-18 15:22:37.125726+00	
00000000-0000-0000-0000-000000000000	aeb3e69a-27e4-450b-973b-d7565d66fabe	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-18T16:21:47Z"}	2021-09-18 16:21:47.516268+00	
00000000-0000-0000-0000-000000000000	cc1ff36b-8fda-4833-aa5e-5fbd2b0c0eb9	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-18T16:21:47Z"}	2021-09-18 16:21:47.51737+00	
00000000-0000-0000-0000-000000000000	bdd2f1bc-e1e6-41cd-96ac-577ecf0e3221	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-18T17:20:48Z"}	2021-09-18 17:20:48.330316+00	
00000000-0000-0000-0000-000000000000	cbf6083f-bd48-44f0-a4ee-cd49b8dedf7b	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-18T17:20:48Z"}	2021-09-18 17:20:48.331365+00	
00000000-0000-0000-0000-000000000000	880fe5d5-e5ff-4db6-b20c-d4bdb80e09e6	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-18T18:21:21Z"}	2021-09-18 18:21:21.712123+00	
00000000-0000-0000-0000-000000000000	37dfa3fe-2c48-4f2b-b47a-b31e2e2e3148	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-18T18:21:21Z"}	2021-09-18 18:21:21.713156+00	
00000000-0000-0000-0000-000000000000	0ce32874-386d-4914-bfad-7157799fc7f0	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-18T20:28:40Z"}	2021-09-18 20:28:40.442839+00	
00000000-0000-0000-0000-000000000000	cd318eeb-e5d8-451b-b898-3096fdeae646	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-18T20:28:40Z"}	2021-09-18 20:28:40.444864+00	
00000000-0000-0000-0000-000000000000	0503cff9-35f2-4f13-8192-539dbd2884c7	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-18T21:28:15Z"}	2021-09-18 21:28:15.344468+00	
00000000-0000-0000-0000-000000000000	99aab7f7-add7-45be-bc86-418b70a6d9ab	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-18T21:28:15Z"}	2021-09-18 21:28:15.345496+00	
00000000-0000-0000-0000-000000000000	db891cae-f1fe-493f-937e-bf609c4c2789	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-18T22:27:15Z"}	2021-09-18 22:27:15.528809+00	
00000000-0000-0000-0000-000000000000	38a92fb0-eb6f-4c2d-8441-7f7536d25097	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-18T22:27:15Z"}	2021-09-18 22:27:15.529886+00	
00000000-0000-0000-0000-000000000000	0f1fb8a7-071c-4368-851d-96e0698917de	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-18T23:28:25Z"}	2021-09-18 23:28:25.426426+00	
00000000-0000-0000-0000-000000000000	566679df-3db2-48ea-9b42-601aecadee9c	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-18T23:28:25Z"}	2021-09-18 23:28:25.427446+00	
00000000-0000-0000-0000-000000000000	f1287870-4b78-4948-96a8-d05e521eac29	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-19T08:15:04Z"}	2021-09-19 08:15:04.738944+00	
00000000-0000-0000-0000-000000000000	0fc34fef-79fb-458d-b5f0-c17b14a73074	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-19T08:15:04Z"}	2021-09-19 08:15:04.744179+00	
00000000-0000-0000-0000-000000000000	6c182b04-25b3-45b3-9140-fe3538650ed7	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-19T16:54:02Z"}	2021-09-19 16:54:02.133888+00	
00000000-0000-0000-0000-000000000000	2ed14f5f-a6af-4383-9979-a069a78f9a30	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-19T16:54:02Z"}	2021-09-19 16:54:02.134996+00	
00000000-0000-0000-0000-000000000000	d04f7408-f27d-454e-849d-135161df1c61	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-19T17:53:02Z"}	2021-09-19 17:53:02.023554+00	
00000000-0000-0000-0000-000000000000	e685b14f-16fa-47d9-b01f-32bb355ea63b	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-19T17:53:02Z"}	2021-09-19 17:53:02.024627+00	
00000000-0000-0000-0000-000000000000	49370713-eeda-4649-83c6-d5889255a032	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-19T20:56:19Z"}	2021-09-19 20:56:19.171235+00	
00000000-0000-0000-0000-000000000000	63f29388-9ce2-4e25-b119-680797d02ece	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-19T20:56:19Z"}	2021-09-19 20:56:19.171974+00	
00000000-0000-0000-0000-000000000000	28872b7c-b25d-4cdc-bbb7-70434e5e6b5f	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-19T21:55:57Z"}	2021-09-19 21:55:57.164151+00	
00000000-0000-0000-0000-000000000000	711b4ec1-aa74-4def-ae5a-bdb652e1eef0	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-19T21:55:57Z"}	2021-09-19 21:55:57.164841+00	
00000000-0000-0000-0000-000000000000	025cd1a4-adde-4c48-8dd9-6ffc15ebcee9	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-19T23:04:20Z"}	2021-09-19 23:04:20.165269+00	
00000000-0000-0000-0000-000000000000	87d1c304-b257-4d93-a010-b5a30e69c6ca	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-19T23:04:20Z"}	2021-09-19 23:04:20.165982+00	
00000000-0000-0000-0000-000000000000	32d0ebf0-113c-40e5-8a2f-293dcbd88a32	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-20T01:52:36Z"}	2021-09-20 01:52:36.32267+00	
00000000-0000-0000-0000-000000000000	175b13c0-8d8f-40f7-8724-9aef7b96205f	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-20T01:52:36Z"}	2021-09-20 01:52:36.323419+00	
00000000-0000-0000-0000-000000000000	d43e4c74-35ce-4472-ac6f-ecb1cccf335a	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-20T04:00:55Z"}	2021-09-20 04:00:55.224931+00	
00000000-0000-0000-0000-000000000000	36cc01ae-877e-44a0-90cf-205a478b71cb	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-20T04:00:55Z"}	2021-09-20 04:00:55.225683+00	
00000000-0000-0000-0000-000000000000	0b341bca-c17b-483c-a4f8-90ec42d8a13e	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-20T05:00:04Z"}	2021-09-20 05:00:04.527982+00	
00000000-0000-0000-0000-000000000000	f555e61e-35ac-4922-b6b2-c996ed60290e	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-20T05:00:04Z"}	2021-09-20 05:00:04.52875+00	
00000000-0000-0000-0000-000000000000	cbbdc64b-646c-40c0-a5bb-2360dbd73f68	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-20T16:09:12Z"}	2021-09-20 16:09:12.360188+00	
00000000-0000-0000-0000-000000000000	9967e7c6-e55d-4ac9-8461-09802d05908f	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-20T16:09:12Z"}	2021-09-20 16:09:12.363599+00	
00000000-0000-0000-0000-000000000000	5a20bab9-f3ea-4a4a-8f0e-1254932b73df	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-20T17:08:45Z"}	2021-09-20 17:08:45.561258+00	
00000000-0000-0000-0000-000000000000	fed004c8-74b2-4c93-8b13-168b928bc5c3	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-20T17:08:45Z"}	2021-09-20 17:08:45.562049+00	
00000000-0000-0000-0000-000000000000	0039966f-1795-42f3-abe2-946acf4ea160	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-20T18:08:45Z"}	2021-09-20 18:08:45.650597+00	
00000000-0000-0000-0000-000000000000	879162f2-782c-40e7-9a68-0f22f4ba5d94	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-20T18:08:45Z"}	2021-09-20 18:08:45.651497+00	
00000000-0000-0000-0000-000000000000	9d362429-0095-4208-8dd8-ebffe921575a	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-20T19:07:57Z"}	2021-09-20 19:07:57.630236+00	
00000000-0000-0000-0000-000000000000	66b7f14c-17bc-4a25-bc5a-d753fadd42a7	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-20T19:07:57Z"}	2021-09-20 19:07:57.636627+00	
00000000-0000-0000-0000-000000000000	2ac79452-5ec2-4849-b46e-d1615d737de4	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-20T20:07:12Z"}	2021-09-20 20:07:12.950004+00	
00000000-0000-0000-0000-000000000000	03ae1e0b-6198-4588-b1e0-57670e518568	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-20T20:07:12Z"}	2021-09-20 20:07:12.950722+00	
00000000-0000-0000-0000-000000000000	da23a5ad-cc43-4b08-bebb-7b16ed201cb5	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-20T21:06:21Z"}	2021-09-20 21:06:21.404715+00	
00000000-0000-0000-0000-000000000000	2849405c-2c2c-443e-aeec-bf727baaa286	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-20T21:06:21Z"}	2021-09-20 21:06:21.405488+00	
00000000-0000-0000-0000-000000000000	d0b616cf-5196-453e-8667-83f5ef78dfea	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-20T23:03:39Z"}	2021-09-20 23:03:39.840741+00	
00000000-0000-0000-0000-000000000000	fa100692-530b-429e-b764-cdcd71f74192	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-20T23:03:39Z"}	2021-09-20 23:03:39.841512+00	
00000000-0000-0000-0000-000000000000	87b1f1e9-b1e2-4f8e-9796-15ed7fd94b7a	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-21T02:47:49Z"}	2021-09-21 02:47:49.240004+00	
00000000-0000-0000-0000-000000000000	39604eca-e1bf-4947-9731-9428c29ac9a1	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-21T02:47:49Z"}	2021-09-21 02:47:49.240751+00	
00000000-0000-0000-0000-000000000000	e48498d8-5a3c-4c19-9edb-0493ca8c8d83	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-21T04:40:17Z"}	2021-09-21 04:40:17.524307+00	
00000000-0000-0000-0000-000000000000	48f62ccc-5a8f-466e-a608-edf24a54ec9e	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-21T04:40:17Z"}	2021-09-21 04:40:17.525124+00	
00000000-0000-0000-0000-000000000000	160e01c5-7379-473c-95cf-db292cdec1d8	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-21T15:48:25Z"}	2021-09-21 15:48:25.208391+00	
00000000-0000-0000-0000-000000000000	8baa0cf4-03fb-4765-8682-d592e4ef1e5e	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-21T15:48:25Z"}	2021-09-21 15:48:25.209195+00	
00000000-0000-0000-0000-000000000000	7de6bd44-0758-444c-b9ca-f1e7f164d5a5	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-21T16:47:51Z"}	2021-09-21 16:47:51.87083+00	
00000000-0000-0000-0000-000000000000	5d4fbe28-aa22-42c2-89a4-09f43bac8958	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-21T16:47:51Z"}	2021-09-21 16:47:51.871584+00	
00000000-0000-0000-0000-000000000000	cc05b8d1-0706-4260-b346-72926f2e2c0a	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-21T17:47:00Z"}	2021-09-21 17:47:00.708941+00	
00000000-0000-0000-0000-000000000000	605cb3d0-b3dc-4196-b4b7-1d16e166c0d6	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-21T17:47:00Z"}	2021-09-21 17:47:00.709712+00	
00000000-0000-0000-0000-000000000000	370e3f62-9350-46e1-8541-2f4c9af604ad	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-21T19:00:38Z"}	2021-09-21 19:00:38.414566+00	
00000000-0000-0000-0000-000000000000	e9eee787-89f1-4b33-a7ca-7f67135f5619	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-21T19:00:38Z"}	2021-09-21 19:00:38.415288+00	
00000000-0000-0000-0000-000000000000	0548f595-b5c8-4254-b139-3b698a79b136	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-21T20:00:46Z"}	2021-09-21 20:00:46.020431+00	
00000000-0000-0000-0000-000000000000	2c0377f4-b11e-4741-94aa-e4d7e33b4e04	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-21T20:00:46Z"}	2021-09-21 20:00:46.021197+00	
00000000-0000-0000-0000-000000000000	414426b4-2fb6-4ab0-916f-9d84543f0082	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-21T21:00:05Z"}	2021-09-21 21:00:05.535865+00	
00000000-0000-0000-0000-000000000000	3e5c2d9c-2bd5-43b9-83ae-c7f17c9c4bb2	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-21T21:00:05Z"}	2021-09-21 21:00:05.536624+00	
00000000-0000-0000-0000-000000000000	daf7e54a-65e0-483a-a521-4189dbf8b415	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-21T22:00:55Z"}	2021-09-21 22:00:55.324394+00	
00000000-0000-0000-0000-000000000000	9eb5ac05-86c7-4652-9393-a6de18e7cfa8	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-21T22:00:55Z"}	2021-09-21 22:00:55.325121+00	
00000000-0000-0000-0000-000000000000	7d05565d-7365-4a99-9683-4c6fa26961a0	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-21T23:55:21Z"}	2021-09-21 23:55:21.608644+00	
00000000-0000-0000-0000-000000000000	2833efd9-7830-4486-90ad-2f3821f118ea	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-21T23:55:21Z"}	2021-09-21 23:55:21.609382+00	
00000000-0000-0000-0000-000000000000	af1c8868-9391-4137-b947-a842c28eee62	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T02:36:07Z"}	2021-09-22 02:36:07.021846+00	
00000000-0000-0000-0000-000000000000	9afd534b-b734-47c8-b648-51edac8d0eb8	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T02:36:07Z"}	2021-09-22 02:36:07.0226+00	
00000000-0000-0000-0000-000000000000	93de095f-034f-465d-89e0-f813de98a7b1	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T03:52:33Z"}	2021-09-22 03:52:33.774593+00	
00000000-0000-0000-0000-000000000000	bad1d637-387f-4894-a7a4-1bad83739960	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T03:52:33Z"}	2021-09-22 03:52:33.77536+00	
00000000-0000-0000-0000-000000000000	e905a68e-d27e-4b9d-8e42-543706d0cc86	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T14:07:24Z"}	2021-09-22 14:07:24.329993+00	
00000000-0000-0000-0000-000000000000	59019d19-8275-41f0-9612-65a200721e50	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T14:07:24Z"}	2021-09-22 14:07:24.333648+00	
00000000-0000-0000-0000-000000000000	e10a1e3d-cb50-470a-b5a0-fab027ec19c0	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T15:50:40Z"}	2021-09-22 15:50:40.614745+00	
00000000-0000-0000-0000-000000000000	175c0f87-f892-4d7e-b5bc-4bc8d2884c11	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T15:50:40Z"}	2021-09-22 15:50:40.61544+00	
00000000-0000-0000-0000-000000000000	14356d17-54be-4c13-a98d-a42876a718d4	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T16:49:41Z"}	2021-09-22 16:49:41.860717+00	
00000000-0000-0000-0000-000000000000	436f4010-2306-473a-8bb9-84e70ff6c111	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T16:49:41Z"}	2021-09-22 16:49:41.861468+00	
00000000-0000-0000-0000-000000000000	b517edb5-3c77-4dca-9050-cf8adb79ffe9	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T17:48:43Z"}	2021-09-22 17:48:43.637955+00	
00000000-0000-0000-0000-000000000000	86970a42-a434-4aae-b47c-4224809a1f56	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T17:48:43Z"}	2021-09-22 17:48:43.638722+00	
00000000-0000-0000-0000-000000000000	63ae7f69-0f73-4278-901c-86ea16c408de	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T19:08:19Z"}	2021-09-22 19:08:19.864561+00	
00000000-0000-0000-0000-000000000000	15c598ab-ec52-48b7-8392-ad193d77d5bb	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T19:08:19Z"}	2021-09-22 19:08:19.865301+00	
00000000-0000-0000-0000-000000000000	7f8f1081-69ca-4bfe-a4fc-2f8087b97aab	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T20:07:20Z"}	2021-09-22 20:07:20.884452+00	
00000000-0000-0000-0000-000000000000	40442836-0180-4d98-b7bc-d2e32eb2a6fe	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T20:07:20Z"}	2021-09-22 20:07:20.885192+00	
00000000-0000-0000-0000-000000000000	fcc10582-8787-4bbb-b74b-b69e1117ba5e	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T21:06:22Z"}	2021-09-22 21:06:22.326905+00	
00000000-0000-0000-0000-000000000000	9cd4d43d-83c0-427e-8aa4-2b36785b3d54	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T21:06:22Z"}	2021-09-22 21:06:22.327675+00	
00000000-0000-0000-0000-000000000000	140154ee-1332-44b2-80d6-cced9855b57b	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T22:05:22Z"}	2021-09-22 22:05:22.337717+00	
00000000-0000-0000-0000-000000000000	cc59da47-f1e9-4777-bda3-c8ac0d71ce71	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T22:05:22Z"}	2021-09-22 22:05:22.338448+00	
00000000-0000-0000-0000-000000000000	f1103601-fb81-4870-a2fd-d58149506440	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T23:04:22Z"}	2021-09-22 23:04:22.373059+00	
00000000-0000-0000-0000-000000000000	ff2285d0-43f1-49f7-877e-36aeac9be220	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-22T23:04:22Z"}	2021-09-22 23:04:22.373805+00	
00000000-0000-0000-0000-000000000000	65992fb0-797f-485f-adf4-491d87cc4a91	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T01:37:50Z"}	2021-09-23 01:37:50.078815+00	
00000000-0000-0000-0000-000000000000	b2001087-dc66-480f-a60c-0bf3f291705b	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T01:37:50Z"}	2021-09-23 01:37:50.079562+00	
00000000-0000-0000-0000-000000000000	b132bb19-b87e-43bf-9c90-b2d637fd311f	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T02:36:50Z"}	2021-09-23 02:36:50.802734+00	
00000000-0000-0000-0000-000000000000	80f40ba1-9230-462d-97bd-aa36c8152aad	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T02:36:50Z"}	2021-09-23 02:36:50.803472+00	
00000000-0000-0000-0000-000000000000	d232af62-29dd-4a6d-b362-2487905f8cff	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T04:24:30Z"}	2021-09-23 04:24:30.241694+00	
00000000-0000-0000-0000-000000000000	3c566a7a-ecc4-47a0-874b-1d0445b5d756	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T04:24:30Z"}	2021-09-23 04:24:30.242534+00	
00000000-0000-0000-0000-000000000000	3207398f-08cb-4a0c-b3df-d0e4901be9c1	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T05:23:31Z"}	2021-09-23 05:23:31.168753+00	
00000000-0000-0000-0000-000000000000	bdd8a70b-2986-4712-bff5-682d78b4ece6	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T05:23:31Z"}	2021-09-23 05:23:31.169511+00	
00000000-0000-0000-0000-000000000000	bc2881c2-8662-41c1-aa82-f9a2c24e0d8f	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T16:26:41Z"}	2021-09-23 16:26:41.624566+00	
00000000-0000-0000-0000-000000000000	1ef3a900-8774-45c3-821e-7c3f4f00db38	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T16:26:41Z"}	2021-09-23 16:26:41.626998+00	
00000000-0000-0000-0000-000000000000	040dba00-55c8-423f-aa20-17fb7aa758b2	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T17:25:43Z"}	2021-09-23 17:25:43.626183+00	
00000000-0000-0000-0000-000000000000	756b0419-5554-40b1-abc3-c12a8759c817	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T17:25:43Z"}	2021-09-23 17:25:43.628538+00	
00000000-0000-0000-0000-000000000000	3628884b-1b45-47b8-aebd-ff4cc75c5295	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T18:42:48Z"}	2021-09-23 18:42:48.460182+00	
00000000-0000-0000-0000-000000000000	bb4f6e44-1b16-4d68-b0f5-0d4fe4f69ac7	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T18:42:48Z"}	2021-09-23 18:42:48.460943+00	
00000000-0000-0000-0000-000000000000	399720b4-ccd9-46c3-acfb-3cd73b6001ab	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T19:46:19Z"}	2021-09-23 19:46:19.329557+00	
00000000-0000-0000-0000-000000000000	266d9321-8996-4e5c-a8d5-c4e8908583e6	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T19:46:19Z"}	2021-09-23 19:46:19.330361+00	
00000000-0000-0000-0000-000000000000	3f089b45-123b-41cc-818d-4c627d67f492	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T20:45:21Z"}	2021-09-23 20:45:21.310884+00	
00000000-0000-0000-0000-000000000000	0e56e33b-6501-4cd7-8784-234b11601ca5	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T20:45:21Z"}	2021-09-23 20:45:21.311651+00	
00000000-0000-0000-0000-000000000000	80a2025b-0866-41dc-b7d8-767f41176d48	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T21:44:22Z"}	2021-09-23 21:44:22.252174+00	
00000000-0000-0000-0000-000000000000	53e92550-842d-481f-961b-27ac399c6368	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T21:44:22Z"}	2021-09-23 21:44:22.252971+00	
00000000-0000-0000-0000-000000000000	977ebc18-a347-4e33-a73d-4da42d67d307	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T22:43:23Z"}	2021-09-23 22:43:23.721202+00	
00000000-0000-0000-0000-000000000000	048f2196-295e-401a-94a6-e0ff9d3ec5df	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-23T22:43:23Z"}	2021-09-23 22:43:23.721925+00	
00000000-0000-0000-0000-000000000000	efcaeed0-6c13-4ebc-9ce8-a094d77cdc3e	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-24T01:37:04Z"}	2021-09-24 01:37:04.95313+00	
00000000-0000-0000-0000-000000000000	fed3a256-e744-42f3-bcdf-06c0b0110fcd	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-24T01:37:04Z"}	2021-09-24 01:37:04.953891+00	
00000000-0000-0000-0000-000000000000	0fbcb7d0-ca50-4a7b-ac39-e8267ef908ba	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-24T02:36:05Z"}	2021-09-24 02:36:05.560824+00	
00000000-0000-0000-0000-000000000000	a6b6f466-dfdb-4be5-bcae-7fb2ca0b3a02	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-24T02:36:05Z"}	2021-09-24 02:36:05.561611+00	
00000000-0000-0000-0000-000000000000	082951f3-ce19-489e-afc0-0e80fb7295f3	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-24T03:49:29Z"}	2021-09-24 03:49:29.312944+00	
00000000-0000-0000-0000-000000000000	67f1ce8a-f0ce-4949-aed4-e57ec460ffac	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-24T03:49:29Z"}	2021-09-24 03:49:29.313719+00	
00000000-0000-0000-0000-000000000000	85b82983-f791-47e1-bcaa-c0052ae8305e	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-24T13:07:22Z"}	2021-09-24 13:07:22.086262+00	
00000000-0000-0000-0000-000000000000	c672623d-5e0f-4e9d-b8d6-7913cbefc56a	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-24T13:07:22Z"}	2021-09-24 13:07:22.090932+00	
00000000-0000-0000-0000-000000000000	5cdeaf64-1dad-42db-a9a4-425728a08f41	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-24T14:06:22Z"}	2021-09-24 14:06:22.323861+00	
00000000-0000-0000-0000-000000000000	c51bc49b-77ea-41eb-ae21-bc58006a16a8	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-24T14:06:22Z"}	2021-09-24 14:06:22.324578+00	
00000000-0000-0000-0000-000000000000	7f00bc68-ada7-45ce-8875-ae361659e123	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-24T15:05:51Z"}	2021-09-24 15:05:51.383418+00	
00000000-0000-0000-0000-000000000000	3f329064-4000-44cd-bb8e-ace5b529892f	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-24T15:07:17Z"}	2021-09-24 15:07:17.351339+00	
00000000-0000-0000-0000-000000000000	ef963eac-47fb-4901-8eee-dee0926ab359	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-24T15:08:12Z"}	2021-09-24 15:08:12.489178+00	
00000000-0000-0000-0000-000000000000	d40a6dd3-6d37-4e59-a95e-87b106b9018c	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-24T15:08:18Z"}	2021-09-24 15:08:18.344319+00	
00000000-0000-0000-0000-000000000000	ae3c7f7a-ac54-4eb1-ba15-2c85cac943f8	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-24T15:09:18Z"}	2021-09-24 15:09:18.95016+00	
00000000-0000-0000-0000-000000000000	5d04e374-edb3-405f-8c36-ca096ac793ad	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-09-24T15:14:47Z"}	2021-09-24 15:14:47.077172+00	
00000000-0000-0000-0000-000000000000	e1cd3a16-a0d3-4d57-9197-0e757b026fee	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-24T16:29:05Z"}	2021-09-24 16:29:05.585855+00	
00000000-0000-0000-0000-000000000000	4793913b-8681-457c-9b25-7ceea93fd2ee	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-24T16:29:05Z"}	2021-09-24 16:29:05.586879+00	
00000000-0000-0000-0000-000000000000	8e9e7302-2bcd-4c18-91db-bd14d33f00ee	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-24T22:48:18Z"}	2021-09-24 22:48:18.903612+00	
00000000-0000-0000-0000-000000000000	fd428121-383b-4d35-99fa-21c908dcb6f8	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-24T22:48:18Z"}	2021-09-24 22:48:18.904349+00	
00000000-0000-0000-0000-000000000000	03ea2059-16c2-4326-8ba7-d1305d5a1a7b	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-26T00:55:38Z"}	2021-09-26 00:55:38.070274+00	
00000000-0000-0000-0000-000000000000	a482c4ef-2f70-4d51-ac87-c707cfb8fc42	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-26T00:55:38Z"}	2021-09-26 00:55:38.072862+00	
00000000-0000-0000-0000-000000000000	12a04ac2-78f1-447d-a869-c34d4d88df93	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-26T07:27:52Z"}	2021-09-26 07:27:52.374034+00	
00000000-0000-0000-0000-000000000000	db90948f-0da1-4eda-b66b-086d13526904	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-26T07:27:52Z"}	2021-09-26 07:27:52.37478+00	
00000000-0000-0000-0000-000000000000	032e7ae4-f4e8-4fab-b367-25e2ab4ecb1f	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-28T00:54:18Z"}	2021-09-28 00:54:18.724417+00	
00000000-0000-0000-0000-000000000000	fe58a0a0-2a75-456f-86f2-2f7876aa0053	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-28T00:54:18Z"}	2021-09-28 00:54:18.727278+00	
00000000-0000-0000-0000-000000000000	5cc4f2cf-a44e-4fe8-bf1a-aa7aa3ad1e2d	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-28T03:57:27Z"}	2021-09-28 03:57:27.326355+00	
00000000-0000-0000-0000-000000000000	148d6b04-4075-461e-b70a-cd6a03ecc03c	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-09-28T03:57:27Z"}	2021-09-28 03:57:27.329095+00	
00000000-0000-0000-0000-000000000000	f44e36ac-ef8c-4fe7-b435-aea1819c45db	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-01T23:49:00Z"}	2021-10-01 23:49:00.928682+00	
00000000-0000-0000-0000-000000000000	26f9faa3-89bd-4450-a5b8-8d1c9c9876f8	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-01T23:49:00Z"}	2021-10-01 23:49:00.932567+00	
00000000-0000-0000-0000-000000000000	8f386333-ca9c-49ed-bbc7-cd27689c5bd7	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-04T16:15:48Z"}	2021-10-04 16:15:48.239841+00	
00000000-0000-0000-0000-000000000000	88b1691b-5e16-4c34-b067-2c595397abeb	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-04T16:15:48Z"}	2021-10-04 16:15:48.243387+00	
00000000-0000-0000-0000-000000000000	f65e8ab5-e5b5-4f55-8c81-81910f9d9f15	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-04T18:16:47Z"}	2021-10-04 18:16:47.72103+00	
00000000-0000-0000-0000-000000000000	0fd40874-b2d4-4df6-a354-2f1d2244b72e	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-04T18:16:47Z"}	2021-10-04 18:16:47.721935+00	
00000000-0000-0000-0000-000000000000	7315469a-5362-4500-93f3-bb4174ce78e5	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-04T19:15:47Z"}	2021-10-04 19:15:47.974931+00	
00000000-0000-0000-0000-000000000000	0bb77b94-5294-4e2e-87f4-b54fea59631c	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-04T19:15:47Z"}	2021-10-04 19:15:47.975789+00	
00000000-0000-0000-0000-000000000000	24c34efd-3208-461e-ba64-195eeb180af5	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-04T20:14:49Z"}	2021-10-04 20:14:49.236593+00	
00000000-0000-0000-0000-000000000000	c0ced37f-fdc5-47c9-97ca-20527cbc1d8d	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-04T20:14:49Z"}	2021-10-04 20:14:49.237447+00	
00000000-0000-0000-0000-000000000000	0a3e1f69-a055-4abd-abec-4d688f3f2e19	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-04T21:15:32Z"}	2021-10-04 21:15:32.558427+00	
00000000-0000-0000-0000-000000000000	9e872b08-ec1a-4cab-8ad8-b60db423eb4a	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-04T21:15:32Z"}	2021-10-04 21:15:32.559366+00	
00000000-0000-0000-0000-000000000000	2deed2b2-383a-4ea2-b563-4ae8f57a1220	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-04T22:16:35Z"}	2021-10-04 22:16:35.235572+00	
00000000-0000-0000-0000-000000000000	4bd4668a-6c56-4c8f-a52b-c0bec6d0bc59	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-04T22:16:35Z"}	2021-10-04 22:16:35.236438+00	
00000000-0000-0000-0000-000000000000	16e75240-5f29-4c9f-a414-07a2a0237b33	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-05T00:07:19Z"}	2021-10-05 00:07:19.620836+00	
00000000-0000-0000-0000-000000000000	732f4a04-5b35-472e-a843-d6522602bf44	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-05T00:07:19Z"}	2021-10-05 00:07:19.621671+00	
00000000-0000-0000-0000-000000000000	57e335be-0cc9-45b3-a4b5-4a6eb2da2040	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-05T01:09:11Z"}	2021-10-05 01:09:11.842273+00	
00000000-0000-0000-0000-000000000000	3d850251-ba18-4e3d-b615-712d7646669a	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-05T01:09:11Z"}	2021-10-05 01:09:11.843102+00	
00000000-0000-0000-0000-000000000000	5735f36d-0893-4b6b-896c-9ef6eaf986ae	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-05T02:59:29Z"}	2021-10-05 02:59:29.826874+00	
00000000-0000-0000-0000-000000000000	04f13a84-5aad-441f-8824-3b70e8243f18	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-05T02:59:29Z"}	2021-10-05 02:59:29.827717+00	
00000000-0000-0000-0000-000000000000	757faddd-13f0-4de9-9f0c-f97a4fa7c49d	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-05T04:42:29Z"}	2021-10-05 04:42:29.639343+00	
00000000-0000-0000-0000-000000000000	71af4e68-fb52-4a56-8f91-122866c85367	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-05T04:42:29Z"}	2021-10-05 04:42:29.640224+00	
00000000-0000-0000-0000-000000000000	432a8ec3-28bd-4792-8f71-e2c34c2c61c8	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-05T05:41:29Z"}	2021-10-05 05:41:29.819564+00	
00000000-0000-0000-0000-000000000000	71e59050-dafc-4302-b9eb-9b36c9b16875	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-05T05:41:29Z"}	2021-10-05 05:41:29.820406+00	
00000000-0000-0000-0000-000000000000	602cd28f-e92c-4bfb-96e2-4d040a0e5744	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-05T13:15:47Z"}	2021-10-05 13:15:47.127582+00	
00000000-0000-0000-0000-000000000000	f73f7925-eabe-407d-9ab0-fc6fca81a40b	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-05T13:15:47Z"}	2021-10-05 13:15:47.128424+00	
00000000-0000-0000-0000-000000000000	435b289b-0336-4da8-849f-f3b3a89c6e58	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-05T14:14:47Z"}	2021-10-05 14:14:47.276272+00	
00000000-0000-0000-0000-000000000000	a1be3228-9dcb-495c-a30f-8b6756a84934	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-05T14:14:47Z"}	2021-10-05 14:14:47.279835+00	
00000000-0000-0000-0000-000000000000	f3a8f96b-d541-42af-b252-14159a4d5381	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-05T15:22:47Z"}	2021-10-05 15:22:47.727398+00	
00000000-0000-0000-0000-000000000000	d33bf2a6-a3df-495d-816c-ee89514808ac	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-05T15:22:47Z"}	2021-10-05 15:22:47.728425+00	
00000000-0000-0000-0000-000000000000	4d24b98a-25c6-4aae-a05d-fb2cec15ab8e	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-05T16:39:42Z"}	2021-10-05 16:39:42.460569+00	
00000000-0000-0000-0000-000000000000	b58c733b-04f0-48ba-b52a-6ffdbcd61fae	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-05T16:39:42Z"}	2021-10-05 16:39:42.461433+00	
00000000-0000-0000-0000-000000000000	1e235b98-d57d-477c-8c45-ecb8854d8915	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-07T00:04:35Z"}	2021-10-07 00:04:35.423372+00	
00000000-0000-0000-0000-000000000000	bafe2bc2-a737-49da-b113-030946da4eaf	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-07T00:04:35Z"}	2021-10-07 00:04:35.427482+00	
00000000-0000-0000-0000-000000000000	50c367b6-4837-4044-9b99-71eceabc9ba9	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-07T01:03:34Z"}	2021-10-07 01:03:34.618322+00	
00000000-0000-0000-0000-000000000000	6eaa0624-70f0-4a28-8b02-2f71a65c5d41	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-07T01:03:34Z"}	2021-10-07 01:03:34.619202+00	
00000000-0000-0000-0000-000000000000	cba65b0f-619f-4d10-8d71-7e3bad6c49ad	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-07T02:42:53Z"}	2021-10-07 02:42:53.602248+00	
00000000-0000-0000-0000-000000000000	4dbc95fe-bc6e-4009-9f93-61de233745d9	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-07T02:42:53Z"}	2021-10-07 02:42:53.603093+00	
00000000-0000-0000-0000-000000000000	7a5dbb5e-8c8a-43c7-9edb-ca5aef86d587	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-07T03:41:53Z"}	2021-10-07 03:41:53.724622+00	
00000000-0000-0000-0000-000000000000	2a326441-6811-47a3-abb6-6d7c44a0ca3c	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-07T03:41:53Z"}	2021-10-07 03:41:53.725546+00	
00000000-0000-0000-0000-000000000000	8f630e63-c35d-43c4-ae8c-d2cfc6b4c955	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-07T11:26:39Z"}	2021-10-07 11:26:39.444325+00	
00000000-0000-0000-0000-000000000000	063ad6e5-1a03-42df-9b7d-6930d9102f9c	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-07T11:26:39Z"}	2021-10-07 11:26:39.447207+00	
00000000-0000-0000-0000-000000000000	0a00bc42-48a0-49f2-8893-792f96560392	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-07T13:18:10Z"}	2021-10-07 13:18:10.375894+00	
00000000-0000-0000-0000-000000000000	97abedb3-c1b9-450b-8106-fdddb515e43d	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-10-07T13:18:10Z"}	2021-10-07 13:18:10.376741+00	
00000000-0000-0000-0000-000000000000	d080be68-22ea-4176-9820-12f9480c381b	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-10-07T13:18:34Z"}	2021-10-07 13:18:34.663623+00	
00000000-0000-0000-0000-000000000000	11a9e7cb-6ca7-41ae-80a8-a1a38adba571	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-10-09T00:34:33Z"}	2021-10-09 00:34:33.532012+00	
00000000-0000-0000-0000-000000000000	74291e6a-8802-4859-b230-7f93822c8573	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-11-09T19:16:33Z"}	2021-11-09 19:16:33.006566+00	
00000000-0000-0000-0000-000000000000	9a9d2377-f614-451a-9bca-1cda8f8406b9	{"action":"user_recovery_requested","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"user","timestamp":"2021-11-09T19:19:59Z"}	2021-11-09 19:19:59.610176+00	
00000000-0000-0000-0000-000000000000	fc98ec0e-35ef-47b9-8437-5acd1b30a6c0	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-09T20:26:42Z"}	2021-11-09 20:26:42.427695+00	
00000000-0000-0000-0000-000000000000	bef5b994-c060-412d-9330-160c55c45bc2	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-09T20:26:42Z"}	2021-11-09 20:26:42.428404+00	
00000000-0000-0000-0000-000000000000	d98b7dc5-2331-477d-aba8-0d35485c5788	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-09T20:28:34Z"}	2021-11-09 20:28:34.807853+00	
00000000-0000-0000-0000-000000000000	3f1a386b-1a57-4480-af0b-529a3ab8c9ba	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-09T20:28:34Z"}	2021-11-09 20:28:34.808524+00	
00000000-0000-0000-0000-000000000000	8e1ebaf5-2183-4a26-b04f-2de0a30abf29	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-09T22:09:02Z"}	2021-11-09 22:09:02.889533+00	
00000000-0000-0000-0000-000000000000	a6030143-5009-4f4a-9427-bc4cde3e151b	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-09T22:09:02Z"}	2021-11-09 22:09:02.890315+00	
00000000-0000-0000-0000-000000000000	2e194e42-f1b6-46d7-a2cd-6b4ab94f866e	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-09T22:10:51Z"}	2021-11-09 22:10:51.090142+00	
00000000-0000-0000-0000-000000000000	75a60343-ca9c-411a-a56e-93869e57a94b	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-09T22:10:51Z"}	2021-11-09 22:10:51.090893+00	
00000000-0000-0000-0000-000000000000	c5d62d1b-3df2-4ca6-8f21-295533ba5912	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-09T23:08:06Z"}	2021-11-09 23:08:06.971921+00	
00000000-0000-0000-0000-000000000000	2c37d01f-f285-44d5-b2e7-afe133754875	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-09T23:08:06Z"}	2021-11-09 23:08:06.972732+00	
00000000-0000-0000-0000-000000000000	2731d209-452c-4b01-9173-6be5b76ebe55	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-09T23:09:52Z"}	2021-11-09 23:09:52.593539+00	
00000000-0000-0000-0000-000000000000	3c4a8119-4ddb-4d30-83a0-22471beb82d7	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-09T23:09:52Z"}	2021-11-09 23:09:52.594329+00	
00000000-0000-0000-0000-000000000000	144cf242-0007-48f9-a1cd-9ab0d55efcd9	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T00:22:44Z"}	2021-11-10 00:22:44.023312+00	
00000000-0000-0000-0000-000000000000	4b6ac0fd-6a56-484a-a584-d74f0d284c11	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T00:22:44Z"}	2021-11-10 00:22:44.02419+00	
00000000-0000-0000-0000-000000000000	f532a228-f20e-4e29-b5f5-d3dd5b8971a9	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T00:26:23Z"}	2021-11-10 00:26:23.35673+00	
00000000-0000-0000-0000-000000000000	28739fd2-c1b3-44b5-80a8-3896d19bba78	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T00:26:23Z"}	2021-11-10 00:26:23.357511+00	
00000000-0000-0000-0000-000000000000	3286d95a-e4dc-488a-b463-a13549c18b81	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T01:24:52Z"}	2021-11-10 01:24:52.682224+00	
00000000-0000-0000-0000-000000000000	88136348-990f-43d7-a3df-3a111fbdcba9	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T01:24:52Z"}	2021-11-10 01:24:52.683027+00	
00000000-0000-0000-0000-000000000000	c1cd0f11-b729-4624-9f2b-c73600d4e18c	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T01:25:25Z"}	2021-11-10 01:25:25.080569+00	
00000000-0000-0000-0000-000000000000	b3ffaa1d-60b4-47fe-8977-1d68bd594ac1	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T01:25:25Z"}	2021-11-10 01:25:25.081352+00	
00000000-0000-0000-0000-000000000000	c1661c71-838a-4dfc-8ede-db371548bc02	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T02:59:52Z"}	2021-11-10 02:59:52.011312+00	
00000000-0000-0000-0000-000000000000	77978e8d-1e7d-4800-b589-629adcc0b92e	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T02:59:52Z"}	2021-11-10 02:59:52.012542+00	
00000000-0000-0000-0000-000000000000	ec7b86ac-ab82-47a5-94e0-6e9ddca5a87f	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T02:59:52Z"}	2021-11-10 02:59:52.022154+00	
00000000-0000-0000-0000-000000000000	4474cf26-8b87-405c-ad8c-cc7acf708a19	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T02:59:52Z"}	2021-11-10 02:59:52.022859+00	
00000000-0000-0000-0000-000000000000	989cc62b-3cd9-4454-95be-024b7f433d75	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T04:14:52Z"}	2021-11-10 04:14:52.690642+00	
00000000-0000-0000-0000-000000000000	77ec5ac9-15f4-430b-a990-5d792716bb4a	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T04:14:52Z"}	2021-11-10 04:14:52.69147+00	
00000000-0000-0000-0000-000000000000	c3f1b842-a065-45b3-8e6e-eebea4235f0a	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T04:14:52Z"}	2021-11-10 04:14:52.718256+00	
00000000-0000-0000-0000-000000000000	c95f910d-6f5a-4831-9cff-63ff72da41a5	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T04:14:52Z"}	2021-11-10 04:14:52.719113+00	
00000000-0000-0000-0000-000000000000	7b3f3e1e-302d-4610-81a6-b192a789142a	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T05:14:52Z"}	2021-11-10 05:14:52.631883+00	
00000000-0000-0000-0000-000000000000	f36e0649-6fcf-4334-b798-576202d0e4a6	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T05:14:52Z"}	2021-11-10 05:14:52.632665+00	
00000000-0000-0000-0000-000000000000	8cc15881-1da9-4c04-b50a-70e607a83594	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T05:14:52Z"}	2021-11-10 05:14:52.648611+00	
00000000-0000-0000-0000-000000000000	9739acb6-8513-4670-a393-ee96683fc7df	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T05:14:52Z"}	2021-11-10 05:14:52.650262+00	
00000000-0000-0000-0000-000000000000	f06a518d-e919-4881-9fff-349316919122	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T15:58:27Z"}	2021-11-10 15:58:27.645331+00	
00000000-0000-0000-0000-000000000000	e96265b8-8dca-4ea0-a532-89c4ebc48378	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T15:58:27Z"}	2021-11-10 15:58:27.646304+00	
00000000-0000-0000-0000-000000000000	b03e2741-c9da-441d-a79d-23a5fcd4a630	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T15:58:27Z"}	2021-11-10 15:58:27.648181+00	
00000000-0000-0000-0000-000000000000	21de8411-4060-404e-82e2-c990a64ddd2a	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T15:58:27Z"}	2021-11-10 15:58:27.648178+00	
00000000-0000-0000-0000-000000000000	71527215-a32a-40fc-b352-09fcf8959ba6	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T17:05:36Z"}	2021-11-10 17:05:36.041039+00	
00000000-0000-0000-0000-000000000000	534b8393-1383-43e7-bd8a-cb2f090252e5	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T17:05:36Z"}	2021-11-10 17:05:36.041923+00	
00000000-0000-0000-0000-000000000000	ec3fecfd-18d1-408d-86f7-6798d4f3df36	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T17:05:36Z"}	2021-11-10 17:05:36.943769+00	
00000000-0000-0000-0000-000000000000	b8b28f4b-d00a-4efe-a830-0d5e78fb0937	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T17:05:36Z"}	2021-11-10 17:05:36.944574+00	
00000000-0000-0000-0000-000000000000	e03cdf90-7ec6-4573-94d8-d36124239658	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T18:04:52Z"}	2021-11-10 18:04:52.67073+00	
00000000-0000-0000-0000-000000000000	012fc0ec-be7a-4bdc-a696-2f55f0d30827	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T18:04:52Z"}	2021-11-10 18:04:52.67156+00	
00000000-0000-0000-0000-000000000000	d9a97876-3467-400e-8003-39747f7f55fa	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T18:04:52Z"}	2021-11-10 18:04:52.691498+00	
00000000-0000-0000-0000-000000000000	2c2f1b4c-6744-44c8-91c7-1c8032185b83	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T18:04:52Z"}	2021-11-10 18:04:52.692263+00	
00000000-0000-0000-0000-000000000000	76a37e36-e0f9-4ac5-b45b-670a2eecaf7d	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T19:03:54Z"}	2021-11-10 19:03:54.306833+00	
00000000-0000-0000-0000-000000000000	71f189fc-2e5e-468d-9f9f-95cb45957460	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T19:03:54Z"}	2021-11-10 19:03:54.307731+00	
00000000-0000-0000-0000-000000000000	4e563f31-0e7b-4dfb-88a9-c5a03b2da1c1	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T19:03:54Z"}	2021-11-10 19:03:54.30774+00	
00000000-0000-0000-0000-000000000000	b0484b32-d2f0-4704-9520-f6a3aa683c4f	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T19:03:54Z"}	2021-11-10 19:03:54.30857+00	
00000000-0000-0000-0000-000000000000	699fe838-5065-4c33-9e28-710372cc151d	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T20:11:49Z"}	2021-11-10 20:11:49.108596+00	
00000000-0000-0000-0000-000000000000	fa2fe3c1-2782-4c0d-a9ab-c3ece7f2eab7	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T20:11:49Z"}	2021-11-10 20:11:49.109411+00	
00000000-0000-0000-0000-000000000000	b4f09a58-553b-48c8-9ae3-0f94c73743ab	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T20:11:49Z"}	2021-11-10 20:11:49.113009+00	
00000000-0000-0000-0000-000000000000	e76e23b1-95f8-4671-8e77-e5ad4dfe8453	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T20:11:49Z"}	2021-11-10 20:11:49.115637+00	
00000000-0000-0000-0000-000000000000	bc241c58-d524-4a42-9581-e73dfdfabede	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T21:10:52Z"}	2021-11-10 21:10:52.635902+00	
00000000-0000-0000-0000-000000000000	5c7ffa0c-64d2-46ac-aedf-b0d48958cc82	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T21:10:52Z"}	2021-11-10 21:10:52.636736+00	
00000000-0000-0000-0000-000000000000	10762fbf-53bf-4a15-b9bb-429024d093ed	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T21:10:52Z"}	2021-11-10 21:10:52.637298+00	
00000000-0000-0000-0000-000000000000	eff2a1d9-0bb3-498c-b419-b93da88b7883	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T21:10:52Z"}	2021-11-10 21:10:52.638015+00	
00000000-0000-0000-0000-000000000000	552af79a-5731-4bd9-a35a-74997c59db2f	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T22:09:54Z"}	2021-11-10 22:09:54.123132+00	
00000000-0000-0000-0000-000000000000	b41b3acd-c733-4856-aca1-2b517b865ee9	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T22:09:54Z"}	2021-11-10 22:09:54.124024+00	
00000000-0000-0000-0000-000000000000	6a9efa5b-7680-4107-a3fe-fa9c9262165d	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T22:09:54Z"}	2021-11-10 22:09:54.127104+00	
00000000-0000-0000-0000-000000000000	8d0a1cd9-ef35-400e-893f-4de15db7f268	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-10T22:09:54Z"}	2021-11-10 22:09:54.128326+00	
00000000-0000-0000-0000-000000000000	fb715f60-3cc9-4e6f-8c32-1d74bc95b91a	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-11T00:20:28Z"}	2021-11-11 00:20:28.782216+00	
00000000-0000-0000-0000-000000000000	ce4da462-be90-418f-8519-3228f561d2af	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-11T00:20:28Z"}	2021-11-11 00:20:28.78318+00	
00000000-0000-0000-0000-000000000000	3f010ead-821c-469c-bf11-f17365f6a574	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-11-13T01:01:13Z"}	2021-11-13 01:01:13.616597+00	
00000000-0000-0000-0000-000000000000	3e3fc270-cca4-4c42-ba2c-1f04d2ec4a17	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-13T01:01:34Z"}	2021-11-13 01:01:34.275489+00	
00000000-0000-0000-0000-000000000000	e25a5f77-691d-4aed-938d-b8f0a535cf02	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-13T01:01:34Z"}	2021-11-13 01:01:34.276408+00	
00000000-0000-0000-0000-000000000000	dab1e5d9-b843-4b0e-908e-ff5700b81ab3	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-13T01:02:09Z"}	2021-11-13 01:02:09.922507+00	
00000000-0000-0000-0000-000000000000	3c0bbdfb-87fe-437a-a32e-b473c18e73d9	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-13T01:02:09Z"}	2021-11-13 01:02:09.923285+00	
00000000-0000-0000-0000-000000000000	f3784d2d-fe53-41d9-8aa5-515d1094692d	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-13T01:06:36Z"}	2021-11-13 01:06:36.836079+00	
00000000-0000-0000-0000-000000000000	7247f947-4fa2-4734-aaf4-99496c03f386	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-13T01:06:36Z"}	2021-11-13 01:06:36.836901+00	
00000000-0000-0000-0000-000000000000	c3fcf96c-507a-4bcc-a209-00e26af97a40	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-11-13T01:09:29Z"}	2021-11-13 01:09:29.718909+00	
00000000-0000-0000-0000-000000000000	65c35ad9-5cd4-4c7f-9198-1feadd3f7ae1	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-13T01:11:29Z"}	2021-11-13 01:11:29.585954+00	
00000000-0000-0000-0000-000000000000	9555f71a-9738-4b50-9be8-feda7a2e88a6	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-13T01:11:29Z"}	2021-11-13 01:11:29.58679+00	
00000000-0000-0000-0000-000000000000	7b22dfe1-826c-4be2-82d9-ad8656010867	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-13T01:11:37Z"}	2021-11-13 01:11:37.304003+00	
00000000-0000-0000-0000-000000000000	822f0aad-3ba6-4fe5-b97d-c5e9edbac364	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-13T01:11:37Z"}	2021-11-13 01:11:37.304895+00	
00000000-0000-0000-0000-000000000000	4378b5e9-275d-4fab-8d76-4088de7fcc77	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-13T01:12:08Z"}	2021-11-13 01:12:08.846037+00	
00000000-0000-0000-0000-000000000000	cc4e5758-c417-4e7b-a157-8f413812c3eb	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-13T01:12:08Z"}	2021-11-13 01:12:08.846863+00	
00000000-0000-0000-0000-000000000000	1495b20d-451b-42e4-abe4-0652d32f34b2	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-13T01:12:43Z"}	2021-11-13 01:12:43.859085+00	
00000000-0000-0000-0000-000000000000	4bbbd2f8-1652-4569-9737-3373138d0306	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-13T01:12:43Z"}	2021-11-13 01:12:43.859955+00	
00000000-0000-0000-0000-000000000000	e1fd15bb-aaff-4d8b-bde7-22fba67e1b51	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-11-13T01:13:47Z"}	2021-11-13 01:13:47.641965+00	
00000000-0000-0000-0000-000000000000	31f28bb2-ca2c-4dd5-8672-01d44d8529ca	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-11-13T01:13:59Z"}	2021-11-13 01:13:59.716827+00	
00000000-0000-0000-0000-000000000000	1be69921-c9c5-48d3-8ed8-7358217e821a	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-13T01:14:08Z"}	2021-11-13 01:14:08.786912+00	
00000000-0000-0000-0000-000000000000	27c0666f-30a0-4e82-9c0d-4f07abb3e9f7	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-13T01:14:08Z"}	2021-11-13 01:14:08.787789+00	
00000000-0000-0000-0000-000000000000	0c48c526-c617-4955-93ca-ccfa0100ae7f	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-11T00:20:28Z"}	2021-11-11 00:20:28.783977+00	
00000000-0000-0000-0000-000000000000	b966fe91-8ec5-42ce-baa8-4513cd9591f2	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-11T00:20:28Z"}	2021-11-11 00:20:28.78502+00	
00000000-0000-0000-0000-000000000000	5b614c1c-10ee-4800-afff-1a10d3aac5f8	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-11T01:26:14Z"}	2021-11-11 01:26:14.726024+00	
00000000-0000-0000-0000-000000000000	6172c0f3-9959-478f-9766-d1e3a0beb889	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-11T01:26:14Z"}	2021-11-11 01:26:14.729433+00	
00000000-0000-0000-0000-000000000000	e0327052-c64d-4f35-b09e-64177bafdef0	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-11T01:26:14Z"}	2021-11-11 01:26:14.740507+00	
00000000-0000-0000-0000-000000000000	f6f6f5b7-ba53-4b1c-8ea0-395b9dbf3095	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-11T01:26:14Z"}	2021-11-11 01:26:14.741244+00	
00000000-0000-0000-0000-000000000000	8c3f67fd-9ec1-4860-8196-6a1ad9f1f22b	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-11T03:37:39Z"}	2021-11-11 03:37:39.688114+00	
00000000-0000-0000-0000-000000000000	89abe656-eacf-4a4a-9e17-c091d4661b14	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-11T03:37:39Z"}	2021-11-11 03:37:39.689079+00	
00000000-0000-0000-0000-000000000000	ebe6c74f-30f0-441d-aef3-f550924ab1b1	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-11T03:37:41Z"}	2021-11-11 03:37:41.085601+00	
00000000-0000-0000-0000-000000000000	1fe51fcf-0715-4d64-90c3-cda6833bb6ca	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-11T03:37:41Z"}	2021-11-11 03:37:41.086492+00	
00000000-0000-0000-0000-000000000000	3b7907f3-db39-4895-8274-6f4b4dffe307	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-11T04:36:44Z"}	2021-11-11 04:36:44.91243+00	
00000000-0000-0000-0000-000000000000	58e801bf-dcd3-4dc4-8287-847733c1116c	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-11T04:36:44Z"}	2021-11-11 04:36:44.913431+00	
00000000-0000-0000-0000-000000000000	ee322613-348e-4c78-a5ee-5ff3ea8741eb	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-11T04:36:47Z"}	2021-11-11 04:36:47.779209+00	
00000000-0000-0000-0000-000000000000	60539800-8f63-4745-8c4a-8eb8851409b0	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-11T04:36:47Z"}	2021-11-11 04:36:47.780065+00	
00000000-0000-0000-0000-000000000000	73e4a2c4-3a70-481f-a0b6-0226e66e4dc7	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-13T00:59:57Z"}	2021-11-13 00:59:57.912985+00	
00000000-0000-0000-0000-000000000000	576db822-b221-49f9-994c-99dc5793f6ac	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-13T00:59:57Z"}	2021-11-13 00:59:57.916849+00	
00000000-0000-0000-0000-000000000000	a5a6ec99-6d49-418e-8e73-ee606bae1fff	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-11-13T01:13:18Z"}	2021-11-13 01:13:18.591603+00	
00000000-0000-0000-0000-000000000000	7f03f2a2-040e-4138-94e8-6189f7a3078c	{"action":"logout","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2021-11-13T01:13:54Z"}	2021-11-13 01:13:54.311927+00	
00000000-0000-0000-0000-000000000000	d0a76a17-1f16-4bfc-ab41-543f31be267b	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-15T21:19:27Z"}	2021-11-15 21:19:27.504723+00	
00000000-0000-0000-0000-000000000000	1c0b00c6-9fef-456f-9f06-f5661074993b	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2021-11-15T21:19:27Z"}	2021-11-15 21:19:27.505565+00	
00000000-0000-0000-0000-000000000000	39b57f39-a409-4e5c-be16-b6aa1a147aec	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2022-01-28T05:33:52Z"}	2022-01-28 05:33:52.031271+00	
00000000-0000-0000-0000-000000000000	29e0a3c0-225b-4108-8ad9-6edadece1838	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-28T06:32:53Z"}	2022-01-28 06:32:53.477943+00	
00000000-0000-0000-0000-000000000000	3df8de57-cdd2-4c19-957e-43e845551a0c	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-28T06:32:53Z"}	2022-01-28 06:32:53.478752+00	
00000000-0000-0000-0000-000000000000	6a7d03a3-afde-41c3-936d-084ea0f2c5e1	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-28T13:22:03Z"}	2022-01-28 13:22:03.848219+00	
00000000-0000-0000-0000-000000000000	69ac0ff1-622e-4b5d-bca1-e62c0241ebc0	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-28T13:22:03Z"}	2022-01-28 13:22:03.849753+00	
00000000-0000-0000-0000-000000000000	83487be6-baaa-4392-bef7-18f648a5af65	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-28T14:21:04Z"}	2022-01-28 14:21:04.187021+00	
00000000-0000-0000-0000-000000000000	2c2cd83b-4e3e-468f-887b-3730fb355bd3	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-28T14:21:04Z"}	2022-01-28 14:21:04.187839+00	
00000000-0000-0000-0000-000000000000	e94e5ed0-d5fe-4627-9e95-c94ab7f48a18	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-28T15:20:06Z"}	2022-01-28 15:20:06.449115+00	
00000000-0000-0000-0000-000000000000	b8c3292a-50c6-4b87-941d-d192d732c089	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-28T15:20:06Z"}	2022-01-28 15:20:06.450582+00	
00000000-0000-0000-0000-000000000000	8ed21df2-6605-495a-b99f-53609ad707a7	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-28T16:21:37Z"}	2022-01-28 16:21:37.025466+00	
00000000-0000-0000-0000-000000000000	509d55dc-5ef0-462c-9fb6-a7c58e2972de	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-28T16:21:37Z"}	2022-01-28 16:21:37.028058+00	
00000000-0000-0000-0000-000000000000	79db40dc-310d-4ce5-913b-b3b1919ad85a	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-28T20:37:33Z"}	2022-01-28 20:37:33.898217+00	
00000000-0000-0000-0000-000000000000	fb06eb77-9d9d-428c-9105-197e4b3020a7	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-28T20:37:33Z"}	2022-01-28 20:37:33.898995+00	
00000000-0000-0000-0000-000000000000	4abefd34-2952-49c4-8c4e-b9ed13646aac	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-29T04:40:26Z"}	2022-01-29 04:40:26.441789+00	
00000000-0000-0000-0000-000000000000	f63c1a44-9c6c-4ab9-8479-d7ffce13622d	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-29T04:40:26Z"}	2022-01-29 04:40:26.442687+00	
00000000-0000-0000-0000-000000000000	4b0aa20b-eb7d-4482-a5b7-eef5caf98e3d	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-29T15:44:20Z"}	2022-01-29 15:44:20.40933+00	
00000000-0000-0000-0000-000000000000	ecce064d-ea4b-4069-a5b6-41acbfb70459	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-29T15:44:20Z"}	2022-01-29 15:44:20.413594+00	
00000000-0000-0000-0000-000000000000	ffcc728f-4296-449a-af8d-2d6a83ff8e5c	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-29T19:38:47Z"}	2022-01-29 19:38:47.016803+00	
00000000-0000-0000-0000-000000000000	b885d0ea-8218-464f-bcfe-9fae5f771062	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-29T19:38:47Z"}	2022-01-29 19:38:47.017561+00	
00000000-0000-0000-0000-000000000000	202984f0-0caa-4648-98bb-d030f27e4142	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-29T23:16:00Z"}	2022-01-29 23:16:00.926629+00	
00000000-0000-0000-0000-000000000000	d7e31fb9-d757-436a-b485-e9caffd275d5	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-29T23:16:00Z"}	2022-01-29 23:16:00.927494+00	
00000000-0000-0000-0000-000000000000	e3410526-de0f-4b53-ab41-932cc504baa1	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T00:15:02Z"}	2022-01-30 00:15:02.969722+00	
00000000-0000-0000-0000-000000000000	de48eca9-e74c-491c-9705-95fea6cf666b	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T00:15:02Z"}	2022-01-30 00:15:02.97058+00	
00000000-0000-0000-0000-000000000000	a1cdb64e-d2cf-4348-9a15-5fa9a18dff1d	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T01:14:04Z"}	2022-01-30 01:14:04.953187+00	
00000000-0000-0000-0000-000000000000	facad932-9fff-4f99-9098-c91c23c2c0d1	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T01:14:04Z"}	2022-01-30 01:14:04.954205+00	
00000000-0000-0000-0000-000000000000	59a660f3-48cb-4a3f-b9ca-af90af3661c1	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T02:13:05Z"}	2022-01-30 02:13:05.148768+00	
00000000-0000-0000-0000-000000000000	d756dfe7-84af-4308-9ca4-ed2ca4ff42bf	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T02:13:05Z"}	2022-01-30 02:13:05.149688+00	
00000000-0000-0000-0000-000000000000	0b843faa-7265-435c-9e3f-a38557a5f283	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T03:12:06Z"}	2022-01-30 03:12:06.19909+00	
00000000-0000-0000-0000-000000000000	d4365c1f-76cc-4380-8ac9-ce30761dc2a4	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T03:12:06Z"}	2022-01-30 03:12:06.19995+00	
00000000-0000-0000-0000-000000000000	d9be7128-2284-4da8-ac1c-b2c11eabcf11	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T05:20:52Z"}	2022-01-30 05:20:52.654623+00	
00000000-0000-0000-0000-000000000000	bd0ad8cb-7a8f-4c0b-9870-177633dc38f6	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T05:20:52Z"}	2022-01-30 05:20:52.657449+00	
00000000-0000-0000-0000-000000000000	35242357-fae5-46d8-afaa-349f8961d539	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T14:53:18Z"}	2022-01-30 14:53:18.908453+00	
00000000-0000-0000-0000-000000000000	bd921f28-d86e-4675-884e-42fcebc511bf	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T14:53:18Z"}	2022-01-30 14:53:18.90928+00	
00000000-0000-0000-0000-000000000000	044b2cf6-3f43-49b7-b9d8-c4a45f873ec8	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T15:59:04Z"}	2022-01-30 15:59:04.271641+00	
00000000-0000-0000-0000-000000000000	93da84d6-7eea-4d94-aee6-8b68fc824bd8	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T15:59:04Z"}	2022-01-30 15:59:04.272481+00	
00000000-0000-0000-0000-000000000000	67a572ea-673e-4291-aec7-f5eeb0a91e99	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T17:10:35Z"}	2022-01-30 17:10:35.734344+00	
00000000-0000-0000-0000-000000000000	bf5ce4ae-0d69-4ca1-8625-b92a3886bc67	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T17:10:35Z"}	2022-01-30 17:10:35.735159+00	
00000000-0000-0000-0000-000000000000	34aca52c-9ca7-409a-ab43-7c5928928572	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T18:26:04Z"}	2022-01-30 18:26:04.481704+00	
00000000-0000-0000-0000-000000000000	866bab14-32ed-465d-baf1-c46d6843694c	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T18:26:04Z"}	2022-01-30 18:26:04.482841+00	
00000000-0000-0000-0000-000000000000	7e2fffc5-b53e-4ff4-acc1-7b6be70866cd	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T19:26:03Z"}	2022-01-30 19:26:03.310806+00	
00000000-0000-0000-0000-000000000000	d2652ab3-2077-4c45-985d-b06c6d0a655d	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T19:26:03Z"}	2022-01-30 19:26:03.311643+00	
00000000-0000-0000-0000-000000000000	3a9921f1-07e0-4ccd-8ae4-6adf5991fce0	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T20:25:03Z"}	2022-01-30 20:25:03.392986+00	
00000000-0000-0000-0000-000000000000	2dd92a8c-6ed5-440a-a927-c3d0234c7a3e	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-01-30T20:25:03Z"}	2022-01-30 20:25:03.393817+00	
00000000-0000-0000-0000-000000000000	b96d67b3-a135-4115-aee2-f54f785e79bc	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2022-04-01T04:06:09Z","traits":{"provider":"email"}}	2022-04-01 04:06:09.74726+00	
00000000-0000-0000-0000-000000000000	c2c1d173-5bd3-4985-b48c-cbac92b43026	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-01T22:23:41Z"}	2022-04-01 22:23:41.008371+00	
00000000-0000-0000-0000-000000000000	f864ac5f-4007-4545-92c0-febb10b2e5de	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-01T22:23:41Z"}	2022-04-01 22:23:41.010099+00	
00000000-0000-0000-0000-000000000000	2fda3e32-3e37-4962-b5d2-554741730f6f	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2022-04-07T22:16:05Z","traits":{"provider":"email"}}	2022-04-07 22:16:05.599068+00	
00000000-0000-0000-0000-000000000000	de15678e-3c67-475f-9303-52c063c18eba	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-07T23:37:06Z"}	2022-04-07 23:37:06.006897+00	
00000000-0000-0000-0000-000000000000	e7f2bdf9-f4e2-4cd8-ad1b-93bb782e7163	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-07T23:37:06Z"}	2022-04-07 23:37:06.007825+00	
00000000-0000-0000-0000-000000000000	068f6ef5-3ea8-42eb-b728-3bead00137c1	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-08T00:36:07Z"}	2022-04-08 00:36:07.17618+00	
00000000-0000-0000-0000-000000000000	e70417a9-75ba-41b5-8e27-2a3883518619	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-08T00:36:07Z"}	2022-04-08 00:36:07.177081+00	
00000000-0000-0000-0000-000000000000	1c4d6e83-8659-45c7-8151-8405a52af98b	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-08T01:35:08Z"}	2022-04-08 01:35:08.096202+00	
00000000-0000-0000-0000-000000000000	44c4636b-92f8-43ca-afc5-b6456d3c2d29	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-08T01:35:08Z"}	2022-04-08 01:35:08.097066+00	
00000000-0000-0000-0000-000000000000	4c93d4c7-28ee-4cf7-a343-6d100eca2e66	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-08T04:13:53Z"}	2022-04-08 04:13:53.600496+00	
00000000-0000-0000-0000-000000000000	ca2bcb1b-5150-4821-a97a-3f693af9131b	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-08T04:13:53Z"}	2022-04-08 04:13:53.601345+00	
00000000-0000-0000-0000-000000000000	ea17f99f-8390-45d9-a233-d8c454da0630	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-09T02:46:13Z"}	2022-04-09 02:46:13.909928+00	
00000000-0000-0000-0000-000000000000	61c2c97d-2cf8-484f-b6af-84a92e4587f8	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-09T02:46:13Z"}	2022-04-09 02:46:13.912708+00	
00000000-0000-0000-0000-000000000000	5f0ac09d-1ade-4f48-b8ab-271c24817839	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-09T03:45:15Z"}	2022-04-09 03:45:15.00355+00	
00000000-0000-0000-0000-000000000000	93981a1d-b89e-48d0-a9de-1f39ea1ef750	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-09T03:45:15Z"}	2022-04-09 03:45:15.004433+00	
00000000-0000-0000-0000-000000000000	fcaa63f8-10c0-43b6-a0e4-3d91a44adf60	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2022-04-19T02:39:25Z","traits":{"provider":"email"}}	2022-04-19 02:39:25.565353+00	
00000000-0000-0000-0000-000000000000	168533cd-7542-4021-b02f-8e7e291b97ae	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-19T03:38:27Z"}	2022-04-19 03:38:27.287608+00	
00000000-0000-0000-0000-000000000000	a2cf17fb-242e-4b15-bf76-53a0fdb4dfe6	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-19T03:38:27Z"}	2022-04-19 03:38:27.288469+00	
00000000-0000-0000-0000-000000000000	574b70b5-79af-47cf-89aa-b392c0a53b77	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2022-04-19T14:29:38Z","traits":{"provider":"email"}}	2022-04-19 14:29:38.60557+00	
00000000-0000-0000-0000-000000000000	0785fa76-b85a-4e47-a86f-1ebefc409892	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-19T23:56:08Z"}	2022-04-19 23:56:08.546665+00	
00000000-0000-0000-0000-000000000000	e0dc1b2d-9d34-4128-81bd-1028a75758da	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-19T23:56:08Z"}	2022-04-19 23:56:08.548321+00	
00000000-0000-0000-0000-000000000000	eaa6c8e8-63a9-4325-93de-932e529aa210	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-20T00:56:37Z"}	2022-04-20 00:56:37.34147+00	
00000000-0000-0000-0000-000000000000	f7f62321-120a-48ab-8721-b801c41c9198	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-20T00:56:37Z"}	2022-04-20 00:56:37.342403+00	
00000000-0000-0000-0000-000000000000	c976d787-3b11-4ab2-819a-99cbdf953c2c	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-20T01:55:37Z"}	2022-04-20 01:55:37.743904+00	
00000000-0000-0000-0000-000000000000	66acc869-c019-498a-949f-844112753138	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-20T01:55:37Z"}	2022-04-20 01:55:37.744768+00	
00000000-0000-0000-0000-000000000000	055883c4-d55b-4af0-b496-1251cae6dbc3	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-20T04:07:18Z"}	2022-04-20 04:07:18.364714+00	
00000000-0000-0000-0000-000000000000	3c66eb01-0df9-4c40-82c4-c743dcc966c8	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-20T04:07:18Z"}	2022-04-20 04:07:18.365656+00	
00000000-0000-0000-0000-000000000000	fa0ea58f-aa25-4387-95d5-0de0152122fe	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-20T14:00:43Z"}	2022-04-20 14:00:43.220502+00	
00000000-0000-0000-0000-000000000000	56f5b7d2-4a4e-4f61-ae54-3eca7b878c36	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-20T14:00:43Z"}	2022-04-20 14:00:43.224772+00	
00000000-0000-0000-0000-000000000000	4e7a379a-abdd-4e53-8d12-772c7eecb310	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-20T14:59:43Z"}	2022-04-20 14:59:43.269238+00	
00000000-0000-0000-0000-000000000000	4bd78701-df39-41ec-b0fc-f17322aa8d45	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-20T14:59:43Z"}	2022-04-20 14:59:43.270145+00	
00000000-0000-0000-0000-000000000000	c19e8494-b6b0-4bc9-b2df-63c171dedbf6	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-20T18:37:28Z"}	2022-04-20 18:37:28.151892+00	
00000000-0000-0000-0000-000000000000	87fcbb01-d75d-4d2e-a062-3fa8207dc2be	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-20T18:37:28Z"}	2022-04-20 18:37:28.152861+00	
00000000-0000-0000-0000-000000000000	d7ea621a-82a4-4dce-bb07-d0fa1d37cedb	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-29T04:23:14Z"}	2022-04-29 04:23:14.963995+00	
00000000-0000-0000-0000-000000000000	52a9402c-b34a-4e54-b2c9-08ae49152fad	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-29T04:23:14Z"}	2022-04-29 04:23:14.965269+00	
00000000-0000-0000-0000-000000000000	ff5351cf-37b3-411e-a8d4-e0e43df17c13	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-29T05:22:44Z"}	2022-04-29 05:22:44.918272+00	
00000000-0000-0000-0000-000000000000	79516a4b-02e1-4ebb-8031-bce9e12e533c	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-29T05:22:44Z"}	2022-04-29 05:22:44.919481+00	
00000000-0000-0000-0000-000000000000	06047a1c-3601-4807-b5bf-f308100f827b	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-29T18:55:29Z"}	2022-04-29 18:55:29.587638+00	
00000000-0000-0000-0000-000000000000	337f5ec1-75b7-4404-8574-7f9483731944	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-29T18:55:29Z"}	2022-04-29 18:55:29.588843+00	
00000000-0000-0000-0000-000000000000	f307d555-3919-4d3e-83e3-69127b7ee56a	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-30T00:02:44Z"}	2022-04-30 00:02:44.710708+00	
00000000-0000-0000-0000-000000000000	a7d957af-f45c-43e1-9a30-5d0826969a9f	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-30T00:02:44Z"}	2022-04-30 00:02:44.71187+00	
00000000-0000-0000-0000-000000000000	e96e85be-bc22-48df-95dd-6d922979abfa	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-30T03:21:16Z"}	2022-04-30 03:21:16.160565+00	
00000000-0000-0000-0000-000000000000	c9d49c02-8e14-4923-a4b7-03cabbdb5612	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-30T03:21:16Z"}	2022-04-30 03:21:16.161448+00	
00000000-0000-0000-0000-000000000000	1fcf33fe-e3a2-4f3a-a0d2-03a583cf44be	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-30T04:20:17Z"}	2022-04-30 04:20:17.262591+00	
00000000-0000-0000-0000-000000000000	cf8cb42c-a607-4ab8-9570-7e97e4c738b1	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-30T04:20:17Z"}	2022-04-30 04:20:17.263494+00	
00000000-0000-0000-0000-000000000000	501694e8-e129-4ad8-982d-201bc80e8aca	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-30T05:19:28Z"}	2022-04-30 05:19:28.749859+00	
00000000-0000-0000-0000-000000000000	f064d4f7-832f-4e1c-bf1d-ae81232c61ba	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-30T05:19:28Z"}	2022-04-30 05:19:28.750797+00	
00000000-0000-0000-0000-000000000000	b837ce07-a857-4ef3-997b-47617a5166a7	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-30T14:13:57Z"}	2022-04-30 14:13:57.154404+00	
00000000-0000-0000-0000-000000000000	96554dc0-245b-44bd-bb95-86a3f0d4a52f	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-30T14:13:57Z"}	2022-04-30 14:13:57.157729+00	
00000000-0000-0000-0000-000000000000	d5b20a1d-f1ad-46c9-8498-de78e15450f3	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-30T15:12:58Z"}	2022-04-30 15:12:58.616164+00	
00000000-0000-0000-0000-000000000000	5b8e4733-7a1b-4e47-b1bf-4689c9dc6c88	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-04-30T15:12:58Z"}	2022-04-30 15:12:58.61705+00	
00000000-0000-0000-0000-000000000000	c874bda0-4ee3-4e45-9421-00e3fd744055	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-05-08T03:08:42Z"}	2022-05-08 03:08:42.020912+00	
00000000-0000-0000-0000-000000000000	6c2fd205-463e-42a6-b04f-2ef1df723ea9	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-05-08T03:08:42Z"}	2022-05-08 03:08:42.024436+00	
00000000-0000-0000-0000-000000000000	95b156df-e503-4ff8-ba48-4f87733a7aef	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-05-08T04:07:42Z"}	2022-05-08 04:07:42.440331+00	
00000000-0000-0000-0000-000000000000	7b9e6511-ad37-4dd5-97b3-88130566002b	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-05-08T04:07:42Z"}	2022-05-08 04:07:42.441186+00	
00000000-0000-0000-0000-000000000000	5e545436-bb3e-4179-b600-60e3e8f6f046	{"action":"login","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"account","timestamp":"2022-05-20T14:03:02Z","traits":{"provider":"email"}}	2022-05-20 14:03:02.637432+00	
00000000-0000-0000-0000-000000000000	4f405fdf-5b66-471b-b54e-d6c563dca9ae	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-05-20T15:02:03Z"}	2022-05-20 15:02:03.301856+00	
00000000-0000-0000-0000-000000000000	b380416c-87dc-4634-a121-3af7151916fb	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-05-20T15:02:03Z"}	2022-05-20 15:02:03.302756+00	
00000000-0000-0000-0000-000000000000	eef398d6-d5ea-4a50-b196-612b96350181	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-05-23T00:25:18Z"}	2022-05-23 00:25:18.153639+00	
00000000-0000-0000-0000-000000000000	a617c1b0-62bc-4ebf-a2cd-22a245a0631a	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-05-23T00:25:18Z"}	2022-05-23 00:25:18.158047+00	
00000000-0000-0000-0000-000000000000	12e12679-673f-42b3-b921-37235a7f0d58	{"action":"token_refreshed","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-05-23T04:29:19Z"}	2022-05-23 04:29:19.800484+00	
00000000-0000-0000-0000-000000000000	180b41e2-e8da-459d-9851-97160d662059	{"action":"token_revoked","actor_id":"22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065","actor_username":"robert.aboukhalil@gmail.com","log_type":"token","timestamp":"2022-05-23T04:29:19Z"}	2022-05-23 04:29:19.803599+00	
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."identities" ("id", "user_id", "identity_data", "provider", "last_sign_in_at", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."instances" ("id", "uuid", "raw_base_config", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."refresh_tokens" ("instance_id", "id", "token", "user_id", "revoked", "created_at", "updated_at", "parent") FROM stdin;
00000000-0000-0000-0000-000000000000	88	JEoFHzGPdxwLVcDQxMoM9Q	c661f0e6-f87d-4782-827a-bfbb2de14b6f	t	2021-09-03 02:59:39.828281+00	2021-09-03 02:59:39.828281+00	\N
00000000-0000-0000-0000-000000000000	123	q8hGhlM8IJ9vWHID0-LGRg	c661f0e6-f87d-4782-827a-bfbb2de14b6f	f	2021-09-07 23:15:12.657782+00	2021-09-07 23:15:12.657782+00	\N
00000000-0000-0000-0000-000000000000	330	r-pRH-GQwsCvesVZ4Zp46A	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2021-11-13 01:14:08.788742+00	2021-11-13 01:14:08.788742+00	\N
00000000-0000-0000-0000-000000000000	331	4NYddAxflDikMnqBPRBaWA	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	f	2021-11-15 21:19:27.509305+00	2021-11-15 21:19:27.509305+00	\N
00000000-0000-0000-0000-000000000000	329	3qh6LT671qKy7VNTMe-9aQ	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2021-11-13 01:13:59.717793+00	2021-11-13 01:13:59.717793+00	\N
00000000-0000-0000-0000-000000000000	332	IKnG7I0gO6h0FxXq8Qcz6A	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-01-28 05:33:52.03948+00	2022-01-28 05:33:52.03948+00	\N
00000000-0000-0000-0000-000000000000	333	EwOevzGmVD2iNAfZsZO-Bg	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-01-28 06:32:53.480208+00	2022-01-28 06:32:53.480208+00	IKnG7I0gO6h0FxXq8Qcz6A
00000000-0000-0000-0000-000000000000	334	HMP1ZBX9JQpJ9z1rSzBE7Q	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-01-28 13:22:03.851006+00	2022-01-28 13:22:03.851006+00	EwOevzGmVD2iNAfZsZO-Bg
00000000-0000-0000-0000-000000000000	335	MxtAPxJqHK6v_84eQWIW_Q	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-01-28 14:21:04.189046+00	2022-01-28 14:21:04.189046+00	HMP1ZBX9JQpJ9z1rSzBE7Q
00000000-0000-0000-0000-000000000000	336	34mHemdixUgSwjpa3s50Lg	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-01-28 15:20:06.451668+00	2022-01-28 15:20:06.451668+00	MxtAPxJqHK6v_84eQWIW_Q
00000000-0000-0000-0000-000000000000	337	Vbvrrx2bME_a-y8VevSfsw	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-01-28 16:21:37.029468+00	2022-01-28 16:21:37.029468+00	34mHemdixUgSwjpa3s50Lg
00000000-0000-0000-0000-000000000000	338	74GkGcM7t814Wk1Mfe2K6Q	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-01-28 20:37:33.900071+00	2022-01-28 20:37:33.900071+00	Vbvrrx2bME_a-y8VevSfsw
00000000-0000-0000-0000-000000000000	339	PE4epi-q9A_b-2SiyGm0WQ	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-01-29 04:40:26.443803+00	2022-01-29 04:40:26.443803+00	74GkGcM7t814Wk1Mfe2K6Q
00000000-0000-0000-0000-000000000000	340	_cb01cVECXZRLHh6LPJonw	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-01-29 15:44:20.415496+00	2022-01-29 15:44:20.415496+00	PE4epi-q9A_b-2SiyGm0WQ
00000000-0000-0000-0000-000000000000	341	d9S89ZCMj2xhhuxbXg9f9A	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-01-29 19:38:47.01859+00	2022-01-29 19:38:47.01859+00	_cb01cVECXZRLHh6LPJonw
00000000-0000-0000-0000-000000000000	342	NOjo5rPi6eHqyeocUr__Bg	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-01-29 23:16:00.933418+00	2022-01-29 23:16:00.933418+00	d9S89ZCMj2xhhuxbXg9f9A
00000000-0000-0000-0000-000000000000	343	s56DrANpXdVMNOnK3Rn6PQ	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-01-30 00:15:02.971629+00	2022-01-30 00:15:02.971629+00	NOjo5rPi6eHqyeocUr__Bg
00000000-0000-0000-0000-000000000000	344	8ymZYi-wxD-E-lhKo2wceg	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-01-30 01:14:04.955335+00	2022-01-30 01:14:04.955335+00	s56DrANpXdVMNOnK3Rn6PQ
00000000-0000-0000-0000-000000000000	345	stU85Jc_SUG04kdCRPBb9Q	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-01-30 02:13:05.151025+00	2022-01-30 02:13:05.151025+00	8ymZYi-wxD-E-lhKo2wceg
00000000-0000-0000-0000-000000000000	346	MqYjnAMmnl4BFFM2TD_jMw	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-01-30 03:12:06.201135+00	2022-01-30 03:12:06.201135+00	stU85Jc_SUG04kdCRPBb9Q
00000000-0000-0000-0000-000000000000	347	FQ3lmDGO7DcUz-pGGgBNvw	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-01-30 05:20:52.658531+00	2022-01-30 05:20:52.658531+00	MqYjnAMmnl4BFFM2TD_jMw
00000000-0000-0000-0000-000000000000	348	zCr1SPn6otMKvCUSeYLsBQ	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-01-30 14:53:18.910308+00	2022-01-30 14:53:18.910308+00	FQ3lmDGO7DcUz-pGGgBNvw
00000000-0000-0000-0000-000000000000	349	vjqX-viQnVuPSGQss5TpUA	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-01-30 15:59:04.273694+00	2022-01-30 15:59:04.273694+00	zCr1SPn6otMKvCUSeYLsBQ
00000000-0000-0000-0000-000000000000	350	L_Ow3Scs19JjegPuxheguQ	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-01-30 17:10:35.736191+00	2022-01-30 17:10:35.736191+00	vjqX-viQnVuPSGQss5TpUA
00000000-0000-0000-0000-000000000000	351	yGENtX1RsmMCrP8EC1j8Sw	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-01-30 18:26:04.484078+00	2022-01-30 18:26:04.484078+00	L_Ow3Scs19JjegPuxheguQ
00000000-0000-0000-0000-000000000000	352	LZqoqInxCkElYEpnbzdLVg	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-01-30 19:26:03.312728+00	2022-01-30 19:26:03.312728+00	yGENtX1RsmMCrP8EC1j8Sw
00000000-0000-0000-0000-000000000000	353	CX86iC09yRHCLp3ONWvL2w	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	f	2022-01-30 20:25:03.395056+00	2022-01-30 20:25:03.395056+00	LZqoqInxCkElYEpnbzdLVg
00000000-0000-0000-0000-000000000000	354	MU3kh-YZIyohWzYQaWwFzQ	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-01 04:06:09.748733+00	2022-04-01 04:06:09.748736+00	\N
00000000-0000-0000-0000-000000000000	355	NhFiWuAL5HJzcDPfy27ChQ	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-01 22:23:41.012277+00	2022-04-01 22:23:41.01228+00	MU3kh-YZIyohWzYQaWwFzQ
00000000-0000-0000-0000-000000000000	356	RNgFEddOihtntBwp4SnpCQ	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-07 22:16:05.603085+00	2022-04-07 22:16:05.603087+00	\N
00000000-0000-0000-0000-000000000000	357	dgUSDQMrDNUSUKkYydeUtQ	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-07 23:37:06.00939+00	2022-04-07 23:37:06.009392+00	RNgFEddOihtntBwp4SnpCQ
00000000-0000-0000-0000-000000000000	358	7CT_5R7YKz-hoZa1kSWJ1Q	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-08 00:36:07.178392+00	2022-04-08 00:36:07.178395+00	dgUSDQMrDNUSUKkYydeUtQ
00000000-0000-0000-0000-000000000000	359	80PUFGwUKoDqwiAcGsBHlg	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-08 01:35:08.09835+00	2022-04-08 01:35:08.098352+00	7CT_5R7YKz-hoZa1kSWJ1Q
00000000-0000-0000-0000-000000000000	360	PMQh_KereopX4hrbstPcXw	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-08 04:13:53.602589+00	2022-04-08 04:13:53.602592+00	80PUFGwUKoDqwiAcGsBHlg
00000000-0000-0000-0000-000000000000	361	1sDUbshbMmRRO1OE44MwFA	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-09 02:46:13.914927+00	2022-04-09 02:46:13.91493+00	PMQh_KereopX4hrbstPcXw
00000000-0000-0000-0000-000000000000	362	EghjqSQVdZ_ns9U5V5dTMg	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-09 03:45:15.005637+00	2022-04-09 03:45:15.005639+00	1sDUbshbMmRRO1OE44MwFA
00000000-0000-0000-0000-000000000000	363	Vwt6uBv1q3P0aOI8HiyPIw	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-19 02:39:25.56942+00	2022-04-19 02:39:25.569424+00	\N
00000000-0000-0000-0000-000000000000	364	-fYMKXuGDrc7YDa_xRzi-A	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-19 03:38:27.289568+00	2022-04-19 03:38:27.28957+00	Vwt6uBv1q3P0aOI8HiyPIw
00000000-0000-0000-0000-000000000000	365	Dxjzej1CmHqpcHhaOID5fg	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-19 14:29:38.60721+00	2022-04-19 14:29:38.607212+00	\N
00000000-0000-0000-0000-000000000000	366	Ttn8NpHzB0mlJf_9hYYSQg	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-19 23:56:08.550985+00	2022-04-19 23:56:08.550988+00	Dxjzej1CmHqpcHhaOID5fg
00000000-0000-0000-0000-000000000000	367	2GhdVhV1v-4XoyiKZ5-zAw	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-20 00:56:37.343529+00	2022-04-20 00:56:37.343532+00	Ttn8NpHzB0mlJf_9hYYSQg
00000000-0000-0000-0000-000000000000	368	i4Yomm_w4JefAmK-nmfp8Q	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-20 01:55:37.745864+00	2022-04-20 01:55:37.745866+00	2GhdVhV1v-4XoyiKZ5-zAw
00000000-0000-0000-0000-000000000000	369	rKe6nuFZ67a22b5wTP9rEA	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-20 04:07:18.366876+00	2022-04-20 04:07:18.366878+00	i4Yomm_w4JefAmK-nmfp8Q
00000000-0000-0000-0000-000000000000	370	A0yln1PmlBqbpI4Jv4jBNQ	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-20 14:00:43.230172+00	2022-04-20 14:00:43.230176+00	rKe6nuFZ67a22b5wTP9rEA
00000000-0000-0000-0000-000000000000	371	kC2p32cX1oCaS0emKVu0sw	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-20 14:59:43.272099+00	2022-04-20 14:59:43.272102+00	A0yln1PmlBqbpI4Jv4jBNQ
00000000-0000-0000-0000-000000000000	372	hcr66nf86t6TMkwgz6babQ	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-20 18:37:28.155577+00	2022-04-20 18:37:28.155579+00	kC2p32cX1oCaS0emKVu0sw
00000000-0000-0000-0000-000000000000	373	gAJsvH7D0qIgqTOQ17kgGQ	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-29 04:23:14.967381+00	2022-04-29 04:23:14.967384+00	hcr66nf86t6TMkwgz6babQ
00000000-0000-0000-0000-000000000000	374	XXHhBB-yk8ykr6PTdM3mtQ	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-29 05:22:44.921172+00	2022-04-29 05:22:44.921176+00	gAJsvH7D0qIgqTOQ17kgGQ
00000000-0000-0000-0000-000000000000	375	9YSeYpVKIOzeAVbl_L2bMA	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-29 18:55:29.592059+00	2022-04-29 18:55:29.592062+00	XXHhBB-yk8ykr6PTdM3mtQ
00000000-0000-0000-0000-000000000000	376	oqNitANoMqmK5OpvyRPEbg	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-30 00:02:44.713739+00	2022-04-30 00:02:44.713741+00	9YSeYpVKIOzeAVbl_L2bMA
00000000-0000-0000-0000-000000000000	377	mpZ0Nbk1A3u_wNDvrVOndA	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-30 03:21:16.162643+00	2022-04-30 03:21:16.162645+00	oqNitANoMqmK5OpvyRPEbg
00000000-0000-0000-0000-000000000000	378	LCFezdoET9BYGXaDjIXLVQ	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-30 04:20:17.264834+00	2022-04-30 04:20:17.264837+00	mpZ0Nbk1A3u_wNDvrVOndA
00000000-0000-0000-0000-000000000000	379	R19yYGx8xaWsEqN9ZhxdEw	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-30 05:19:28.752069+00	2022-04-30 05:19:28.752072+00	LCFezdoET9BYGXaDjIXLVQ
00000000-0000-0000-0000-000000000000	380	cuXI33XScIf-MgZoex0FAA	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-30 14:13:57.159809+00	2022-04-30 14:13:57.159812+00	R19yYGx8xaWsEqN9ZhxdEw
00000000-0000-0000-0000-000000000000	381	o65Ggvff9HGgV9nf4ekI4g	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-04-30 15:12:58.618934+00	2022-04-30 15:12:58.618937+00	cuXI33XScIf-MgZoex0FAA
00000000-0000-0000-0000-000000000000	382	JmF61aNuvgrEvBexeOrIVQ	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-05-08 03:08:42.02703+00	2022-05-08 03:08:42.027033+00	o65Ggvff9HGgV9nf4ekI4g
00000000-0000-0000-0000-000000000000	383	y_4MWPY7rhok2W3G03mCDg	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-05-08 04:07:42.442369+00	2022-05-08 04:07:42.442372+00	JmF61aNuvgrEvBexeOrIVQ
00000000-0000-0000-0000-000000000000	384	L3BUz9TiJHu1kn2gGsT09A	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-05-20 14:03:02.641252+00	2022-05-20 15:02:03.303583+00	\N
00000000-0000-0000-0000-000000000000	385	7boSdWUZ_jQoLJYjVhrqbg	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-05-20 15:02:03.304477+00	2022-05-23 00:25:18.158923+00	L3BUz9TiJHu1kn2gGsT09A
00000000-0000-0000-0000-000000000000	386	1PpHPY_PiFisGcykBH9f1g	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-05-23 00:25:18.160785+00	2022-05-23 04:29:19.804524+00	7boSdWUZ_jQoLJYjVhrqbg
00000000-0000-0000-0000-000000000000	387	--j9xLlDm1m1sTTBICcltw	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	t	2022-05-23 04:29:19.805584+00	2022-05-23 04:29:19.805587+00	1PpHPY_PiFisGcykBH9f1g
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."schema_migrations" ("version") FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
00
20220224000811
20220323170000
20220412150300
20220429010200
20220429102000
20220531120530
20220614074223
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."users" ("instance_id", "id", "aud", "role", "email", "encrypted_password", "email_confirmed_at", "invited_at", "confirmation_token", "confirmation_sent_at", "recovery_token", "recovery_sent_at", "email_change_token_new", "email_change", "email_change_sent_at", "last_sign_in_at", "raw_app_meta_data", "raw_user_meta_data", "is_super_admin", "created_at", "updated_at", "phone", "phone_confirmed_at", "phone_change", "phone_change_token", "phone_change_sent_at", "email_change_token_current", "email_change_confirm_status", "banned_until", "reauthentication_token", "reauthentication_sent_at") FROM stdin;
00000000-0000-0000-0000-000000000000	7bc09320-2922-4f85-b614-44f9369c3733	authenticated	authenticated	robert.aboukhalil@yahoo.com		\N	2021-08-31 23:53:11.491934+00	G3xzwd4HYSbuWfO6g3d0dQ	2021-08-31 23:53:11.491934+00		\N			\N	\N	{"provider": "email"}	null	f	2021-08-31 23:53:11.488522+00	2021-08-31 23:53:11.488522+00	\N	\N			\N		0	\N		\N
00000000-0000-0000-0000-000000000000	c661f0e6-f87d-4782-827a-bfbb2de14b6f	authenticated	authenticated	lunexa@gmail.com	$2a$10$AH3ytn6zFusrasXNUhvm6um8LIVF5sc3AXG.7SPzpqB9hryiU5mmW	2021-09-03 02:55:50.866839+00	\N		2021-09-03 02:55:20.358135+00		\N			\N	2021-09-03 02:59:39.828236+00	{"provider": "email"}	null	f	2021-09-03 02:55:20.354789+00	2021-09-03 02:55:20.354789+00	\N	\N			\N		0	\N		\N
00000000-0000-0000-0000-000000000000	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	authenticated	authenticated	robert.aboukhalil@gmail.com	$2a$10$wtJp957N04hC9lNsoIUSy.RzGdCN0l/arRpzT8uAprA4nxCoi7T/O	2021-08-31 17:56:13.399212+00	\N		2021-08-31 17:55:21.711434+00		2021-11-09 19:19:59.610831+00			\N	2022-05-20 14:03:02.641209+00	{"provider": "email"}	null	f	2021-08-31 17:55:21.703373+00	2022-05-23 04:29:19.806927+00	\N	\N			\N		0	\N		\N
\.


--
-- Data for Name: logs; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY "public"."logs" ("id", "time", "pathname", "status", "search") FROM stdin;
1	2021-08-19 23:00:49.674592+00	/	200	\N
2	2021-08-19 23:00:49.701937+00	/build/bundle.js	200	\N
3	2021-08-19 23:00:49.726468+00	/build/bundle.css	200	\N
4	2021-08-19 23:00:49.872784+00	/images/cli.cropped.png	200	\N
5	2021-08-19 23:29:19.411037+00	/	200	\N
6	2021-08-20 03:45:33.892696+00	/tutorials	200	\N
7	2021-08-20 03:45:34.133652+00	/build/bundle.js	200	\N
8	2021-08-20 03:45:34.712851+00	/data/dna-secrets/reads.fq	200	\N
9	2021-08-20 03:45:34.765793+00	/data/dna-secrets/reads.fq	200	\N
10	2021-08-20 03:45:34.959402+00	/data/dna-secrets/morereads.fq	200	\N
11	2021-08-20 03:45:35.03243+00	/data/dna-secrets/morereads.fq	200	\N
12	2021-08-20 03:47:12.855993+00	/tutorials	200	\N
13	2021-08-20 03:47:12.876357+00	/build/bundle.css	200	\N
14	2021-08-20 03:47:12.964579+00	/build/bundle.js	200	\N
15	2021-08-20 03:47:35.598855+00	/tutorials	200	\N
16	2021-08-20 03:47:35.632865+00	/build/bundle.css	200	\N
17	2021-08-20 03:47:35.660624+00	/build/bundle.js	200	\N
18	2021-08-20 03:47:38.240765+00	/build/bundle.js.map	404	\N
19	2021-08-20 03:47:38.29325+00	/build/bootstrap.min.css.map	404	\N
20	2021-08-20 03:47:56.05685+00	/build/bundle.css	200	\N
21	2021-08-20 03:47:56.056868+00	/tutorials	200	\N
22	2021-08-20 03:47:56.103554+00	/build/bundle.js	200	\N
23	2021-08-20 04:03:32.494853+00	/tutorials	200	\N
24	2021-08-20 04:03:32.550664+00	/build/bundle.css	200	\N
25	2021-08-20 04:03:32.749804+00	/build/bundle.js	200	\N
26	2021-08-20 04:04:37.653783+00	/tutorials	200	\N
27	2021-08-20 04:04:37.719662+00	/build/bundle.css	200	\N
28	2021-08-20 04:04:37.733696+00	/build/bundle.js	200	\N
29	2021-08-20 04:04:46.602625+00	/tutorials	200	\N
30	2021-08-20 04:04:46.656255+00	/build/bundle.js	200	\N
31	2021-08-20 04:04:46.682128+00	/build/bundle.css	200	\N
32	2021-08-20 04:04:49.734359+00	/tutorials	200	\N
33	2021-08-20 04:04:49.820362+00	/build/bundle.js	200	\N
34	2021-08-20 04:04:49.824466+00	/build/bundle.css	200	\N
35	2021-08-20 04:04:50.889063+00	/tutorials	200	\N
36	2021-08-20 04:04:50.967563+00	/build/bundle.css	200	\N
37	2021-08-20 04:04:50.972924+00	/build/bundle.js	200	\N
38	2021-08-20 04:04:52.101659+00	/tutorials	200	\N
39	2021-08-20 04:04:52.191042+00	/build/bundle.js	200	\N
40	2021-08-20 04:04:52.20576+00	/build/bundle.css	200	\N
41	2021-08-20 04:04:56.354121+00	/tutorials	200	\N
42	2021-08-20 04:04:56.4819+00	/build/bundle.js	200	\N
43	2021-08-20 04:04:56.497372+00	/build/bundle.css	200	\N
44	2021-08-20 04:04:57.527633+00	/tutorials	200	\N
45	2021-08-20 04:04:57.620231+00	/build/bundle.js	200	\N
46	2021-08-20 04:04:57.625944+00	/build/bundle.css	200	\N
47	2021-08-20 04:04:58.212004+00	/tutorials	200	\N
48	2021-08-20 04:04:58.27606+00	/build/bundle.js	200	\N
49	2021-08-20 04:04:58.29919+00	/build/bundle.css	200	\N
50	2021-08-20 04:04:59.595127+00	/tutorials	200	\N
51	2021-08-20 04:04:59.686578+00	/build/bundle.js	200	\N
52	2021-08-20 04:04:59.702612+00	/build/bundle.css	200	\N
53	2021-08-20 14:51:34.560275+00	/build/bundle.js	200	\N
54	2021-08-20 14:51:34.781532+00	/images/cli.cropped.png	200	\N
55	2021-08-20 14:52:14.887141+00	/data/bedtools-intro/cpg.bed	200	\N
56	2021-08-20 14:52:15.031822+00	/data/bedtools-intro/exons.bed	200	\N
57	2021-08-20 14:52:15.217373+00	/data/bedtools-intro/fHeart-DS15839.bed	200	\N
58	2021-08-20 14:52:15.283707+00	/build/bootstrap.min.css.map	404	\N
59	2021-08-20 14:52:15.340823+00	/build/bundle.js.map	200	\N
60	2021-08-20 14:52:15.416162+00	/data/bedtools-intro/fHeart-DS16621.bed	200	\N
61	2021-08-20 14:52:15.793065+00	/data/bedtools-intro/fSkin-DS19745.bed	200	\N
62	2021-08-20 14:52:15.931689+00	/data/bedtools-intro/gwas.bed	200	\N
63	2021-08-20 14:52:16.108279+00	/data/bedtools-intro/hesc.chromHmm.bed	200	\N
64	2021-08-20 14:52:16.265423+00	/data/bedtools-intro/genome.txt	200	\N
65	2021-08-20 14:52:24.206286+00	/igv-ui.css.map	404	\N
66	2021-08-20 14:52:24.234333+00	/igv.css.map	404	\N
67	2021-08-20 15:51:44.084217+00	/tutorials	200	\N
68	2021-08-20 15:51:44.148676+00	/build/bundle.js.map	200	\N
69	2021-08-20 15:51:44.193337+00	/build/bootstrap.min.css.map	404	\N
70	2021-08-20 15:51:44.316062+00	/igv.css.map	404	\N
71	2021-08-20 15:51:44.382882+00	/igv-ui.css.map	404	\N
72	2021-08-20 15:51:44.473604+00	/data/bedtools-intro/cpg.bed	200	\N
73	2021-08-20 15:51:44.620874+00	/data/bedtools-intro/exons.bed	200	\N
74	2021-08-20 15:51:44.796023+00	/data/bedtools-intro/fHeart-DS15839.bed	200	\N
75	2021-08-20 15:51:44.944976+00	/data/bedtools-intro/fHeart-DS16621.bed	200	\N
76	2021-08-20 15:51:45.121203+00	/data/bedtools-intro/fSkin-DS19745.bed	200	\N
77	2021-08-20 15:51:45.264817+00	/data/bedtools-intro/gwas.bed	200	\N
78	2021-08-20 15:51:45.472871+00	/data/bedtools-intro/hesc.chromHmm.bed	200	\N
79	2021-08-20 15:51:45.685775+00	/data/bedtools-intro/genome.txt	200	\N
80	2021-08-20 15:58:53.506418+00	/api/v1/ping	404	\N
81	2021-08-20 15:58:54.752368+00	/api/v1/ping	404	\N
82	2021-08-20 15:59:39.689157+00	/api/v1/ping	404	\N
83	2021-08-20 15:59:40.995498+00	/api/v1/ping	404	\N
84	2021-08-20 15:59:45.763054+00	/api/v1/ping	404	\N
85	2021-08-20 16:00:17.090698+00	/api/v1/ping	404	\N
86	2021-08-20 16:01:33.316037+00	/tutorials	200	\N
87	2021-08-20 16:01:33.340977+00	/build/bundle.css	200	\N
88	2021-08-20 16:01:33.536721+00	/build/bootstrap.min.css.map	404	\N
89	2021-08-20 16:01:33.589257+00	/build/bundle.js	200	\N
90	2021-08-20 16:01:34.135683+00	/igv.css.map	404	\N
91	2021-08-20 16:01:34.177651+00	/igv-ui.css.map	404	\N
92	2021-08-20 16:01:34.320087+00	/build/bundle.js.map	200	\N
93	2021-08-20 16:01:34.585663+00	/data/bedtools-intro/cpg.bed	200	\N
94	2021-08-20 16:01:34.756945+00	/data/bedtools-intro/exons.bed	200	\N
95	2021-08-20 16:01:34.956593+00	/data/bedtools-intro/fHeart-DS15839.bed	200	\N
96	2021-08-20 16:01:35.080553+00	/data/bedtools-intro/fHeart-DS16621.bed	200	\N
97	2021-08-20 16:01:35.260542+00	/data/bedtools-intro/fSkin-DS19745.bed	200	\N
98	2021-08-20 16:01:35.434135+00	/data/bedtools-intro/gwas.bed	200	\N
99	2021-08-20 16:01:35.566258+00	/data/bedtools-intro/hesc.chromHmm.bed	200	\N
100	2021-08-20 16:01:35.781152+00	/data/bedtools-intro/genome.txt	200	\N
101	2021-08-20 16:01:41.270391+00	/tutorials	200	\N
102	2021-08-20 16:01:41.294225+00	/build/bundle.js	200	\N
103	2021-08-20 16:01:41.300555+00	/build/bundle.css	200	\N
104	2021-08-20 16:01:41.354479+00	/build/bootstrap.min.css.map	404	\N
105	2021-08-20 16:01:41.423484+00	/build/bundle.js.map	200	\N
106	2021-08-20 16:01:41.527733+00	/igv-ui.css.map	404	\N
107	2021-08-20 16:01:41.583476+00	/igv.css.map	404	\N
108	2021-08-20 16:01:41.684769+00	/data/bedtools-intro/cpg.bed	200	\N
109	2021-08-20 16:01:41.765136+00	/data/bedtools-intro/exons.bed	200	\N
110	2021-08-20 16:01:41.871704+00	/data/bedtools-intro/fHeart-DS15839.bed	200	\N
111	2021-08-20 16:01:41.978227+00	/data/bedtools-intro/fHeart-DS16621.bed	200	\N
112	2021-08-20 16:01:41.998347+00	/data/bedtools-intro/fSkin-DS19745.bed	200	\N
113	2021-08-20 16:01:42.064162+00	/data/bedtools-intro/gwas.bed	200	\N
114	2021-08-20 16:01:42.136696+00	/data/bedtools-intro/hesc.chromHmm.bed	200	\N
115	2021-08-20 16:01:42.177544+00	/data/bedtools-intro/genome.txt	200	\N
116	2021-08-20 16:01:53.010821+00	/data/bedtools-intro/cpg.bed	200	\N
117	2021-08-20 16:01:53.063508+00	/data/bedtools-intro/exons.bed	200	\N
118	2021-08-20 16:01:53.139027+00	/data/bedtools-intro/fHeart-DS15839.bed	200	\N
119	2021-08-20 16:01:53.236672+00	/data/bedtools-intro/fHeart-DS16621.bed	200	\N
120	2021-08-20 16:01:53.298471+00	/data/bedtools-intro/fSkin-DS19745.bed	200	\N
121	2021-08-20 16:01:53.358217+00	/data/bedtools-intro/gwas.bed	200	\N
122	2021-08-20 16:01:53.424249+00	/data/bedtools-intro/hesc.chromHmm.bed	200	\N
123	2021-08-20 16:01:53.481336+00	/data/bedtools-intro/genome.txt	200	\N
124	2021-08-20 16:01:56.886263+00	/build/bundle.js.map	200	\N
125	2021-08-20 16:01:56.947161+00	/igv-ui.css.map	404	\N
126	2021-08-20 16:01:56.96403+00	/igv.css.map	404	\N
127	2021-08-20 16:01:56.979794+00	/build/bootstrap.min.css.map	404	\N
128	2021-08-20 16:01:58.720811+00	/build/bootstrap.min.css.map	404	\N
129	2021-08-20 16:01:58.856244+00	/build/bundle.js.map	200	\N
130	2021-08-20 16:02:39.311411+00	/build/bundle.js.map	200	\N
131	2021-08-20 16:02:39.325095+00	/igv-ui.css.map	404	\N
132	2021-08-20 16:02:39.339084+00	/build/bootstrap.min.css.map	404	\N
133	2021-08-20 16:02:39.360215+00	/igv.css.map	404	\N
134	2021-08-20 16:02:39.439643+00	/data/bedtools-intro/cpg.bed	200	\N
135	2021-08-20 16:02:39.597869+00	/data/bedtools-intro/exons.bed	200	\N
136	2021-08-20 16:02:39.727112+00	/data/bedtools-intro/fHeart-DS15839.bed	200	\N
137	2021-08-20 16:02:39.903683+00	/data/bedtools-intro/fHeart-DS16621.bed	200	\N
138	2021-08-20 16:02:40.038483+00	/data/bedtools-intro/fSkin-DS19745.bed	200	\N
139	2021-08-20 16:02:40.202079+00	/data/bedtools-intro/gwas.bed	200	\N
140	2021-08-20 16:02:40.354567+00	/data/bedtools-intro/hesc.chromHmm.bed	200	\N
141	2021-08-20 16:02:40.516369+00	/data/bedtools-intro/genome.txt	200	\N
142	2021-08-20 16:02:42.891717+00	/api/v1/ping	404	\N
143	2021-08-20 16:03:07.940786+00	/tutorials	200	\N
144	2021-08-20 16:03:08.019401+00	/build/bundle.js	200	\N
145	2021-08-20 16:03:08.034491+00	/build/bundle.css	200	\N
146	2021-08-20 16:03:08.158736+00	/build/bootstrap.min.css.map	404	\N
147	2021-08-20 16:03:08.179087+00	/build/bundle.js.map	200	\N
148	2021-08-20 16:03:08.376029+00	/data/bedtools-intro/cpg.bed	200	\N
149	2021-08-20 16:03:08.441915+00	/data/bedtools-intro/exons.bed	200	\N
150	2021-08-20 16:03:08.502135+00	/data/bedtools-intro/fHeart-DS15839.bed	200	\N
151	2021-08-20 16:03:08.562068+00	/data/bedtools-intro/fHeart-DS16621.bed	200	\N
152	2021-08-20 16:03:08.619908+00	/data/bedtools-intro/fSkin-DS19745.bed	200	\N
153	2021-08-20 16:03:08.686005+00	/data/bedtools-intro/gwas.bed	200	\N
154	2021-08-20 16:03:08.729957+00	/data/bedtools-intro/hesc.chromHmm.bed	200	\N
155	2021-08-20 16:03:08.796263+00	/data/bedtools-intro/genome.txt	200	\N
156	2021-08-20 16:03:17.194831+00	/tutorials	200	\N
157	2021-08-20 16:03:17.249609+00	/build/bundle.css	200	\N
158	2021-08-20 16:03:17.322775+00	/build/bootstrap.min.css.map	404	\N
159	2021-08-20 16:03:17.414126+00	/build/bundle.js	200	\N
160	2021-08-20 16:03:17.746373+00	/build/bundle.js.map	200	\N
161	2021-08-20 16:03:19.540187+00	/data/bedtools-intro/fHeart-DS15839.bed	200	\N
162	2021-08-20 16:03:19.544535+00	/data/bedtools-intro/cpg.bed	200	\N
163	2021-08-20 16:03:19.583601+00	/data/bedtools-intro/exons.bed	200	\N
164	2021-08-20 16:03:19.598579+00	/data/bedtools-intro/fHeart-DS16621.bed	200	\N
165	2021-08-20 16:03:19.614778+00	/data/bedtools-intro/fSkin-DS19745.bed	200	\N
166	2021-08-20 16:03:19.691686+00	/data/bedtools-intro/gwas.bed	200	\N
167	2021-08-20 16:03:19.737188+00	/data/bedtools-intro/hesc.chromHmm.bed	200	\N
168	2021-08-20 16:03:19.795605+00	/data/bedtools-intro/genome.txt	200	\N
169	2021-08-20 16:03:23.925473+00	/api/v1/ping	404	\N
170	2021-08-20 16:04:11.170219+00	/tutorials	200	\N
171	2021-08-20 16:04:11.202457+00	/build/bundle.css	200	\N
172	2021-08-20 16:04:11.212108+00	/build/bundle.js	200	\N
173	2021-08-20 16:04:11.343658+00	/build/bootstrap.min.css.map	404	\N
174	2021-08-20 16:04:11.467409+00	/build/bundle.js.map	200	\N
175	2021-08-20 16:04:11.894288+00	/data/bedtools-intro/cpg.bed	200	\N
176	2021-08-20 16:04:11.949525+00	/data/bedtools-intro/exons.bed	200	\N
177	2021-08-20 16:04:12.013773+00	/data/bedtools-intro/fHeart-DS15839.bed	200	\N
178	2021-08-20 16:04:12.050502+00	/data/bedtools-intro/fHeart-DS16621.bed	200	\N
179	2021-08-20 16:04:12.115406+00	/data/bedtools-intro/fSkin-DS19745.bed	200	\N
180	2021-08-20 16:04:12.166445+00	/data/bedtools-intro/gwas.bed	200	\N
181	2021-08-20 16:04:12.216117+00	/data/bedtools-intro/hesc.chromHmm.bed	200	\N
182	2021-08-20 16:04:12.273224+00	/data/bedtools-intro/genome.txt	200	\N
183	2021-08-20 16:07:07.076671+00	/api/v1/ping	200	\N
184	2021-08-20 16:07:58.028658+00	/api/v1/ping	200	\N
185	2021-08-20 16:08:46.30298+00	/api/v1/ping	200	\N
186	2021-08-20 16:08:57.794236+00	/api/v1/ping	200	\N
187	2021-08-20 16:09:05.472574+00	/api/v1/ping	200	\N
188	2021-08-20 16:09:22.569337+00	/api/v1/ping	200	\N
189	2021-08-20 16:10:41.929958+00	/api/v1/ping	200	\N
190	2021-08-20 16:10:45.952424+00	/api/v1/ping	200	\N
191	2021-08-20 16:10:52.820452+00	/api/v1/ping	200	\N
192	2021-08-20 16:10:53.003571+00	/api/v1/ping	200	\N
193	2021-08-20 16:10:53.657551+00	/api/v1/ping	200	\N
194	2021-08-20 16:10:53.799197+00	/api/v1/ping	200	\N
195	2021-08-20 16:10:53.995068+00	/api/v1/ping	200	\N
196	2021-08-20 16:10:54.088132+00	/api/v1/ping	200	\N
197	2021-08-20 16:10:58.049088+00	/api/v1/ping	200	\N
198	2021-08-20 16:10:58.177665+00	/api/v1/ping	200	\N
199	2021-08-20 16:10:58.327701+00	/api/v1/ping	200	\N
200	2021-08-20 16:11:03.343164+00	/tutorials	200	\N
201	2021-08-20 16:11:03.404666+00	/build/bundle.js	200	\N
202	2021-08-20 16:11:03.421406+00	/build/bundle.css	200	\N
203	2021-08-20 16:11:03.62354+00	/build/bundle.js.map	200	\N
204	2021-08-20 16:11:03.642638+00	/build/bootstrap.min.css.map	404	\N
205	2021-08-20 16:11:04.118929+00	/data/bedtools-intro/cpg.bed	200	\N
206	2021-08-20 16:11:04.721109+00	/data/bedtools-intro/exons.bed	200	\N
207	2021-08-20 16:11:04.851533+00	/data/bedtools-intro/fHeart-DS15839.bed	200	\N
208	2021-08-20 16:11:05.071335+00	/data/bedtools-intro/fHeart-DS16621.bed	200	\N
209	2021-08-20 16:11:05.231415+00	/data/bedtools-intro/fSkin-DS19745.bed	200	\N
210	2021-08-20 16:11:05.403227+00	/data/bedtools-intro/gwas.bed	200	\N
211	2021-08-20 16:11:05.540353+00	/data/bedtools-intro/hesc.chromHmm.bed	200	\N
212	2021-08-20 16:11:05.712557+00	/data/bedtools-intro/genome.txt	200	\N
213	2021-08-20 16:11:17.014731+00	/tutorials	200	\N
214	2021-08-20 16:11:17.069552+00	/build/bundle.css	200	\N
215	2021-08-20 16:11:17.08295+00	/build/bundle.js	200	\N
216	2021-08-20 16:11:17.179978+00	/build/bootstrap.min.css.map	404	\N
217	2021-08-20 16:11:17.184828+00	/build/bundle.js.map	200	\N
218	2021-08-20 16:11:17.479851+00	/data/bedtools-intro/cpg.bed	200	\N
219	2021-08-20 16:11:17.557034+00	/data/bedtools-intro/exons.bed	200	\N
220	2021-08-20 16:11:17.61071+00	/data/bedtools-intro/fHeart-DS15839.bed	200	\N
221	2021-08-20 16:11:17.676155+00	/data/bedtools-intro/fHeart-DS16621.bed	200	\N
535	2021-08-25 14:54:41.945122+00	/api/v1/ping	200	
222	2021-08-20 16:11:17.728127+00	/data/bedtools-intro/fSkin-DS19745.bed	200	\N
223	2021-08-20 16:11:17.788778+00	/data/bedtools-intro/gwas.bed	200	\N
224	2021-08-20 16:11:17.831858+00	/data/bedtools-intro/hesc.chromHmm.bed	200	\N
225	2021-08-20 16:11:17.888726+00	/data/bedtools-intro/genome.txt	200	\N
226	2021-08-20 16:11:35.759503+00	/data/bedtools-intro/cpg.bed	200	\N
227	2021-08-20 16:11:40.457796+00	/api/v1/ping	200	\N
228	2021-08-20 16:11:40.901938+00	/api/v1/ping	200	\N
229	2021-08-20 16:12:57.393695+00	/api/v1/ping	200	\N
230	2021-08-20 16:13:57.662492+00	/tutorials	200	\N
231	2021-08-20 16:13:57.752688+00	/build/bundle.css	200	\N
232	2021-08-20 16:13:57.77672+00	/build/bundle.js	200	\N
233	2021-08-20 16:13:58.051032+00	/build/bootstrap.min.css.map	404	\N
234	2021-08-20 16:13:58.069712+00	/build/bundle.js.map	200	\N
235	2021-08-20 16:13:58.453278+00	/data/bedtools-intro/exons.bed	200	\N
236	2021-08-20 16:13:58.594023+00	/data/bedtools-intro/fHeart-DS15839.bed	200	\N
237	2021-08-20 16:13:58.752056+00	/data/bedtools-intro/fHeart-DS16621.bed	200	\N
238	2021-08-20 16:13:58.90794+00	/data/bedtools-intro/fSkin-DS19745.bed	200	\N
239	2021-08-20 16:13:59.061561+00	/data/bedtools-intro/gwas.bed	200	\N
240	2021-08-20 16:13:59.209628+00	/data/bedtools-intro/hesc.chromHmm.bed	200	\N
241	2021-08-20 16:13:59.367999+00	/data/bedtools-intro/genome.txt	200	\N
242	2021-08-20 16:14:52.096377+00	/api/v1/ping	200	\N
243	2021-08-20 16:21:55.964608+00	/tutorials	200	\N
244	2021-08-20 16:21:56.069604+00	/build/bundle.css	200	\N
245	2021-08-20 16:21:56.232205+00	/build/bundle.js	200	\N
246	2021-08-20 16:21:56.298743+00	/build/bootstrap.min.css.map	404	\N
247	2021-08-20 16:21:56.710627+00	/build/bundle.js.map	200	\N
248	2021-08-20 16:21:56.951054+00	/data/bedtools-intro/exons.bed	200	\N
249	2021-08-20 16:21:57.196995+00	/data/bedtools-intro/fHeart-DS15839.bed	200	\N
250	2021-08-20 16:21:57.390342+00	/data/bedtools-intro/fHeart-DS16621.bed	200	\N
251	2021-08-20 16:21:57.559064+00	/data/bedtools-intro/fSkin-DS19745.bed	200	\N
252	2021-08-20 16:21:57.708806+00	/data/bedtools-intro/gwas.bed	200	\N
253	2021-08-20 16:21:57.89072+00	/data/bedtools-intro/hesc.chromHmm.bed	200	\N
254	2021-08-20 16:21:58.033068+00	/data/bedtools-intro/genome.txt	200	\N
255	2021-08-20 16:22:01.851271+00	/api/v1/ping	200	\N
256	2021-08-20 16:22:14.477455+00	/api/v1/ping	200	\N
257	2021-08-20 16:22:15.151284+00	/api/v1/ping	200	\N
258	2021-08-20 16:22:15.588266+00	/api/v1/ping	200	\N
259	2021-08-20 16:22:15.688856+00	/api/v1/ping	200	\N
260	2021-08-20 16:22:15.875028+00	/api/v1/ping	200	\N
261	2021-08-20 16:22:16.043867+00	/api/v1/ping	200	\N
262	2021-08-20 16:22:17.131289+00	/api/v1/ping	200	\N
263	2021-08-20 16:22:17.969292+00	/api/v1/ping	200	\N
264	2021-08-20 16:25:53.365069+00	/api/v1/ping	200	\N
265	2021-08-20 16:26:47.907671+00	/api/v1/ping	200	\N
266	2021-08-20 20:30:57.808988+00	/tutorials	200	\N
267	2021-08-20 20:30:58.070244+00	/data/bedtools-intro/exons.bed	200	\N
268	2021-08-20 20:30:58.22337+00	/data/bedtools-intro/fHeart-DS15839.bed	200	\N
269	2021-08-20 20:30:58.405384+00	/data/bedtools-intro/fHeart-DS16621.bed	200	\N
270	2021-08-20 20:30:58.549641+00	/data/bedtools-intro/fSkin-DS19745.bed	200	\N
271	2021-08-20 20:30:58.692484+00	/data/bedtools-intro/gwas.bed	200	\N
272	2021-08-20 20:30:58.875254+00	/data/bedtools-intro/hesc.chromHmm.bed	200	\N
273	2021-08-20 20:30:59.002371+00	/data/bedtools-intro/genome.txt	200	\N
274	2021-08-20 21:16:06.453382+00	/tutorials	200	\N
275	2021-08-20 21:16:12.248389+00	/tutorials	200	\N
276	2021-08-20 21:46:03.508616+00	/data/bedtools-intro/exons.bed	200	
277	2021-08-20 21:46:03.683304+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
278	2021-08-20 21:46:03.842816+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
279	2021-08-20 21:46:03.988777+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
280	2021-08-20 21:46:04.142092+00	/data/bedtools-intro/gwas.bed	200	
281	2021-08-20 21:46:04.305154+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
282	2021-08-20 21:46:04.472266+00	/data/bedtools-intro/genome.txt	200	
283	2021-08-20 21:46:08.826663+00	/tutorials	200	?id=bedtools-intro
284	2021-08-20 21:46:08.905046+00	/build/bundle.js	200	
285	2021-08-20 21:46:08.973643+00	/build/bundle.css	200	
286	2021-08-20 21:46:09.317308+00	/data/bedtools-intro/exons.bed	200	
287	2021-08-20 21:46:09.339362+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
288	2021-08-20 21:46:09.38422+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
289	2021-08-20 21:46:09.434434+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
290	2021-08-20 21:46:09.486439+00	/data/bedtools-intro/gwas.bed	200	
291	2021-08-20 21:46:09.567671+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
292	2021-08-20 21:46:09.631986+00	/data/bedtools-intro/genome.txt	200	
293	2021-08-20 21:46:23.944446+00	/api/v1/ping	200	
294	2021-08-20 21:46:24.293388+00	/api/v1/ping	200	
295	2021-08-20 21:46:24.457456+00	/api/v1/ping	200	
296	2021-08-20 21:46:25.140637+00	/tutorials	200	?id=bedtools-intro&step=3
297	2021-08-20 21:46:25.421166+00	/data/bedtools-intro/exons.bed	200	
298	2021-08-20 21:46:25.445269+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
299	2021-08-20 21:46:25.492836+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
300	2021-08-20 21:46:25.536654+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
301	2021-08-20 21:46:25.583189+00	/data/bedtools-intro/gwas.bed	200	
302	2021-08-20 21:46:25.636754+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
303	2021-08-20 21:46:25.693053+00	/data/bedtools-intro/genome.txt	200	
304	2021-08-20 21:59:19.92577+00	/	200	
305	2021-08-20 21:59:19.966881+00	/build/bundle.css	200	
306	2021-08-20 21:59:20.139435+00	/build/bundle.js	200	
307	2021-08-20 21:59:20.336467+00	/images/cli.cropped.png	200	
308	2021-08-20 21:59:23.643226+00	/tutorials	200	?id=bowtie2-intro
309	2021-08-20 21:59:24.252838+00	/data/bowtie2-intro/reads_1.fq	200	
310	2021-08-20 21:59:24.311862+00	/data/bowtie2-intro/reads_1.fq	200	
311	2021-08-20 21:59:24.47114+00	/data/bowtie2-intro/reads_2.fq	200	
312	2021-08-20 21:59:24.559468+00	/data/bowtie2-intro/reads_2.fq	200	
313	2021-08-20 21:59:24.712332+00	/data/bowtie2-intro/longreads.fq	200	
314	2021-08-20 21:59:24.778498+00	/data/bowtie2-intro/longreads.fq	200	
315	2021-08-21 02:08:10.00267+00	/	200	
316	2021-08-21 02:08:10.858846+00	/	200	
317	2021-08-21 02:08:11.1567+00	/build/bundle.css	200	
318	2021-08-21 02:08:11.348585+00	/build/bundle.js	200	
319	2021-08-21 02:08:12.014341+00	/images/cli.png	200	
320	2021-08-21 20:23:49.055231+00	/build/bundle.js	200	
321	2021-08-21 20:23:49.40496+00	/images/cli.png	200	
322	2021-08-21 20:26:39.118183+00	/	200	
323	2021-08-21 20:26:39.160489+00	/build/bundle.css	200	
324	2021-08-21 20:26:39.188077+00	/build/bundle.js	200	
325	2021-08-21 20:26:39.380826+00	/images/cli.png	200	
326	2021-08-21 20:26:41.218443+00	/playground	200	
327	2021-08-21 20:26:43.99348+00	/data/bedtools-intro/exons.bed	200	
328	2021-08-21 20:26:44.140918+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
329	2021-08-21 20:26:44.297641+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
330	2021-08-21 20:26:44.483349+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
331	2021-08-21 20:26:44.60441+00	/data/bedtools-intro/gwas.bed	200	
332	2021-08-21 20:26:44.766383+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
333	2021-08-21 20:26:44.975473+00	/data/bedtools-intro/genome.txt	200	
334	2021-08-22 20:35:20.503739+00	/build/bundle.css	200	
335	2021-08-22 20:35:20.503746+00	/build/bundle.js	200	
336	2021-08-22 20:35:21.010599+00	/images/cli.png	200	
337	2021-08-22 20:35:24.914296+00	/data/bedtools-intro/exons.bed	200	
338	2021-08-22 20:35:25.080825+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
339	2021-08-22 20:35:25.208+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
340	2021-08-22 20:35:25.376669+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
341	2021-08-22 20:35:25.55299+00	/data/bedtools-intro/gwas.bed	200	
342	2021-08-22 20:35:25.685862+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
343	2021-08-22 20:35:25.859061+00	/data/bedtools-intro/genome.txt	200	
344	2021-08-22 20:35:48.361479+00	/tutorials	200	?id=bowtie2-intro
345	2021-08-22 20:36:15.239681+00	/tutorials	200	?id=bowtie2-intro
346	2021-08-23 00:13:32.52668+00	/data/bedtools-intro/exons.bed	200	
347	2021-08-23 00:13:32.651544+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
348	2021-08-23 00:13:32.813186+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
349	2021-08-23 00:13:32.95722+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
350	2021-08-23 00:13:33.110611+00	/data/bedtools-intro/gwas.bed	200	
351	2021-08-23 00:13:33.286347+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
352	2021-08-23 00:13:33.458493+00	/data/bedtools-intro/genome.txt	200	
353	2021-08-23 00:13:41.921614+00	/tutorials	200	?id=bedtools-intro
354	2021-08-23 00:13:42.129314+00	/data/bedtools-intro/exons.bed	200	
355	2021-08-23 00:13:42.152867+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
356	2021-08-23 00:13:42.208995+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
357	2021-08-23 00:13:42.254815+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
358	2021-08-23 00:13:42.343167+00	/data/bedtools-intro/gwas.bed	200	
359	2021-08-23 00:13:42.375155+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
360	2021-08-23 00:13:42.444929+00	/data/bedtools-intro/genome.txt	200	
361	2021-08-23 01:27:50.240916+00	/data/bedtools-intro/exons.bed	200	
362	2021-08-23 01:27:50.424054+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
363	2021-08-23 01:27:50.602593+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
364	2021-08-23 01:27:50.882994+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
365	2021-08-23 01:27:51.137583+00	/data/bedtools-intro/gwas.bed	200	
366	2021-08-23 01:27:51.378609+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
367	2021-08-23 01:27:51.664352+00	/data/bedtools-intro/genome.txt	200	
368	2021-08-23 01:27:53.903554+00	/tutorials	200	?id=bedtools-intro
369	2021-08-23 01:27:53.912359+00	/build/bundle.css	200	
370	2021-08-23 01:27:54.126295+00	/build/bundle.js	200	
371	2021-08-23 01:27:54.723429+00	/data/bedtools-intro/exons.bed	200	
372	2021-08-23 01:27:54.774411+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
373	2021-08-23 01:27:54.842002+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
374	2021-08-23 01:27:54.898253+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
375	2021-08-23 01:27:54.948438+00	/data/bedtools-intro/gwas.bed	200	
376	2021-08-23 01:27:55.012746+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
377	2021-08-23 01:27:55.089849+00	/data/bedtools-intro/genome.txt	200	
378	2021-08-23 01:27:58.427786+00	/tutorials	200	?id=bedtools-intro
379	2021-08-23 01:27:58.612291+00	/data/bedtools-intro/exons.bed	200	
380	2021-08-23 01:27:58.698375+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
381	2021-08-23 01:27:58.755307+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
382	2021-08-23 01:27:58.825829+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
383	2021-08-23 01:27:58.849822+00	/data/bedtools-intro/gwas.bed	200	
384	2021-08-23 01:27:58.903657+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
385	2021-08-23 01:27:58.95202+00	/data/bedtools-intro/genome.txt	200	
386	2021-08-23 17:04:18.433166+00	/build/bundle.js	200	
387	2021-08-23 17:04:18.689949+00	/images/cli.png	200	
388	2021-08-23 17:04:19.288859+00	/	200	
389	2021-08-23 17:04:19.346295+00	/build/bundle.css	200	
390	2021-08-23 17:04:19.371602+00	/build/bundle.js	200	
391	2021-08-23 17:04:19.512435+00	/images/cli.png	200	
392	2021-08-23 17:06:01.968924+00	/	200	
393	2021-08-23 17:06:02.197109+00	/build/bundle.css	200	
394	2021-08-23 17:06:02.272012+00	/build/bundle.js	200	
395	2021-08-23 17:06:02.435923+00	/images/cli.png	200	
396	2021-08-23 17:16:45.470577+00	/	200	
397	2021-08-23 17:16:45.523419+00	/build/bundle.css	200	
398	2021-08-23 17:16:45.695753+00	/build/bundle.js	200	
399	2021-08-23 17:16:45.8948+00	/images/cli.png	200	
400	2021-08-23 17:16:57.765681+00	/data/bedtools-intro/exons.bed	200	
401	2021-08-23 17:16:57.910231+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
402	2021-08-23 17:16:58.092922+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
403	2021-08-23 17:16:58.277347+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
404	2021-08-23 17:16:58.438877+00	/data/bedtools-intro/gwas.bed	200	
405	2021-08-23 17:16:58.597797+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
406	2021-08-23 17:16:58.766997+00	/data/bedtools-intro/genome.txt	200	
407	2021-08-23 17:16:59.243277+00	/api/v1/ping	200	
408	2021-08-23 17:16:59.584102+00	/api/v1/ping	200	
409	2021-08-23 17:16:59.712426+00	/api/v1/ping	200	
410	2021-08-23 17:16:59.870332+00	/api/v1/ping	200	
411	2021-08-23 17:17:00.788024+00	/data/bedtools-intro/exons.bed	200	
412	2021-08-23 17:17:04.068626+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
413	2021-08-23 17:17:04.085351+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
414	2021-08-23 17:17:04.169727+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
415	2021-08-23 17:17:04.217755+00	/data/bedtools-intro/gwas.bed	200	
416	2021-08-23 17:17:04.302661+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
417	2021-08-23 17:17:04.333589+00	/data/bedtools-intro/genome.txt	200	
418	2021-08-23 19:33:29.153871+00	/	200	
419	2021-08-23 19:33:29.190236+00	/build/bundle.css	200	
420	2021-08-23 19:33:29.242302+00	/build/bundle.js	200	
421	2021-08-23 19:33:29.358361+00	/images/cli.png	200	
422	2021-08-23 20:09:50.153581+00	/tutorials	200	?id=bowtie2-intro&step=1
423	2021-08-23 20:38:25.827646+00	/tutorials	200	?id=bowtie2-intro&step=1
424	2021-08-23 20:38:25.882688+00	/build/bundle.css	200	
425	2021-08-23 20:38:26.045469+00	/build/bundle.js	200	
426	2021-08-23 20:49:37.528714+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
427	2021-08-23 20:49:37.77638+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
428	2021-08-23 20:49:37.938798+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
429	2021-08-23 20:49:38.112343+00	/data/bedtools-intro/gwas.bed	200	
430	2021-08-23 20:49:38.387824+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
431	2021-08-23 20:49:38.558363+00	/data/bedtools-intro/genome.txt	200	
432	2021-08-25 00:25:00.146031+00	/build/bundle.js	200	
433	2021-08-25 00:25:00.614662+00	/images/cli.png	200	
434	2021-08-25 00:25:01.360986+00	/	200	
435	2021-08-25 00:25:01.463422+00	/build/bundle.js	200	
436	2021-08-25 00:25:01.548161+00	/images/cli.png	200	
437	2021-08-25 00:25:01.620949+00	/build/bundle.css	200	
438	2021-08-25 02:08:15.808339+00	/	200	
439	2021-08-25 02:08:15.903627+00	/build/bundle.css	200	
440	2021-08-25 02:08:16.264166+00	/build/bundle.js	200	
441	2021-08-25 02:08:16.527981+00	/images/cli.png	200	
442	2021-08-25 02:08:23.604708+00	/tutorials	200	?id=terminal-basics
443	2021-08-25 02:08:24.730343+00	/data/terminal-basics/orders.tsv	200	
444	2021-08-25 02:08:24.889804+00	/data/terminal-basics/ref.fa	200	
445	2021-08-25 02:08:25.078081+00	/data/terminal-basics/ref.fa.bak	200	
446	2021-08-25 02:09:19.931793+00	/api/v1/ping	200	
447	2021-08-25 02:11:35.576165+00	/api/v1/ping	200	
448	2021-08-25 02:11:49.096032+00	/data/terminal-basics/orders.tsv	200	
449	2021-08-25 02:12:36.04612+00	/api/v1/ping	200	
450	2021-08-25 02:13:04.0862+00	/api/v1/ping	200	
451	2021-08-25 02:14:25.184849+00	/api/v1/ping	200	
452	2021-08-25 02:15:00.274319+00	/data/terminal-basics/ref.fa	200	
453	2021-08-25 02:16:45.745243+00	/data/terminal-basics/ref.fa.bak	200	
454	2021-08-25 02:17:42.645324+00	/api/v1/ping	200	
455	2021-08-25 02:20:18.528053+00	/api/v1/ping	200	
456	2021-08-25 02:20:25.391638+00	/tutorials	200	?id=bedtools-intro
457	2021-08-25 02:20:28.027421+00	/data/bedtools-intro/cpg.bed	200	
458	2021-08-25 02:20:28.207107+00	/data/bedtools-intro/exons.bed	200	
459	2021-08-25 02:20:28.489901+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
460	2021-08-25 02:20:28.719286+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
461	2021-08-25 02:20:28.981464+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
462	2021-08-25 02:20:29.262936+00	/data/bedtools-intro/gwas.bed	200	
463	2021-08-25 02:20:29.448548+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
464	2021-08-25 02:20:29.639306+00	/data/bedtools-intro/genome.txt	200	
465	2021-08-25 02:20:32.549642+00	/playground	200	
466	2021-08-25 02:21:42.287481+00	/tutorials	200	?id=samtools-intro
467	2021-08-25 02:21:43.082826+00	/data/samtools-intro/sample.sam	200	
468	2021-08-25 02:21:43.178468+00	/data/samtools-intro/sample.sam	200	
469	2021-08-25 14:44:31.845397+00	/build/bundle.js	200	
470	2021-08-25 14:44:32.151575+00	/images/cli.png	200	
471	2021-08-25 14:44:36.192709+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
472	2021-08-25 14:44:36.277184+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
473	2021-08-25 14:44:36.449166+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
474	2021-08-25 14:44:36.598503+00	/data/bedtools-intro/gwas.bed	200	
475	2021-08-25 14:44:36.736012+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
476	2021-08-25 14:44:36.888377+00	/data/bedtools-intro/genome.txt	200	
477	2021-08-25 14:44:46.24448+00	/tutorials	200	?id=terminal-basics
478	2021-08-25 14:44:46.528097+00	/data/terminal-basics/orders.tsv	200	
479	2021-08-25 14:44:46.655692+00	/data/terminal-basics/ref.fa	200	
480	2021-08-25 14:44:46.861774+00	/data/terminal-basics/ref.fa.bak	200	
481	2021-08-25 14:47:58.49777+00	/data/terminal-basics/orders.tsv	200	
482	2021-08-25 14:47:58.605877+00	/data/terminal-basics/ref.fa	200	
483	2021-08-25 14:47:58.763365+00	/data/terminal-basics/ref.fa.bak	200	
484	2021-08-25 14:48:22.265643+00	/api/v1/ping	200	
485	2021-08-25 14:48:55.654533+00	/api/v1/ping	200	
486	2021-08-25 14:48:59.317236+00	/data/terminal-basics/orders.tsv	200	
487	2021-08-25 14:49:25.581769+00	/api/v1/ping	200	
488	2021-08-25 14:49:42.213702+00	/api/v1/ping	200	
489	2021-08-25 14:50:01.033059+00	/api/v1/ping	200	
490	2021-08-25 14:50:38.844933+00	/data/terminal-basics/ref.fa	200	
491	2021-08-25 14:50:56.571568+00	/data/terminal-basics/ref.fa.bak	200	
492	2021-08-25 14:51:31.62565+00	/api/v1/ping	200	
493	2021-08-25 14:52:14.104483+00	/api/v1/ping	200	
494	2021-08-25 14:52:32.136662+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
495	2021-08-25 14:52:32.282578+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
496	2021-08-25 14:52:32.45812+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
497	2021-08-25 14:52:32.599004+00	/data/bedtools-intro/gwas.bed	200	
498	2021-08-25 14:52:32.799683+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
499	2021-08-25 14:52:32.952701+00	/data/bedtools-intro/genome.txt	200	
500	2021-08-25 14:52:34.247652+00	/api/v1/ping	200	
501	2021-08-25 14:52:34.755711+00	/api/v1/ping	200	
502	2021-08-25 14:52:36.751325+00	/api/v1/ping	200	
503	2021-08-25 14:52:37.181914+00	/api/v1/ping	200	
504	2021-08-25 14:52:37.611512+00	/api/v1/ping	200	
505	2021-08-25 14:52:42.15771+00	/api/v1/ping	200	
506	2021-08-25 14:52:43.018702+00	/data/bedtools-intro/gwas.bed	200	
507	2021-08-25 14:52:43.097411+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
508	2021-08-25 14:52:46.439683+00	/api/v1/ping	200	
509	2021-08-25 14:52:51.434432+00	/api/v1/ping	200	
510	2021-08-25 14:52:53.290311+00	/api/v1/ping	200	
511	2021-08-25 14:52:57.534888+00	/api/v1/ping	200	
512	2021-08-25 14:52:59.471633+00	/api/v1/ping	200	
513	2021-08-25 14:53:00.651576+00	/data/bedtools-intro/genome.txt	200	
514	2021-08-25 14:53:01.960419+00	/api/v1/ping	200	
515	2021-08-25 14:53:17.822257+00	/api/v1/ping	200	
516	2021-08-25 14:53:17.844411+00	/api/v1/ping	200	
517	2021-08-25 14:53:18.552633+00	/api/v1/ping	200	
518	2021-08-25 14:53:19.905179+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
519	2021-08-25 14:53:19.993794+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
520	2021-08-25 14:53:20.836829+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
521	2021-08-25 14:53:21.906124+00	/api/v1/ping	200	
522	2021-08-25 14:53:48.853269+00	/api/v1/ping	200	
523	2021-08-25 14:53:59.796829+00	/api/v1/ping	200	
524	2021-08-25 14:54:00.322151+00	/api/v1/ping	200	
525	2021-08-25 14:54:05.560362+00	/api/v1/ping	200	
526	2021-08-25 14:54:07.345804+00	/api/v1/ping	200	
527	2021-08-25 14:54:10.656457+00	/api/v1/ping	200	
528	2021-08-25 14:54:14.23227+00	/api/v1/ping	200	
529	2021-08-25 14:54:36.038004+00	/api/v1/ping	200	
530	2021-08-25 14:54:38.698547+00	/tutorials	200	?id=samtools-intro
531	2021-08-25 14:54:39.04862+00	/data/samtools-intro/sample.sam	200	
532	2021-08-25 14:54:39.098227+00	/data/samtools-intro/sample.sam	200	
533	2021-08-25 14:54:40.421068+00	/api/v1/ping	200	
534	2021-08-25 14:54:41.058371+00	/api/v1/ping	200	
536	2021-08-25 14:54:44.800688+00	/api/v1/ping	200	
537	2021-08-25 14:54:49.854115+00	/api/v1/ping	200	
538	2021-08-25 14:54:54.333495+00	/api/v1/ping	200	
539	2021-08-25 14:54:58.011684+00	/data/samtools-intro/sample.bam.bai	200	
540	2021-08-25 14:54:58.206213+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.s4j2umnpo1
541	2021-08-25 14:54:58.286808+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.b0i4ajp5zl
542	2021-08-25 14:54:58.361369+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.rxo4o14j09
543	2021-08-25 14:54:58.412737+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.ir2se26zq1
544	2021-08-25 14:55:12.586145+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.id0mjbumd5
545	2021-08-25 14:55:12.586149+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.njyjhbiw2pm
546	2021-08-25 14:55:12.607792+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.v1jvf29tbh
547	2021-08-25 14:55:12.609901+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.djil8ky0ajt
548	2021-08-25 14:55:17.120172+00	/api/v1/ping	200	
549	2021-08-25 14:55:49.151412+00	/build/bootstrap.min.css.map	404	
550	2021-08-25 14:55:49.185327+00	/igv-ui.css.map	404	
551	2021-08-25 14:55:49.190127+00	/igv.css.map	404	
552	2021-08-25 14:55:49.257054+00	/build/bundle.js.map	200	
553	2021-08-25 14:56:13.490894+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.ezqeosusilp
554	2021-08-25 14:56:13.496775+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.v4pt4y4ii5
555	2021-08-25 14:56:13.518124+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.2490caecfzi
556	2021-08-25 14:56:13.527216+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.20i7ocb2s55
557	2021-08-25 14:56:56.839238+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.bimiegu37h6
558	2021-08-25 14:56:56.848662+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.ygjcm7mp3b
559	2021-08-25 14:56:56.860406+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.h3ut2zlbej9
560	2021-08-25 14:56:56.878258+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.tu4d28mjl5p
561	2021-08-25 14:57:22.440752+00	/api/v1/ping	200	
562	2021-08-25 14:57:23.003475+00	/api/v1/ping	200	
563	2021-08-25 14:57:23.57046+00	/api/v1/ping	200	
564	2021-08-25 14:57:24.254376+00	/api/v1/ping	200	
565	2021-08-25 14:57:24.456164+00	/api/v1/ping	200	
566	2021-08-25 14:57:24.92915+00	/api/v1/ping	200	
567	2021-08-25 14:57:26.837438+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.9kz0tsje1tv
568	2021-08-25 14:57:26.857989+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.zrmxc56mmh
569	2021-08-25 14:57:26.862629+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.gh05lgzsj8p
570	2021-08-25 14:57:26.923341+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.qhzevb8ns0r
571	2021-08-25 14:57:54.391896+00	/tutorials	200	?id=samtools-intro&step=6
572	2021-08-25 14:57:54.435924+00	/build/bundle.css	200	
573	2021-08-25 14:57:54.477927+00	/build/bundle.js	200	
574	2021-08-25 14:57:54.807604+00	/build/bootstrap.min.css.map	404	
575	2021-08-25 14:57:54.917485+00	/build/bundle.js.map	200	
576	2021-08-25 14:57:55.288566+00	/igv-ui.css.map	404	
577	2021-08-25 14:57:55.349768+00	/igv.css.map	404	
578	2021-08-25 14:57:57.197222+00	/data/samtools-intro/sample.sam	200	
579	2021-08-25 14:57:57.211443+00	/data/samtools-intro/sample.sam	200	
580	2021-08-25 14:58:01.926625+00	/data/samtools-intro/sample.bam.bai	200	
581	2021-08-25 14:58:01.937781+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.um95tsj6dip
582	2021-08-25 14:58:01.952032+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.46rd27ciivs
583	2021-08-25 14:58:01.980683+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.mp462w576x
584	2021-08-25 14:58:02.038359+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.9rjopplho4
585	2021-08-25 14:58:31.723466+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.n8ivqx0dhx
586	2021-08-25 14:58:31.728788+00	/data/samtools-intro/sample.bam.bai	200	
587	2021-08-25 14:58:31.754355+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.mbuycco4u9
588	2021-08-25 14:58:31.802235+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.olzu0196asd
589	2021-08-25 14:58:31.852721+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.vnbdj7m73j
590	2021-08-25 14:58:43.02039+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.tkop7cdqee
591	2021-08-25 14:58:43.063085+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.rtvn9n0ywqq
592	2021-08-25 14:58:46.023616+00	/tutorials	200	?id=samtools-intro&step=6
593	2021-08-25 14:58:49.250405+00	/tutorials	200	?id=samtools-intro&step=6
594	2021-08-25 14:58:49.67272+00	/tutorials	200	?id=samtools-intro&step=6
595	2021-08-25 14:58:50.160156+00	/tutorials	200	?id=samtools-intro&step=6
596	2021-08-25 14:58:58.001099+00	/tutorials	200	?id=samtools-intro&step=6
597	2021-08-25 14:58:58.058726+00	/build/bundle.js	200	
598	2021-08-25 14:58:58.067371+00	/build/bundle.css	200	
599	2021-08-25 14:58:58.252952+00	/build/bundle.js.map	200	
600	2021-08-25 14:58:58.298543+00	/build/bootstrap.min.css.map	404	
601	2021-08-25 14:58:58.51356+00	/igv-ui.css.map	404	
602	2021-08-25 14:58:58.518842+00	/igv.css.map	404	
603	2021-08-25 14:58:59.331399+00	/data/samtools-intro/sample.sam	200	
604	2021-08-25 14:58:59.396056+00	/data/samtools-intro/sample.sam	200	
605	2021-08-25 14:59:03.465238+00	/data/samtools-intro/sample.bam.bai	200	
606	2021-08-25 14:59:03.476141+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.rzp40atmhcn
607	2021-08-25 14:59:03.533053+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.v3gcu66n7zl
608	2021-08-25 14:59:03.595298+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.h9peu9qvqd
609	2021-08-25 14:59:03.643673+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.7jkb9mmrlxw
610	2021-08-25 14:59:38.110021+00	/api/v1/ping	200	
611	2021-08-25 14:59:46.540744+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.wlinhvhtzho
612	2021-08-25 14:59:46.592856+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.546tmky4ujw
613	2021-08-25 14:59:47.067343+00	/tutorials	200	?id=samtools-intro&step=6
614	2021-08-25 14:59:48.880128+00	/tutorials	200	?id=samtools-intro&step=6
615	2021-08-25 14:59:48.925237+00	/build/bundle.css	200	
616	2021-08-25 14:59:48.943715+00	/build/bundle.js	200	
617	2021-08-25 14:59:50.86787+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.w25sv2lyovl
618	2021-08-25 14:59:50.884254+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.cllfien9s6n
619	2021-08-25 14:59:50.915282+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.zo0ry33mev
620	2021-08-25 14:59:50.957022+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.cr8uowdcake
621	2021-08-25 15:01:44.686629+00	/api/v1/ping	200	
622	2021-08-25 15:01:45.070395+00	/api/v1/ping	200	
623	2021-08-25 15:01:45.722654+00	/api/v1/ping	200	
624	2021-08-25 15:01:48.604489+00	/api/v1/ping	200	
625	2021-08-25 15:01:51.907265+00	/data/terminal-basics/orders.tsv	200	
719	2021-08-25 16:42:57.557448+00	/data/samtools-intro/sample.bam.bai	200	
626	2021-08-25 15:42:03.084917+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.3f7whv99d1x
627	2021-08-25 15:42:23.554581+00	/build/bundle.js.map	200	
628	2021-08-25 15:42:23.677256+00	/igv.css.map	404	
629	2021-08-25 15:42:23.686733+00	/build/bootstrap.min.css.map	404	
630	2021-08-25 15:42:23.698874+00	/igv-ui.css.map	404	
631	2021-08-25 15:42:27.845979+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.3hzd9mu4slo
632	2021-08-25 15:42:27.860224+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.m8pxhswoh2c
633	2021-08-25 15:42:27.918427+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.atb17uxlf9b
634	2021-08-25 15:42:27.948581+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.gx0ousd7yvq
635	2021-08-25 15:44:11.219204+00	/data/samtools-intro/sample.bam.bai	200	
636	2021-08-25 15:44:11.230494+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.v06bebf2vn
637	2021-08-25 15:44:11.268424+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.hbth1ta8d94
638	2021-08-25 15:44:11.321757+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.qh6x4njh3q
639	2021-08-25 15:44:11.355231+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.1rtwgn5rvox
640	2021-08-25 15:44:47.127607+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.1rtwgn5rvox
641	2021-08-25 15:46:25.190131+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.gd5ce48q6jv
642	2021-08-25 15:46:25.211147+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.4qaa5igifab
643	2021-08-25 16:25:44.782017+00	/tutorials	404	?id=samtools-intro&step=6
644	2021-08-25 16:25:47.742423+00	/tutorials	404	?id=samtools-intro&step=6
645	2021-08-25 16:26:05.495262+00	/tutorials	404	?id=samtools-intro&step=6
646	2021-08-25 16:27:25.446004+00	/tutorials	404	?id=samtools-intro&step=6
647	2021-08-25 16:27:38.194611+00	/tutorials	404	?id=samtools-intro&step=6
648	2021-08-25 16:30:06.989937+00	/tutorials	404	?id=samtools-intro&step=6
649	2021-08-25 16:30:31.53314+00	/tutorials	200	?id=samtools-intro&step=6
650	2021-08-25 16:30:31.582814+00	/build/bundle.js	200	
651	2021-08-25 16:30:31.72707+00	/build/bundle.css	200	
652	2021-08-25 16:30:31.735665+00	/build/bundle.js.map	200	
653	2021-08-25 16:30:31.937749+00	/build/bootstrap.min.css.map	404	
654	2021-08-25 16:30:32.05521+00	/igv.css.map	404	
655	2021-08-25 16:30:32.069983+00	/igv-ui.css.map	404	
656	2021-08-25 16:30:33.41365+00	/data/samtools-intro/sample.sam	200	
657	2021-08-25 16:30:33.493255+00	/data/samtools-intro/sample.sam	200	
658	2021-08-25 16:30:42.715736+00	/data/samtools-intro/sample.bam.bai	200	
659	2021-08-25 16:30:42.742418+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.ahytjg60hxi
660	2021-08-25 16:30:42.75812+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.xfnr9ld5is
661	2021-08-25 16:30:42.782838+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.98mf6n8tgh7
662	2021-08-25 16:30:42.837703+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.zra5bjmeed
663	2021-08-25 16:35:03.574874+00	/tutorials	404	?id=samtools-intro&step=6
664	2021-08-25 16:35:04.492236+00	/tutorials	404	?id=samtools-intro&step=6
665	2021-08-25 16:35:17.008942+00	/tutorials	404	?id=samtools-intro&step=6
666	2021-08-25 16:35:17.467279+00	/tutorials	404	?id=samtools-intro&step=6
667	2021-08-25 16:35:17.703395+00	/tutorials	404	?id=samtools-intro&step=6
668	2021-08-25 16:35:17.840751+00	/tutorials	404	?id=samtools-intro&step=6
669	2021-08-25 16:35:17.970006+00	/tutorials	404	?id=samtools-intro&step=6
670	2021-08-25 16:35:55.782427+00	/tutorials	404	?id=samtools-intro&step=6
671	2021-08-25 16:35:56.280922+00	/tutorials	404	?id=samtools-intro&step=6
672	2021-08-25 16:35:56.658464+00	/tutorials	404	?id=samtools-intro&step=6
673	2021-08-25 16:35:56.809261+00	/tutorials	404	?id=samtools-intro&step=6
674	2021-08-25 16:35:56.934393+00	/tutorials	404	?id=samtools-intro&step=6
675	2021-08-25 16:35:57.082376+00	/tutorials	404	?id=samtools-intro&step=6
676	2021-08-25 16:35:57.527776+00	/tutorials	404	?id=samtools-intro&step=6
677	2021-08-25 16:35:58.032051+00	/tutorials	404	?id=samtools-intro&step=6
678	2021-08-25 16:35:58.101205+00	/tutorials	404	?id=samtools-intro&step=6
679	2021-08-25 16:35:58.180747+00	/tutorials	404	?id=samtools-intro&step=6
680	2021-08-25 16:35:58.26842+00	/tutorials	404	?id=samtools-intro&step=6
681	2021-08-25 16:35:58.357234+00	/tutorials	404	?id=samtools-intro&step=6
682	2021-08-25 16:35:58.424554+00	/tutorials	404	?id=samtools-intro&step=6
683	2021-08-25 16:35:58.553818+00	/tutorials	404	?id=samtools-intro&step=6
684	2021-08-25 16:35:58.602385+00	/tutorials	404	?id=samtools-intro&step=6
685	2021-08-25 16:35:58.682453+00	/tutorials	404	?id=samtools-intro&step=6
686	2021-08-25 16:35:58.790109+00	/tutorials	404	?id=samtools-intro&step=6
687	2021-08-25 16:35:58.871387+00	/tutorials	404	?id=samtools-intro&step=6
688	2021-08-25 16:36:02.967484+00	/tutorials	404	?id=samtools-intro&step=6
689	2021-08-25 16:36:40.782233+00	/tutorials	200	?id=samtools-intro&step=6
690	2021-08-25 16:36:40.839792+00	/build/bundle.js	200	
691	2021-08-25 16:36:40.882818+00	/build/bundle.css	200	
692	2021-08-25 16:36:41.078958+00	/build/bootstrap.min.css.map	404	
693	2021-08-25 16:36:41.107128+00	/build/bundle.js.map	200	
694	2021-08-25 16:36:41.381559+00	/igv.css.map	404	
695	2021-08-25 16:36:41.408588+00	/igv-ui.css.map	404	
696	2021-08-25 16:36:42.391608+00	/data/samtools-intro/sample.sam	200	
697	2021-08-25 16:36:42.449448+00	/data/samtools-intro/sample.sam	200	
698	2021-08-25 16:36:46.496773+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.sbt12y8zk3g
699	2021-08-25 16:36:46.512945+00	/data/samtools-intro/sample.bam.bai	200	
700	2021-08-25 16:36:46.588525+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.4nky3axioc
701	2021-08-25 16:36:46.601172+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.t7ugqsx6rmj
702	2021-08-25 16:36:46.648746+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.ezqygwh49x
703	2021-08-25 16:39:56.951196+00	/tutorials	200	?id=samtools-intro&step=6
704	2021-08-25 16:39:56.987418+00	/build/bundle.js	200	
705	2021-08-25 16:39:57.003576+00	/build/bundle.css	200	
706	2021-08-25 16:39:57.179301+00	/build/bootstrap.min.css.map	404	
707	2021-08-25 16:39:57.251097+00	/build/bundle.js.map	200	
708	2021-08-25 16:39:57.533383+00	/igv.css.map	404	
709	2021-08-25 16:39:57.558786+00	/igv-ui.css.map	404	
710	2021-08-25 16:39:58.409148+00	/data/samtools-intro/sample.sam	200	
711	2021-08-25 16:39:58.433082+00	/data/samtools-intro/sample.sam	200	
712	2021-08-25 16:40:00.689704+00	/data/samtools-intro/sample.bam.bai	200	
713	2021-08-25 16:40:00.720359+00	/data/samtools-intro/sample.bam	404	?someRandomSeed=0.j3lzsw0i5cr
714	2021-08-25 16:40:51.892248+00	/data/samtools-intro/sample.bam.bai	200	
715	2021-08-25 16:40:51.916959+00	/data/samtools-intro/sample.bam	404	?someRandomSeed=0.wc1q2ngts6a
716	2021-08-25 16:41:59.722839+00	/data/samtools-intro/sample.bam.bai	200	
717	2021-08-25 16:41:59.89701+00	/data/samtools-intro/sample.bam	404	?someRandomSeed=0.j9r1wpo9o39
718	2021-08-25 16:42:57.549345+00	/data/samtools-intro/sample.bam	404	?someRandomSeed=0.c4pdksxwiaq
720	2021-08-25 16:43:21.113642+00	/data/samtools-intro/sample.bam.bai	200	
721	2021-08-25 16:43:21.121728+00	/data/samtools-intro/sample.bam	404	?someRandomSeed=0.rmx11tkzbq
722	2021-08-25 16:45:03.975579+00	/data/samtools-intro/sample.bam	404	?someRandomSeed=0.dyab5snfrtd
723	2021-08-25 16:45:03.979623+00	/data/samtools-intro/sample.bam.bai	200	
724	2021-08-25 16:45:10.150879+00	/data/samtools-intro/sample.bam.bai	200	
725	2021-08-25 16:45:10.171281+00	/data/samtools-intro/sample.bam	404	?someRandomSeed=0.izl59x3b27i
726	2021-08-25 16:45:28.568857+00	/data/samtools-intro/sample.bam	404	?someRandomSeed=0.rxfq05t0ycm
727	2021-08-25 16:45:28.569704+00	/data/samtools-intro/sample.bam.bai	200	
728	2021-08-25 16:45:39.09781+00	/data/samtools-intro/sample.bam.bai	200	
729	2021-08-25 16:45:39.103532+00	/data/samtools-intro/sample.bam	404	?someRandomSeed=0.m68hmbt9heq
730	2021-08-25 16:54:16.97829+00	/tutorials	200	?id=samtools-intro&step=6
731	2021-08-25 16:54:17.008009+00	/build/bundle.js	200	
732	2021-08-25 16:54:17.079533+00	/build/bundle.css	200	
733	2021-08-25 16:54:17.236606+00	/build/bundle.js.map	200	
734	2021-08-25 16:54:17.272017+00	/build/bootstrap.min.css.map	404	
735	2021-08-25 16:54:17.536808+00	/igv-ui.css.map	404	
736	2021-08-25 16:54:17.550697+00	/igv.css.map	404	
737	2021-08-25 16:54:18.353614+00	/data/samtools-intro/sample.sam	200	
738	2021-08-25 16:54:18.436461+00	/data/samtools-intro/sample.sam	200	
739	2021-08-25 16:54:23.422252+00	/data/samtools-intro/sample.bam.bai	200	
740	2021-08-25 16:54:23.461643+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.dv5q58gwlsb
741	2021-08-25 16:54:23.498419+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.rfjm4ysusr8
742	2021-08-25 16:54:23.54438+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.kf6d9m1ah7f
743	2021-08-25 16:54:23.587905+00	/data/samtools-intro/sample.bam	200	?someRandomSeed=0.77vj7vjpaup
744	2021-08-25 16:54:59.977435+00	/tutorials	200	?id=samtools-intro&step=6
745	2021-08-25 16:55:00.025026+00	/build/bundle.css	200	
746	2021-08-25 16:55:00.132452+00	/build/bundle.js	200	
747	2021-08-25 16:55:00.148179+00	/build/bootstrap.min.css.map	404	
748	2021-08-25 16:55:00.411361+00	/igv.css.map	404	
749	2021-08-25 16:55:00.448815+00	/igv-ui.css.map	404	
750	2021-08-25 16:55:00.56801+00	/build/bundle.js.map	200	
751	2021-08-25 16:55:01.347204+00	/data/samtools-intro/sample.sam	200	
752	2021-08-25 16:55:01.397502+00	/data/samtools-intro/sample.sam	200	
753	2021-08-31 17:31:11.826495+00	/	200	
754	2021-08-31 17:31:12.027545+00	/build/bundle.css	200	
755	2021-08-31 17:31:12.106998+00	/build/bundle.js	200	
756	2021-08-31 17:31:12.494139+00	/images/cli.png	200	
757	2021-08-31 17:31:17.350246+00	/tutorials	200	?id=dna-secrets
758	2021-08-31 17:31:21.344766+00	/data/dna-secrets/reads.fq	200	
759	2021-08-31 17:31:21.37471+00	/data/dna-secrets/reads.fq	200	
760	2021-08-31 17:31:21.616639+00	/data/dna-secrets/morereads.fq	200	
761	2021-08-31 17:31:21.699629+00	/data/dna-secrets/morereads.fq	200	
762	2021-08-31 17:31:31.574755+00	/tutorials	200	?id=samtools-intro
763	2021-08-31 17:31:31.896324+00	/data/samtools-intro/sample.sam	200	
764	2021-08-31 17:31:31.964725+00	/data/samtools-intro/sample.sam	200	
765	2021-08-31 17:31:33.878561+00	/api/v1/ping	200	
766	2021-08-31 17:31:34.002533+00	/api/v1/ping	200	
767	2021-08-31 17:31:34.256283+00	/api/v1/ping	200	
768	2021-08-31 17:31:34.404413+00	/api/v1/ping	200	
769	2021-08-31 17:31:34.681805+00	/api/v1/ping	200	
770	2021-08-31 17:31:34.82086+00	/api/v1/ping	200	
771	2021-08-31 17:31:35.186667+00	/api/v1/ping	200	
772	2021-08-31 17:31:35.629434+00	/api/v1/ping	200	
773	2021-08-31 17:31:36.007841+00	/api/v1/ping	200	
774	2021-08-31 17:31:36.203698+00	/api/v1/ping	200	
775	2021-08-31 17:35:43.37884+00	/playground	200	
776	2021-08-31 17:35:44.774421+00	/data/bedtools-intro/cpg.bed	200	
777	2021-08-31 17:35:44.979735+00	/data/bedtools-intro/exons.bed	200	
778	2021-08-31 17:35:45.164991+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
779	2021-08-31 17:35:45.354118+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
780	2021-08-31 17:35:45.547903+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
781	2021-08-31 17:35:45.782898+00	/data/bedtools-intro/gwas.bed	200	
782	2021-08-31 17:35:45.968393+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
783	2021-08-31 17:35:46.17861+00	/data/bedtools-intro/genome.txt	200	
784	2021-08-31 20:16:55.573176+00	/	200	
785	2021-08-31 20:16:55.586879+00	/build/bundle.js	200	
786	2021-08-31 20:16:55.603472+00	/build/bundle.css	200	
787	2021-08-31 20:16:55.810603+00	/images/cli.png	200	
788	2021-08-31 20:16:57.931585+00	/	200	
789	2021-08-31 20:16:58.01494+00	/build/bundle.js	200	
790	2021-08-31 20:16:58.014907+00	/build/bundle.css	200	
791	2021-08-31 20:16:58.084976+00	/images/cli.png	200	
792	2021-08-31 20:16:58.906812+00	/	200	
793	2021-08-31 20:16:58.954143+00	/build/bundle.js	200	
794	2021-08-31 20:16:58.95888+00	/build/bundle.css	200	
795	2021-08-31 20:16:59.050868+00	/images/cli.png	200	
796	2021-08-31 20:16:59.569027+00	/	200	
797	2021-08-31 20:16:59.644774+00	/build/bundle.css	200	
798	2021-08-31 20:16:59.661239+00	/build/bundle.js	200	
799	2021-08-31 20:16:59.751589+00	/images/cli.png	200	
800	2021-08-31 20:17:01.067625+00	/	200	
801	2021-08-31 20:17:01.094401+00	/build/bundle.css	200	
802	2021-08-31 20:17:01.104023+00	/build/bundle.js	200	
803	2021-08-31 20:17:01.178829+00	/images/cli.png	200	
804	2021-08-31 20:17:40.466829+00	/	200	
805	2021-08-31 20:17:40.654116+00	/build/bundle.js	200	
806	2021-08-31 20:17:40.659834+00	/build/bundle.css	200	
807	2021-08-31 20:17:40.85339+00	/images/cli.png	200	
808	2021-09-01 20:12:52.642298+00	/build/bundle.js	200	
809	2021-09-01 20:12:53.060609+00	/images/cli.png	200	
810	2021-09-01 20:13:14.626096+00	/	200	
811	2021-09-01 20:13:19.223906+00	/tutorials	200	
812	2021-09-01 20:14:00.852694+00	/data/bedtools-intro/cpg.bed	200	
813	2021-09-01 20:14:01.020657+00	/data/bedtools-intro/exons.bed	200	
814	2021-09-01 20:14:01.199357+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
815	2021-09-01 20:14:01.413232+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
816	2021-09-01 20:14:01.55583+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
817	2021-09-01 20:14:01.7704+00	/data/bedtools-intro/gwas.bed	200	
818	2021-09-01 20:14:01.983848+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
819	2021-09-01 20:14:02.14684+00	/data/bedtools-intro/genome.txt	200	
820	2021-09-01 20:14:10.430551+00	/playground	200	
821	2021-09-01 20:14:10.669024+00	/data/bedtools-intro/cpg.bed	200	
822	2021-09-01 20:14:10.705544+00	/data/bedtools-intro/exons.bed	200	
823	2021-09-01 20:14:10.760758+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
824	2021-09-01 20:14:10.794075+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
931	2021-09-01 23:34:30.584395+00	/api/v1/ping	200	
825	2021-09-01 20:14:10.838379+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
826	2021-09-01 20:14:10.894738+00	/data/bedtools-intro/gwas.bed	200	
827	2021-09-01 20:14:10.934291+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
828	2021-09-01 20:14:10.989575+00	/data/bedtools-intro/genome.txt	200	
829	2021-09-01 20:14:20.025248+00	/tutorials	200	?id=bedtools-intro
830	2021-09-01 20:14:20.214438+00	/data/bedtools-intro/cpg.bed	200	
831	2021-09-01 20:14:20.263188+00	/data/bedtools-intro/exons.bed	200	
832	2021-09-01 20:14:20.293256+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
833	2021-09-01 20:14:20.364026+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
834	2021-09-01 20:14:20.408325+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
835	2021-09-01 20:14:20.481302+00	/data/bedtools-intro/gwas.bed	200	
836	2021-09-01 20:14:20.514612+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
837	2021-09-01 20:14:20.568075+00	/data/bedtools-intro/genome.txt	200	
838	2021-09-01 20:14:21.91501+00	/api/v1/ping	200	
839	2021-09-01 20:14:23.181075+00	/api/v1/ping	200	
840	2021-09-01 20:14:27.283618+00	/tutorials	200	?id=bedtools-intro&step=2
841	2021-09-01 20:14:27.585996+00	/data/bedtools-intro/cpg.bed	200	
842	2021-09-01 20:14:27.634354+00	/data/bedtools-intro/exons.bed	200	
843	2021-09-01 20:14:27.677989+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
844	2021-09-01 20:14:27.731174+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
845	2021-09-01 20:14:27.784808+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
846	2021-09-01 20:14:27.839881+00	/data/bedtools-intro/gwas.bed	200	
847	2021-09-01 20:14:27.885147+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
848	2021-09-01 20:14:27.940683+00	/data/bedtools-intro/genome.txt	200	
849	2021-09-01 20:14:44.512884+00	/api/v1/ping	200	
850	2021-09-01 20:17:34.151691+00	/tutorials	200	?id=bedtools-intro&step=3
851	2021-09-01 20:17:34.428795+00	/data/bedtools-intro/cpg.bed	200	
852	2021-09-01 20:17:34.571886+00	/data/bedtools-intro/exons.bed	200	
853	2021-09-01 20:17:34.749076+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
854	2021-09-01 20:17:34.876063+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
855	2021-09-01 20:17:35.043626+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
856	2021-09-01 20:17:35.205189+00	/data/bedtools-intro/gwas.bed	200	
857	2021-09-01 20:17:35.374759+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
858	2021-09-01 20:17:35.535013+00	/data/bedtools-intro/genome.txt	200	
859	2021-09-01 20:17:39.605337+00	/tutorials	200	?id=bedtools-intro&step=3
860	2021-09-01 20:17:39.914802+00	/build/bundle.js	200	
861	2021-09-01 20:17:39.923536+00	/build/bundle.css	200	
862	2021-09-01 20:17:40.390587+00	/data/bedtools-intro/cpg.bed	200	
863	2021-09-01 20:17:40.438589+00	/data/bedtools-intro/exons.bed	200	
864	2021-09-01 20:17:40.500842+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
865	2021-09-01 20:17:40.547517+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
866	2021-09-01 20:17:40.614397+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
867	2021-09-01 20:17:40.646197+00	/data/bedtools-intro/gwas.bed	200	
868	2021-09-01 20:17:40.701178+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
869	2021-09-01 20:17:40.748932+00	/data/bedtools-intro/genome.txt	200	
870	2021-09-01 20:17:43.644429+00	/api/v1/ping	200	
871	2021-09-01 20:17:47.947739+00	/build/bundle.js.map	200	
872	2021-09-01 20:17:48.053231+00	/build/bootstrap.min.css.map	404	
873	2021-09-01 20:17:50.181244+00	/api/v1/ping	200	
874	2021-09-01 21:14:03.958878+00	/api/v1/ping	200	
875	2021-09-01 21:14:07.047847+00	/api/v1/ping	200	
876	2021-09-01 23:01:29.503515+00	/api/v1/ping	200	
877	2021-09-01 23:01:31.056781+00	/api/v1/ping	200	
878	2021-09-01 23:01:35.062084+00	/api/v1/ping	200	
879	2021-09-01 23:01:42.680151+00	/	200	
880	2021-09-01 23:01:42.716559+00	/build/bundle.css	200	
881	2021-09-01 23:01:42.738205+00	/build/bundle.js	200	
882	2021-09-01 23:01:42.897379+00	/images/cli.png	200	
883	2021-09-01 23:01:49.689015+00	/tutorials	200	?id=bowtie2-intro
884	2021-09-01 23:01:50.669569+00	/data/bowtie2-intro/reads_1.fq	200	
885	2021-09-01 23:01:50.733529+00	/data/bowtie2-intro/reads_1.fq	200	
886	2021-09-01 23:01:50.884996+00	/data/bowtie2-intro/reads_2.fq	200	
887	2021-09-01 23:01:50.964978+00	/data/bowtie2-intro/reads_2.fq	200	
888	2021-09-01 23:01:51.04797+00	/api/v1/ping	200	
889	2021-09-01 23:01:51.147947+00	/data/bowtie2-intro/longreads.fq	200	
890	2021-09-01 23:01:51.183714+00	/api/v1/ping	200	
891	2021-09-01 23:01:51.251275+00	/data/bowtie2-intro/longreads.fq	200	
892	2021-09-01 23:01:51.334894+00	/api/v1/ping	200	
893	2021-09-01 23:01:51.481585+00	/api/v1/ping	200	
894	2021-09-01 23:01:51.619065+00	/api/v1/ping	200	
895	2021-09-01 23:01:51.907588+00	/api/v1/ping	200	
896	2021-09-01 23:01:52.07268+00	/api/v1/ping	200	
897	2021-09-01 23:03:01.333291+00	/api/v1/ping	200	
898	2021-09-01 23:25:00.589257+00	/api/v1/ping	200	
899	2021-09-01 23:25:09.271813+00	/api/v1/ping	200	
900	2021-09-01 23:27:55.816297+00	/api/v1/ping	200	
901	2021-09-01 23:27:56.087933+00	/api/v1/ping	200	
902	2021-09-01 23:27:56.523751+00	/api/v1/ping	200	
903	2021-09-01 23:27:56.868471+00	/api/v1/ping	200	
904	2021-09-01 23:27:57.289645+00	/api/v1/ping	200	
905	2021-09-01 23:27:57.445368+00	/api/v1/ping	200	
906	2021-09-01 23:27:57.636913+00	/api/v1/ping	200	
907	2021-09-01 23:27:57.889798+00	/api/v1/ping	200	
908	2021-09-01 23:27:58.315676+00	/api/v1/ping	200	
909	2021-09-01 23:27:58.865714+00	/api/v1/ping	200	
910	2021-09-01 23:27:59.413055+00	/api/v1/ping	200	
911	2021-09-01 23:27:59.932507+00	/api/v1/ping	200	
912	2021-09-01 23:28:00.475559+00	/api/v1/ping	200	
913	2021-09-01 23:28:01.796129+00	/api/v1/ping	200	
914	2021-09-01 23:29:56.543553+00	/api/v1/ping	200	
915	2021-09-01 23:30:44.506104+00	/api/v1/ping	200	
916	2021-09-01 23:30:45.511807+00	/api/v1/ping	200	
917	2021-09-01 23:31:05.46481+00	/api/v1/ping	200	
918	2021-09-01 23:31:07.340401+00	/api/v1/ping	200	
919	2021-09-01 23:31:13.511681+00	/api/v1/ping	200	
920	2021-09-01 23:31:26.352855+00	/api/v1/ping	200	
921	2021-09-01 23:31:57.232268+00	/api/v1/ping	200	
922	2021-09-01 23:32:12.739559+00	/api/v1/ping	200	
923	2021-09-01 23:32:17.314433+00	/api/v1/ping	200	
924	2021-09-01 23:32:18.761318+00	/api/v1/ping	200	
925	2021-09-01 23:33:00.67341+00	/api/v1/ping	200	
926	2021-09-01 23:33:01.582635+00	/api/v1/ping	200	
927	2021-09-01 23:33:01.857616+00	/api/v1/ping	200	
928	2021-09-01 23:33:02.482604+00	/api/v1/ping	200	
929	2021-09-01 23:33:02.734564+00	/api/v1/ping	200	
930	2021-09-01 23:33:02.932299+00	/api/v1/ping	200	
932	2021-09-01 23:34:34.898677+00	/api/v1/ping	200	
933	2021-09-01 23:34:36.10885+00	/api/v1/ping	200	
934	2021-09-01 23:34:37.835784+00	/api/v1/ping	200	
935	2021-09-01 23:34:41.234227+00	/api/v1/ping	200	
936	2021-09-01 23:34:46.196742+00	/api/v1/ping	200	
937	2021-09-01 23:34:53.970885+00	/api/v1/ping	200	
938	2021-09-01 23:34:58.811897+00	/api/v1/ping	200	
939	2021-09-01 23:34:59.557558+00	/api/v1/ping	200	
940	2021-09-01 23:35:00.928856+00	/api/v1/ping	200	
941	2021-09-03 02:40:00.792756+00	/build/bundle.js	200	
942	2021-09-03 02:40:00.805791+00	/build/bundle.css	200	
943	2021-09-03 02:40:01.174477+00	/images/cli.png	200	
944	2021-09-03 02:41:23.578705+00	/	200	
945	2021-09-03 02:41:23.612884+00	/build/bundle.css	200	
946	2021-09-03 02:41:23.857112+00	/build/bundle.js	200	
947	2021-09-03 02:41:24.075784+00	/images/cli.png	200	
948	2021-09-03 02:52:26.915981+00	/	200	
949	2021-09-03 02:52:27.040763+00	/build/bundle.css	200	
950	2021-09-03 02:52:27.247893+00	/build/bundle.js	200	
951	2021-09-03 02:52:27.530294+00	/images/cli.png	200	
952	2021-09-03 02:56:09.041715+00	/playground	200	
953	2021-09-03 02:56:12.3873+00	/tutorials	200	?id=terminal-basics
954	2021-09-03 02:56:13.726407+00	/data/terminal-basics/orders.tsv	200	
955	2021-09-03 02:56:13.971739+00	/data/terminal-basics/ref.fa	200	
956	2021-09-03 02:56:14.167809+00	/data/terminal-basics/ref.fa.bak	200	
957	2021-09-03 02:56:16.688158+00	/api/v1/ping	200	
958	2021-09-03 02:56:17.6834+00	/api/v1/ping	200	
959	2021-09-03 02:57:09.525371+00	/tutorials	200	?id=terminal-basics&step=2
960	2021-09-03 02:57:10.469984+00	/data/terminal-basics/orders.tsv	200	
961	2021-09-03 02:57:10.539693+00	/data/terminal-basics/ref.fa	200	
962	2021-09-03 02:57:10.577785+00	/data/terminal-basics/ref.fa.bak	200	
963	2021-09-03 02:58:43.191333+00	/data/bedtools-intro/cpg.bed	200	
964	2021-09-03 02:58:43.36194+00	/data/bedtools-intro/exons.bed	200	
965	2021-09-03 02:58:43.557808+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
966	2021-09-03 02:58:43.737472+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
967	2021-09-03 02:58:44.028036+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
968	2021-09-03 02:58:44.426893+00	/data/bedtools-intro/gwas.bed	200	
969	2021-09-03 02:58:44.596521+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
970	2021-09-03 02:58:44.867729+00	/data/bedtools-intro/genome.txt	200	
971	2021-09-03 02:58:45.510164+00	/data/terminal-basics/orders.tsv	200	
972	2021-09-03 02:58:45.647821+00	/data/terminal-basics/ref.fa	200	
973	2021-09-03 02:58:45.797774+00	/data/terminal-basics/ref.fa.bak	200	
974	2021-09-03 02:58:50.592986+00	/tutorials	200	?id=bowtie2-intro
975	2021-09-03 02:58:51.720765+00	/data/bowtie2-intro/reads_1.fq	200	
976	2021-09-03 02:58:51.788106+00	/data/bowtie2-intro/reads_1.fq	200	
977	2021-09-03 02:58:51.957444+00	/data/bowtie2-intro/reads_2.fq	200	
978	2021-09-03 02:58:52.018008+00	/data/bowtie2-intro/reads_2.fq	200	
979	2021-09-03 02:58:52.20022+00	/data/bowtie2-intro/longreads.fq	200	
980	2021-09-03 02:58:52.303464+00	/data/bowtie2-intro/longreads.fq	200	
981	2021-09-03 02:58:56.01773+00	/data/terminal-basics/orders.tsv	200	
982	2021-09-03 02:58:56.080885+00	/data/terminal-basics/ref.fa	200	
983	2021-09-03 02:58:56.131858+00	/data/terminal-basics/ref.fa.bak	200	
984	2021-09-03 03:00:00.070271+00	/tutorials	200	
985	2021-09-03 03:00:14.680979+00	/data/terminal-basics/orders.tsv	200	
986	2021-09-03 03:00:14.876359+00	/data/terminal-basics/ref.fa	200	
987	2021-09-03 03:00:15.045404+00	/data/terminal-basics/ref.fa.bak	200	
988	2021-09-03 03:00:16.085817+00	/api/v1/ping	200	
989	2021-09-03 03:00:16.249616+00	/api/v1/ping	200	
990	2021-09-03 03:00:16.401255+00	/api/v1/ping	200	
991	2021-09-03 03:00:16.552861+00	/api/v1/ping	200	
992	2021-09-03 03:00:16.857555+00	/api/v1/ping	200	
993	2021-09-06 20:52:52.547615+00	/	200	
994	2021-09-06 20:52:52.78468+00	/build/bundle.css	200	
995	2021-09-06 20:52:52.840597+00	/build/bundle.js	200	
996	2021-09-06 20:52:53.250489+00	/images/cli.png	200	
997	2021-09-06 20:52:56.942213+00	/tutorials	200	?id=bedtools-intro
998	2021-09-06 20:52:58.418791+00	/data/bedtools-intro/cpg.bed	200	
999	2021-09-06 20:52:58.55464+00	/data/bedtools-intro/exons.bed	200	
1000	2021-09-06 20:52:58.723795+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
1001	2021-09-06 20:52:58.867586+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
1002	2021-09-06 20:52:59.039076+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
1003	2021-09-06 20:52:59.22377+00	/data/bedtools-intro/gwas.bed	200	
1004	2021-09-06 20:52:59.398355+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
1005	2021-09-06 20:52:59.561754+00	/data/bedtools-intro/genome.txt	200	
1006	2021-09-06 20:53:01.79923+00	/tutorials	200	?id=terminal-basics
1007	2021-09-06 20:53:02.429088+00	/data/terminal-basics/orders.tsv	200	
1008	2021-09-06 20:53:02.59583+00	/data/terminal-basics/ref.fa	200	
1009	2021-09-06 20:53:02.740076+00	/data/terminal-basics/ref.fa.bak	200	
1010	2021-09-06 20:53:04.663495+00	/tutorials	200	?id=bedtools-intro&step=15
1011	2021-09-06 20:53:04.8184+00	/data/bedtools-intro/cpg.bed	200	
1012	2021-09-06 20:53:04.856841+00	/data/bedtools-intro/exons.bed	200	
1013	2021-09-06 20:53:04.894082+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
1014	2021-09-06 20:53:04.945541+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
1015	2021-09-06 20:53:04.978961+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
1016	2021-09-06 20:53:05.03702+00	/data/bedtools-intro/gwas.bed	200	
1017	2021-09-06 20:53:05.08964+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
1018	2021-09-06 20:53:05.100724+00	/data/bedtools-intro/genome.txt	200	
1019	2021-09-06 20:53:11.467415+00	/api/v1/ping	200	
1020	2021-09-07 19:43:12.312332+00	/	200	
1021	2021-09-07 19:43:12.577412+00	/build/bundle.js	200	
1022	2021-09-07 19:43:12.911252+00	/images/cli.png	200	
1023	2021-09-07 19:43:16.296811+00	/tutorials	200	?id=jq-intro
1024	2021-09-07 19:43:18.398049+00	/data/jq-intro/repo.json	200	
1025	2021-09-07 19:43:18.42811+00	/data/jq-intro/repo.json	200	
1026	2021-09-07 19:43:18.608004+00	/data/jq-intro/issues.json	200	
1027	2021-09-07 19:43:18.669419+00	/data/jq-intro/issues.json	200	
1028	2021-09-07 19:43:18.835+00	/data/jq-intro/issue.json	200	
1029	2021-09-07 19:43:18.90218+00	/data/jq-intro/issue.json	200	
1030	2021-09-07 19:43:34.516236+00	/tutorials	200	
1031	2021-09-07 19:43:37.137739+00	/tutorials	200	
1032	2021-09-07 19:43:37.167404+00	/build/bundle.js	200	
1033	2021-09-07 19:43:37.365806+00	/build/bundle.css	200	
1034	2021-09-07 19:43:41.996759+00	/build/bootstrap.min.css.map	404	
1035	2021-09-07 19:43:42.0656+00	/build/bundle.js.map	200	
1036	2021-09-07 19:44:50.298629+00	/build/bundle.js.map	200	
1168	2021-10-04 05:47:20.928874+00	/build/bundle.css	200	
1037	2021-09-07 19:44:50.341251+00	/build/bootstrap.min.css.map	404	
1038	2021-09-07 19:44:56.905507+00	/build/bundle.js.map	200	
1039	2021-09-07 19:44:56.917505+00	/build/bootstrap.min.css.map	404	
1040	2021-09-07 19:44:57.389341+00	/data/bedtools-intro/cpg.bed	200	
1041	2021-09-07 19:44:57.569377+00	/data/bedtools-intro/exons.bed	200	
1042	2021-09-07 19:44:57.755597+00	/data/bedtools-intro/fHeart-DS15839.bed	200	
1043	2021-09-07 19:44:57.933511+00	/data/bedtools-intro/fHeart-DS16621.bed	200	
1044	2021-09-07 19:44:58.095768+00	/data/bedtools-intro/fSkin-DS19745.bed	200	
1045	2021-09-07 19:44:58.283471+00	/data/bedtools-intro/gwas.bed	200	
1046	2021-09-07 19:44:58.460705+00	/data/bedtools-intro/hesc.chromHmm.bed	200	
1047	2021-09-07 19:44:58.61839+00	/data/bedtools-intro/genome.txt	200	
1048	2021-09-07 19:44:59.07763+00	/api/v1/ping	200	
1049	2021-09-07 19:44:59.801275+00	/api/v1/ping	200	
1050	2021-09-07 23:15:11.88393+00	/	200	
1051	2021-09-07 23:15:12.220458+00	/build/bundle.css	200	
1052	2021-09-07 23:15:12.242047+00	/build/bundle.js	200	
1053	2021-09-07 23:15:12.511554+00	/images/cli.png	200	
1054	2021-09-07 23:15:20.808667+00	/tutorials	200	?id=jq-intro
1055	2021-09-07 23:15:22.349936+00	/data/jq-intro/repo.json	200	
1056	2021-09-07 23:15:22.431823+00	/data/jq-intro/repo.json	200	
1057	2021-09-07 23:15:22.602551+00	/data/jq-intro/issues.json	200	
1058	2021-09-07 23:15:22.708048+00	/data/jq-intro/issues.json	200	
1059	2021-09-07 23:15:22.871268+00	/data/jq-intro/issue.json	200	
1060	2021-09-07 23:15:22.911215+00	/data/jq-intro/issue.json	200	
1061	2021-09-07 23:17:20.945376+00	/api/v1/ping	200	
1062	2021-09-07 23:17:25.122747+00	/api/v1/ping	200	
1063	2021-09-07 23:17:26.792598+00	/api/v1/ping	200	
1064	2021-09-07 23:17:30.388862+00	/api/v1/ping	200	
1065	2021-09-07 23:17:33.371331+00	/api/v1/ping	200	
1066	2021-09-07 23:17:34.703692+00	/api/v1/ping	200	
1067	2021-09-07 23:17:35.631046+00	/api/v1/ping	200	
1068	2021-09-07 23:19:53.722715+00	/api/v1/ping	200	
1069	2021-09-07 23:24:03.641143+00	/api/v1/ping	200	
1070	2021-09-07 23:34:39.899298+00	/api/v1/ping	200	
1071	2021-09-07 23:35:24.111424+00	/api/v1/ping	200	
1072	2021-09-07 23:36:18.721348+00	/api/v1/ping	200	
1073	2021-09-07 23:37:24.594576+00	/api/v1/ping	200	
1074	2021-09-07 23:45:51.532748+00	/api/v1/ping	200	
1075	2021-09-07 23:48:15.182315+00	/api/v1/ping	200	
1076	2021-09-18 17:02:30.79832+00	/	200	
1077	2021-09-18 17:02:31.116207+00	/build/bundle.css	200	
1078	2021-09-18 17:02:31.120262+00	/build/bundle.js	200	
1079	2021-09-18 17:02:31.352634+00	/build/bootstrap.min.css.map	404	
1080	2021-09-18 17:02:31.500822+00	/images/cli.png	200	
1081	2021-09-18 17:02:31.692529+00	/build/bundle.js.map	200	
1082	2021-09-18 17:02:34.799042+00	/tutorials	200	?id=terminal-basics
1083	2021-09-18 17:02:34.941489+00	/build/bootstrap.min.css.map	404	
1084	2021-09-18 17:02:34.962186+00	/build/bundle.js.map	200	
1085	2021-09-18 17:17:03.734804+00	/build/bundle.js.map	200	
1086	2021-09-18 17:17:03.88236+00	/build/bootstrap.min.css.map	404	
1087	2021-09-18 17:24:59.030136+00	/tutorials	200	?id=terminal-basics
1088	2021-09-18 17:24:59.072627+00	/build/bundle.css	200	
1089	2021-09-18 17:24:59.080363+00	/build/bundle.js	200	
1090	2021-09-18 17:24:59.310397+00	/build/bundle.js.map	200	
1091	2021-09-18 17:24:59.340413+00	/build/bootstrap.min.css.map	404	
1092	2021-09-18 17:25:02.221227+00	/data/terminal-basics/orders.tsv	200	
1093	2021-09-18 17:25:02.41089+00	/data/terminal-basics/ref.fa	200	
1094	2021-09-18 17:25:02.644722+00	/data/terminal-basics/ref.fa.bak	200	
1095	2021-09-18 17:25:02.724352+00	/data/terminal-basics/orders.tsv	200	
1096	2021-09-18 17:25:02.79394+00	/data/terminal-basics/ref.fa	200	
1097	2021-09-18 17:25:02.861498+00	/data/terminal-basics/ref.fa.bak	200	
1098	2021-09-22 23:56:27.389722+00	/	200	
1099	2021-09-22 23:56:27.532467+00	/build/bundle.css	200	
1100	2021-09-22 23:56:27.698117+00	/build/bundle.js	200	
1101	2021-09-22 23:56:28.11717+00	/images/cli.png	200	
1102	2021-09-22 23:56:29.738811+00	/tutorials	200	?id=rosalind
1103	2021-09-22 23:56:32.351849+00	/build/bootstrap.min.css.map	404	
1104	2021-09-22 23:56:32.513093+00	/build/bundle.js.map	200	
1105	2021-09-23 01:42:09.475455+00	/tutorials	200	?id=rosalind
1106	2021-09-23 01:42:09.540567+00	/build/bundle.css	200	
1107	2021-09-23 01:42:09.756841+00	/build/bundle.js	200	
1108	2021-09-24 02:22:20.769237+00	/build/bundle.css	200	
1109	2021-09-24 02:22:20.787958+00	/build/bundle.js	200	
1110	2021-09-24 02:22:21.29869+00	/images/cli.png	200	
1111	2021-09-24 02:22:22.525686+00	/	200	
1112	2021-09-24 02:22:22.61299+00	/build/bundle.js	200	
1113	2021-09-24 02:22:22.619508+00	/build/bundle.css	200	
1114	2021-09-24 02:22:22.746092+00	/images/cli.png	200	
1115	2021-09-24 02:22:29.391208+00	/build/bootstrap.min.css.map	404	
1116	2021-09-24 02:22:29.55542+00	/build/bundle.js.map	200	
1117	2021-09-25 01:58:18.144078+00	/build/bundle.css	200	
1118	2021-09-25 01:58:18.616876+00	/build/bundle.js	200	
1119	2021-09-25 01:58:18.981841+00	/images/cli.png	200	
1120	2021-09-25 01:58:21.17044+00	/rosalind	404	
1121	2021-09-25 01:59:01.453039+00	/playground	200	
1122	2021-10-04 05:42:58.393191+00	/	200	
1123	2021-10-04 05:42:59.168951+00	/build/bundle.css	200	
1124	2021-10-04 05:42:59.587283+00	/build/bootstrap.min.css.map	404	
1125	2021-10-04 05:42:59.669717+00	/build/bundle.js	200	
1126	2021-10-04 05:43:00.494243+00	/	200	
1127	2021-10-04 05:43:00.597608+00	/build/bundle.css	200	
1128	2021-10-04 05:43:00.656798+00	/build/bootstrap.min.css.map	404	
1129	2021-10-04 05:43:00.652152+00	/build/bundle.js	200	
1130	2021-10-04 05:43:00.887261+00	/images/cli.png	200	
1131	2021-10-04 05:43:01.167368+00	/build/bundle.js.map	200	
1132	2021-10-04 05:43:01.634081+00	/images/cli.png	200	
1133	2021-10-04 05:43:02.161206+00	/build/bundle.js.map	200	
1134	2021-10-04 05:43:02.427321+00	/	200	
1135	2021-10-04 05:44:01.479209+00	/	200	
1136	2021-10-04 05:44:01.536418+00	/build/bundle.css	200	
1137	2021-10-04 05:44:01.632325+00	/build/bundle.js	200	
1138	2021-10-04 05:44:01.721129+00	/build/bundle.js.map	200	
1139	2021-10-04 05:44:01.744937+00	/images/cli.png	200	
1140	2021-10-04 05:44:02.088417+00	/build/bootstrap.min.css.map	404	
1141	2021-10-04 05:44:02.658208+00	/	200	
1142	2021-10-04 05:47:10.524304+00	/	200	
1143	2021-10-04 05:47:10.612937+00	/build/bundle.css	200	
1144	2021-10-04 05:47:10.620184+00	/build/bundle.js	200	
1145	2021-10-04 05:47:10.898051+00	/build/bootstrap.min.css.map	404	
1146	2021-10-04 05:47:10.930533+00	/build/bundle.js.map	200	
1147	2021-10-04 05:47:10.948611+00	/images/cli.png	200	
1148	2021-10-04 05:47:11.988134+00	/	304	
1149	2021-10-04 05:47:12.127631+00	/build/bundle.js.map	200	
1150	2021-10-04 05:47:12.128424+00	/build/bootstrap.min.css.map	404	
1151	2021-10-04 05:47:13.4261+00	/	200	
1152	2021-10-04 05:47:13.500414+00	/build/bundle.css	200	
1153	2021-10-04 05:47:13.519227+00	/build/bundle.js	200	
1154	2021-10-04 05:47:13.57549+00	/build/bootstrap.min.css.map	404	
1155	2021-10-04 05:47:13.648741+00	/images/cli.png	200	
1156	2021-10-04 05:47:13.656054+00	/build/bundle.js.map	200	
1157	2021-10-04 05:47:14.32996+00	/	304	
1158	2021-10-04 05:47:14.463389+00	/build/bundle.js.map	200	
1159	2021-10-04 05:47:14.477662+00	/build/bootstrap.min.css.map	404	
1160	2021-10-04 05:47:15.16995+00	/	304	
1161	2021-10-04 05:47:15.272582+00	/build/bootstrap.min.css.map	404	
1162	2021-10-04 05:47:15.280381+00	/build/bundle.js.map	200	
1163	2021-10-04 05:47:16.016906+00	/	304	
1164	2021-10-04 05:47:16.106846+00	/build/bundle.js.map	200	
1165	2021-10-04 05:47:16.114391+00	/build/bootstrap.min.css.map	404	
1166	2021-10-04 05:47:20.861994+00	/	200	
1167	2021-10-04 05:47:20.92639+00	/build/bundle.js	200	
1169	2021-10-04 05:47:20.981047+00	/build/bootstrap.min.css.map	404	
1170	2021-10-04 05:47:21.044416+00	/build/bundle.js.map	200	
1171	2021-10-04 05:47:21.049912+00	/images/cli.png	200	
1172	2021-10-04 05:47:21.58918+00	/	304	
1173	2021-10-04 05:47:21.7017+00	/build/bundle.js.map	200	
1174	2021-10-04 05:47:21.716392+00	/build/bootstrap.min.css.map	404	
1175	2021-10-04 05:47:22.134091+00	/	304	
1176	2021-10-04 05:47:22.230907+00	/build/bundle.js.map	200	
1177	2021-10-04 05:47:22.236247+00	/build/bootstrap.min.css.map	404	
1178	2021-10-04 05:47:22.91964+00	/	304	
1179	2021-10-04 05:47:23.011298+00	/build/bundle.js.map	200	
1180	2021-10-04 05:47:23.017226+00	/build/bootstrap.min.css.map	404	
1181	2021-10-04 05:47:23.939962+00	/	304	
1182	2021-10-04 05:47:24.031978+00	/build/bundle.js.map	200	
1183	2021-10-04 05:47:24.042014+00	/build/bootstrap.min.css.map	404	
1184	2021-10-05 05:27:08.470687+00	/build/bundle.js	200	
1185	2021-10-05 05:27:09.119182+00	/images/cli.png	200	
1186	2021-10-05 05:27:10.380928+00	/playground	200	
1187	2021-10-05 05:27:18.225173+00	/build/bootstrap.min.css.map	404	
1188	2021-10-05 05:27:18.598352+00	/build/bundle.js.map	200	
1189	2021-10-06 23:56:13.03366+00	/	200	
1190	2021-10-06 23:56:13.346273+00	/build/bundle.css	200	
1191	2021-10-06 23:56:13.363861+00	/build/bundle.js	200	
1192	2021-10-06 23:56:13.821906+00	/images/cli.png	200	
1193	2021-10-06 23:56:14.330003+00	/build/bootstrap.min.css.map	404	
1194	2021-10-06 23:56:14.596678+00	/build/bundle.js.map	200	
1195	2021-10-06 23:56:15.598805+00	/playground	200	
1196	2021-10-06 23:56:15.742551+00	/build/bundle.css	200	
1197	2021-10-06 23:56:15.750696+00	/build/bundle.js	200	
1198	2021-10-06 23:56:15.827022+00	/build/bootstrap.min.css.map	404	
1199	2021-10-06 23:56:15.929112+00	/build/bundle.js.map	200	
1200	2021-10-07 04:05:02.717536+00	/tutorials	200	
1201	2021-10-07 04:05:03.571574+00	/tutorials	304	
1202	2021-10-07 04:07:08.855983+00	/tutorials	200	
1203	2021-10-07 04:07:08.922807+00	/build/bundle.css	200	
1204	2021-10-07 04:07:09.139829+00	/build/bundle.js	200	
1205	2021-11-09 19:12:51.32969+00	/build/bundle.js.map	200	
1206	2021-11-09 19:12:51.400835+00	/build/bootstrap.min.css.map	404	
1207	2021-11-09 19:12:53.032817+00	/	304	
1208	2021-11-09 19:12:53.139853+00	/build/bundle.js.map	200	
1209	2021-11-09 19:12:53.157965+00	/build/bootstrap.min.css.map	404	
1210	2021-11-09 19:18:50.390192+00	/tutorials	200	?id=jq-intro
1211	2021-11-09 19:18:50.576402+00	/build/bundle.js.map	200	
1212	2021-11-09 19:18:50.681532+00	/build/bootstrap.min.css.map	404	
1213	2021-11-09 19:18:50.844105+00	/data/jq-intro/repo.json	200	
1214	2021-11-09 19:18:50.903275+00	/data/jq-intro/repo.json	200	
1215	2021-11-09 19:18:51.134984+00	/data/jq-intro/issues.json	200	
1216	2021-11-09 19:18:51.196153+00	/data/jq-intro/issues.json	200	
1217	2021-11-09 19:18:51.360195+00	/data/jq-intro/issue.json	200	
1218	2021-11-09 19:18:51.440658+00	/data/jq-intro/issue.json	200	
1219	2021-11-09 19:18:53.662573+00	/tutorials	304	?id=jq-intro
1220	2021-11-09 19:18:53.814396+00	/build/bootstrap.min.css.map	404	
1221	2021-11-09 19:18:53.825801+00	/build/bundle.js.map	200	
1222	2021-11-09 19:20:09.028833+00	/	200	
1223	2021-11-09 19:20:20.258878+00	/build/bootstrap.min.css.map	404	
1224	2021-11-09 19:20:20.459247+00	/build/bundle.js.map	200	
1225	2021-11-09 19:20:26.403123+00	/	200	
1226	2021-11-09 19:20:30.906599+00	/	304	
1227	2021-11-09 19:20:31.047808+00	/build/bundle.js.map	200	
1228	2021-11-09 19:20:31.06426+00	/build/bootstrap.min.css.map	404	
1229	2021-11-09 19:21:18.179747+00	/tutorials	200	?id=jq-intro
1230	2021-11-09 19:21:18.312678+00	/build/bootstrap.min.css.map	404	
1231	2021-11-09 19:21:18.377205+00	/build/bundle.js.map	200	
1232	2021-11-09 20:26:42.254095+00	/	304	
1233	2021-11-09 20:26:42.350979+00	/build/bundle.js.map	200	
1234	2021-11-09 20:26:42.486477+00	/build/bootstrap.min.css.map	404	
1235	2021-11-09 20:26:48.730435+00	/	304	
1236	2021-11-09 20:26:48.8437+00	/build/bundle.js.map	200	
1237	2021-11-09 20:26:48.872464+00	/build/bootstrap.min.css.map	404	
1238	2021-11-09 20:26:50.439108+00	/images/cli.png	200	
1239	2021-11-10 16:23:23.240017+00	/	200	
1240	2021-11-10 16:23:23.562197+00	/build/bundle.css	200	
1241	2021-11-10 16:23:23.698756+00	/build/bundle.js	200	
1242	2021-11-10 16:23:23.732585+00	/build/bootstrap.min.css.map	404	
1243	2021-11-10 16:23:24.054198+00	/images/cli.png	200	
1244	2021-11-10 16:23:24.428982+00	/build/bundle.js.map	200	
1245	2021-11-11 05:10:55.748685+00	/	304	
1246	2021-11-11 05:10:55.860247+00	/build/bundle.js.map	200	
1247	2021-11-11 05:10:55.963461+00	/build/bootstrap.min.css.map	404	
1248	2021-11-13 01:19:28.131397+00	/build/bundle.js.map	200	
1249	2021-11-13 01:19:59.308801+00	/	200	
1250	2021-11-13 01:19:59.55962+00	/build/bundle.css	200	
1251	2021-11-13 01:19:59.607312+00	/build/bundle.js	200	
1252	2021-11-13 01:19:59.992527+00	/images/cli.png	200	
1253	2021-11-13 01:20:03.18765+00	/	200	
1254	2021-11-13 01:21:45.720949+00	/build/bundle.js.map	404	
1255	2022-01-22 02:37:55.365643+00	/playground	200	
1256	2022-01-22 02:41:57.938211+00	/playground	200	
1257	2022-01-22 02:41:58.179152+00	/build/bundle.css	200	
1258	2022-01-22 02:41:58.217214+00	/build/bundle.js	200	
1259	2022-01-22 02:42:15.743919+00	/build/bootstrap.min.css.map	404	
1260	2022-01-22 02:42:18.570503+00	/playground	304	
1261	2022-01-22 02:42:18.781495+00	/build/bootstrap.min.css.map	404	
1262	2022-01-22 02:44:18.835452+00	/playground	200	
1263	2022-01-22 02:44:19.183754+00	/build/bundle.css	200	
1264	2022-01-22 02:44:19.24868+00	/build/bundle.js	200	
1265	2022-01-22 02:44:19.400162+00	/build/bootstrap.min.css.map	404	
1266	2022-01-22 02:46:30.172531+00	/playground	200	
1267	2022-01-22 02:46:30.343441+00	/build/bundle.css	200	
1268	2022-01-22 02:46:30.356384+00	/build/bundle.js	200	
1269	2022-01-22 02:46:30.849904+00	/build/bootstrap.min.css.map	404	
1270	2022-01-22 02:46:38.932993+00	/playground	200	
1271	2022-01-22 02:46:39.056259+00	/build/bundle.js	200	
1272	2022-01-22 02:46:39.066922+00	/build/bundle.css	200	
1273	2022-01-22 02:46:39.140363+00	/build/bootstrap.min.css.map	404	
1274	2022-01-22 02:46:41.668084+00	/playground	200	
1275	2022-01-22 02:46:41.78225+00	/build/bundle.css	200	
1276	2022-01-22 02:46:41.810048+00	/build/bundle.js	200	
1277	2022-01-22 02:46:41.870649+00	/build/bootstrap.min.css.map	404	
1278	2022-01-22 02:46:53.874939+00	/playground	200	
1279	2022-01-22 02:46:53.96796+00	/build/bundle.css	200	
1280	2022-01-22 02:46:53.984057+00	/build/bundle.js	200	
1281	2022-01-22 02:46:54.034325+00	/build/bootstrap.min.css.map	404	
1282	2022-01-22 02:47:16.761709+00	/playground	200	
1283	2022-01-22 02:47:17.010561+00	/build/bundle.css	200	
1284	2022-01-22 02:47:17.099744+00	/build/bootstrap.min.css.map	404	
1285	2022-01-22 02:47:17.119043+00	/build/bundle.js	200	
1286	2022-01-22 02:48:26.273983+00	/playground	200	
1287	2022-01-22 02:48:26.471213+00	/build/bundle.js	200	
1288	2022-01-22 02:48:26.484254+00	/build/bundle.css	200	
1289	2022-01-22 02:48:26.800549+00	/build/bootstrap.min.css.map	404	
1290	2022-01-22 03:43:03.746796+00	/playground	200	
1291	2022-01-22 03:43:03.860818+00	/build/bundle.css	200	
1292	2022-01-22 03:43:03.877512+00	/build/bundle.js	200	
1293	2022-01-22 03:43:04.141306+00	/build/bootstrap.min.css.map	404	
1294	2022-01-22 03:46:54.212706+00	/playground	200	
1295	2022-01-22 03:46:54.359036+00	/build/bundle.css	200	
1296	2022-01-22 03:46:54.577593+00	/build/bootstrap.min.css.map	404	
1297	2022-01-22 03:46:54.5951+00	/build/bundle.js	200	
1298	2022-01-22 03:47:49.712244+00	/playground	200	
1299	2022-01-22 03:47:49.918803+00	/build/bundle.css	200	
1300	2022-01-22 03:47:50.027273+00	/build/bootstrap.min.css.map	404	
1301	2022-01-22 03:47:50.046793+00	/build/bundle.js	200	
1302	2022-01-22 03:48:48.915072+00	/playground	200	
1303	2022-01-22 03:48:49.032351+00	/build/bundle.css	200	
1304	2022-01-22 03:48:49.042613+00	/build/bundle.js	200	
1305	2022-01-22 03:48:49.151403+00	/build/bootstrap.min.css.map	404	
1306	2022-01-22 03:49:42.286981+00	/playground	200	
1307	2022-01-22 03:49:42.578492+00	/build/bundle.css	200	
1308	2022-01-22 03:49:42.655711+00	/build/bootstrap.min.css.map	404	
1309	2022-01-22 03:49:42.672425+00	/build/bundle.js	200	
1310	2022-01-22 04:44:43.394381+00	/playground	200	
1311	2022-01-22 04:44:43.497976+00	/build/bundle.css	200	
1312	2022-01-22 04:44:43.515337+00	/build/bundle.js	200	
1313	2022-01-22 04:44:43.789454+00	/build/bootstrap.min.css.map	404	
1314	2022-01-22 04:45:25.736382+00	/playground	200	
1315	2022-01-22 04:45:25.909995+00	/build/bundle.css	200	
1316	2022-01-22 04:45:25.925608+00	/build/bundle.js	200	
1317	2022-01-22 04:45:26.058546+00	/build/bootstrap.min.css.map	404	
1318	2022-01-22 04:46:11.574054+00	/playground	200	
1319	2022-01-22 04:46:11.683321+00	/build/bundle.js	200	
1320	2022-01-22 04:46:11.689113+00	/build/bundle.css	200	
1321	2022-01-22 04:46:11.936359+00	/build/bootstrap.min.css.map	404	
1322	2022-01-22 04:50:45.853075+00	/playground	200	
1323	2022-01-22 04:50:46.085873+00	/build/bundle.css	200	
1324	2022-01-22 04:50:46.245532+00	/build/bootstrap.min.css.map	404	
1325	2022-01-22 04:50:46.308004+00	/build/bundle.js	200	
1326	2022-01-22 05:07:19.84925+00	/playground	200	
1327	2022-01-22 05:07:19.997355+00	/build/bundle.css	200	
1328	2022-01-22 05:07:20.048799+00	/build/bundle.js	200	
1329	2022-01-22 05:07:20.164213+00	/build/bootstrap.min.css.map	404	
1330	2022-01-22 05:07:27.679231+00	/playground	200	
1331	2022-01-22 05:07:27.807641+00	/build/bundle.css	200	
1332	2022-01-22 05:07:27.888819+00	/build/bootstrap.min.css.map	404	
1333	2022-01-22 05:07:28.066854+00	/build/bundle.js	200	
1334	2022-01-22 05:08:07.577655+00	/playground	200	
1335	2022-01-22 05:08:07.675538+00	/build/bundle.css	200	
1336	2022-01-22 05:08:07.776693+00	/build/bootstrap.min.css.map	404	
1337	2022-01-22 05:08:08.165276+00	/build/bundle.js	200	
1338	2022-01-22 05:08:22.848587+00	/playground	200	
1339	2022-01-22 05:08:22.998006+00	/build/bundle.css	200	
1340	2022-01-22 05:08:23.020972+00	/build/bundle.js	200	
1341	2022-01-22 05:08:23.070265+00	/build/bootstrap.min.css.map	404	
1342	2022-01-22 05:08:26.284918+00	/playground	200	
1343	2022-01-22 05:08:26.399766+00	/build/bundle.css	200	
1344	2022-01-22 05:08:26.410201+00	/build/bundle.js	200	
1345	2022-01-22 05:08:26.46757+00	/build/bootstrap.min.css.map	404	
1346	2022-01-22 15:01:59.204905+00	/playground	200	
1347	2022-01-22 15:01:59.433253+00	/build/bundle.css	200	
1348	2022-01-22 15:01:59.447662+00	/build/bundle.js	200	
1349	2022-01-22 15:03:40.950756+00	/playground	200	
1350	2022-01-22 15:03:41.070337+00	/build/bundle.css	200	
1351	2022-01-22 15:03:41.279365+00	/build/bootstrap.min.css.map	404	
1352	2022-01-22 15:03:41.370424+00	/build/bundle.js	200	
1353	2022-01-22 15:03:48.55562+00	/playground	200	
1354	2022-01-22 15:03:48.63782+00	/build/bundle.css	200	
1355	2022-01-22 15:03:48.648229+00	/build/bundle.js	200	
1356	2022-01-22 15:03:48.697455+00	/build/bootstrap.min.css.map	404	
1357	2022-01-22 16:40:59.005744+00	/playground	200	
1358	2022-01-22 16:40:59.072343+00	/build/bundle.css	200	
1359	2022-01-22 16:40:59.088046+00	/build/bundle.js	200	
1360	2022-01-22 16:40:59.27701+00	/build/bootstrap.min.css.map	404	
1361	2022-01-22 16:41:07.163984+00	/playground	200	
1362	2022-01-22 16:41:07.233598+00	/build/bundle.css	200	
1363	2022-01-22 16:41:07.24295+00	/build/bundle.js	200	
1364	2022-01-22 16:41:07.298779+00	/build/bootstrap.min.css.map	404	
1365	2022-01-22 16:42:42.91466+00	/playground	200	
1366	2022-01-22 16:42:43.208732+00	/build/bundle.css	200	
1367	2022-01-22 16:42:43.397969+00	/build/bundle.js	200	
1368	2022-01-22 16:42:43.496172+00	/build/bootstrap.min.css.map	404	
1369	2022-01-22 16:43:38.396479+00	/playground	200	
1370	2022-01-22 16:43:38.515493+00	/build/bundle.css	200	
1371	2022-01-22 16:43:38.540314+00	/build/bundle.js	200	
1372	2022-01-22 16:43:38.642623+00	/build/bootstrap.min.css.map	404	
1373	2022-01-22 16:46:46.209041+00	/playground	200	
1374	2022-01-22 16:46:46.522186+00	/build/bundle.css	200	
1375	2022-01-22 16:46:46.902617+00	/build/bootstrap.min.css.map	404	
1376	2022-01-22 16:46:47.064266+00	/build/bundle.js	200	
1377	2022-01-22 16:49:32.93046+00	/playground	200	
1378	2022-01-22 16:49:33.223594+00	/build/bundle.css	200	
1379	2022-01-22 16:49:33.238596+00	/build/bundle.js	200	
1380	2022-01-22 16:49:33.438017+00	/build/bootstrap.min.css.map	404	
1381	2022-01-22 16:49:35.926069+00	/playground	200	
1382	2022-01-22 16:49:36.032466+00	/build/bundle.css	200	
1383	2022-01-22 16:49:36.088605+00	/build/bootstrap.min.css.map	404	
1384	2022-01-22 16:49:36.090983+00	/build/bundle.js	200	
1385	2022-01-22 16:51:49.299415+00	/playground	200	
1386	2022-01-22 16:51:49.553053+00	/build/bundle.css	200	
1387	2022-01-22 16:51:49.628812+00	/build/bundle.js	200	
1388	2022-01-22 16:51:49.739231+00	/build/bootstrap.min.css.map	404	
1389	2022-01-22 16:53:41.404586+00	/playground	200	
1390	2022-01-22 16:53:41.63326+00	/build/bundle.js	200	
1391	2022-01-22 16:53:41.647584+00	/build/bundle.css	200	
1392	2022-01-22 16:53:41.825068+00	/build/bootstrap.min.css.map	404	
1393	2022-01-22 16:56:21.069553+00	/playground	200	
1394	2022-01-22 16:56:21.33697+00	/build/bundle.js	200	
1395	2022-01-22 16:56:21.355597+00	/build/bundle.css	200	
1396	2022-01-22 16:56:21.567511+00	/build/bootstrap.min.css.map	404	
1397	2022-01-22 16:56:31.582801+00	/playground	200	
1398	2022-01-22 16:56:31.712787+00	/build/bundle.css	200	
1399	2022-01-22 16:56:31.722422+00	/build/bundle.js	200	
1400	2022-01-22 16:56:31.756551+00	/build/bootstrap.min.css.map	404	
1401	2022-01-22 16:58:51.780054+00	/playground	200	
1402	2022-01-22 16:58:51.796805+00	/build/bundle.css	200	
1403	2022-01-22 16:58:52.045817+00	/build/bundle.js	200	
1404	2022-01-22 16:58:52.097902+00	/build/bootstrap.min.css.map	404	
1405	2022-01-22 17:00:31.427056+00	/playground	200	
1406	2022-01-22 17:00:31.762584+00	/build/bundle.js	200	
1407	2022-01-22 17:00:31.8075+00	/build/bundle.css	200	
1408	2022-01-22 17:00:32.11148+00	/build/bootstrap.min.css.map	404	
1409	2022-01-22 21:37:59.29169+00	/playground	200	
1410	2022-01-22 21:37:59.539363+00	/build/bundle.js	200	
1411	2022-01-22 21:37:59.548647+00	/build/bundle.css	200	
1412	2022-01-22 21:37:59.753119+00	/build/bootstrap.min.css.map	404	
1413	2022-01-22 21:38:56.28594+00	/playground	200	
1414	2022-01-22 21:38:56.488493+00	/build/bundle.css	200	
1415	2022-01-22 21:38:56.563207+00	/build/bundle.js	200	
1416	2022-01-22 21:38:56.823818+00	/build/bootstrap.min.css.map	404	
1417	2022-01-23 03:10:40.779881+00	/playground	200	
1418	2022-01-23 03:10:41.168356+00	/build/bundle.js	200	
1419	2022-01-23 03:10:41.174544+00	/build/bundle.css	200	
1420	2022-01-23 03:10:41.358053+00	/build/bootstrap.min.css.map	404	
1421	2022-01-23 03:11:28.054392+00	/playground	200	
1422	2022-01-23 03:11:28.180568+00	/build/bundle.css	200	
1423	2022-01-23 03:11:28.286046+00	/build/bootstrap.min.css.map	404	
1424	2022-01-23 03:11:28.460476+00	/build/bundle.js	200	
1425	2022-01-23 05:06:11.792324+00	/playground	200	
1426	2022-01-23 05:06:11.879233+00	/build/bundle.css	200	
1427	2022-01-23 05:06:11.890729+00	/build/bundle.js	200	
1428	2022-01-23 05:06:12.158085+00	/build/bootstrap.min.css.map	404	
1429	2022-01-23 05:17:17.699491+00	/	200	
1430	2022-01-23 05:17:18.026273+00	/images/cli.png	200	
1431	2022-01-23 23:14:35.922587+00	/playground	200	
1432	2022-01-23 23:14:36.153544+00	/build/bundle.css	200	
1433	2022-01-23 23:14:36.172564+00	/build/bundle.js	200	
1434	2022-01-23 23:14:36.492178+00	/build/bootstrap.min.css.map	404	
1435	2022-01-24 00:54:16.188307+00	/playground	200	
1436	2022-01-24 00:54:16.333298+00	/build/bundle.css	200	
1437	2022-01-24 00:54:16.348842+00	/build/bundle.js	200	
1438	2022-01-24 01:42:52.66876+00	/build/bootstrap.min.css.map	404	
1439	2022-01-24 01:43:23.367308+00	/undefined	404	
1440	2022-01-27 15:39:21.848243+00	/	200	
1441	2022-01-27 15:39:22.266569+00	/build/bundle.css	200	
1442	2022-01-27 15:39:22.302043+00	/build/bundle.js	200	
1443	2022-01-27 15:39:22.852358+00	/images/cli.png	200	
1444	2022-01-27 15:39:23.299211+00	/playground	200	
1445	2022-01-27 16:04:34.044417+00	/playground	304	
1446	2022-01-27 16:05:39.568434+00	/build/bootstrap.min.css.map	404	
1447	2022-01-27 16:06:30.21837+00	/playground	304	
1448	2022-01-27 16:06:30.42299+00	/build/bootstrap.min.css.map	404	
1449	2022-01-27 16:34:08.618604+00	/	200	
1450	2022-01-27 16:34:09.214289+00	/	200	
1451	2022-01-27 16:35:01.352979+00	/	200	
1452	2022-01-27 16:35:04.917414+00	/playground	200	
1453	2022-01-27 16:35:05.241736+00	/build/bundle.css	200	
1454	2022-01-27 16:35:05.30785+00	/build/bundle.js	200	
1455	2022-01-27 16:35:05.646109+00	/build/bootstrap.min.css.map	404	
1456	2022-01-28 05:34:10.130438+00	/playground	200	
1457	2022-01-28 05:34:10.443108+00	/build/bundle.css	200	
1458	2022-01-28 05:34:10.502625+00	/build/bundle.js	200	
1459	2022-01-28 05:34:10.757876+00	/build/bootstrap.min.css.map	404	
1460	2022-04-19 14:38:33.90443+00	/	200	
1461	2022-04-19 14:38:34.262111+00	/build/bundle.css	200	
1462	2022-04-19 14:38:34.36467+00	/build/bundle.js	200	
1463	2022-04-19 14:38:34.828143+00	/images/cli.png	200	
1464	2022-04-19 14:38:37.370674+00	/tutorials	200	
1465	2022-04-19 14:40:41.922917+00	/tutorials	200	
1466	2022-04-19 14:40:56.186077+00	/tutorials	200	
1467	2022-04-19 14:40:56.551389+00	/build/bundle.css	200	
1468	2022-04-19 14:40:56.611871+00	/build/bundle.js	200	
1469	2022-05-08 23:05:24.586238+00	/	200	
1470	2022-05-08 23:05:24.990418+00	/build/bundle.css	200	
1471	2022-05-08 23:05:25.019427+00	/build/bundle.js	200	
1472	2022-05-08 23:05:25.553839+00	/images/cli.png	200	
1473	2022-05-08 23:05:27.350045+00	/playground	200	
1474	2022-05-08 23:06:07.642031+00	/playground	200	
1475	2022-05-08 23:06:07.745989+00	/build/bundle.css	200	
1476	2022-05-08 23:06:07.765075+00	/build/bundle.js	200	
1477	2022-05-08 23:06:40.096205+00	/playground	200	
1478	2022-05-08 23:06:40.532001+00	/build/bundle.js	200	
1479	2022-05-08 23:06:40.612718+00	/build/bundle.css	200	
1480	2022-05-08 23:07:31.52162+00	/tutorials	200	?id=fastp-intro
1481	2022-05-08 23:07:32.626859+00	/data/fastp-intro/HG004_R1.fastq.gz	200	
1482	2022-05-08 23:07:32.992415+00	/api/v1/ping	200	
1483	2022-05-08 23:07:33.163733+00	/data/fastp-intro/HG004_R2.fastq.gz	200	
1484	2022-05-08 23:07:33.383222+00	/data/fastp-intro/HG004_R1.fastq.gz	200	
1485	2022-05-08 23:07:33.625414+00	/data/fastp-intro/HG004_R2.fastq.gz	200	
1486	2022-05-08 23:07:33.725179+00	/api/v1/ping	200	
1487	2022-05-08 23:07:35.849708+00	/api/v1/ping	200	
1488	2022-05-15 02:57:45.873678+00	/	200	
1489	2022-05-15 02:57:46.298879+00	/build/bundle.css	200	
1490	2022-05-15 02:57:46.313869+00	/build/bundle.js	200	
1491	2022-05-15 02:57:46.748935+00	/images/cli.png	200	
1492	2022-05-15 02:57:50.897513+00	/playground	200	
1493	2022-05-15 02:59:02.287631+00	/playground	200	
1494	2022-05-15 02:59:02.570801+00	/build/bundle.css	200	
1495	2022-05-15 02:59:02.620743+00	/build/bundle.js	200	
1496	2022-05-15 02:59:03.353774+00	/playground	200	
1497	2022-05-15 02:59:03.415299+00	/build/bundle.css	200	
1498	2022-05-15 02:59:03.430325+00	/build/bundle.js	200	
1499	2022-05-15 02:59:04.998324+00	/build/bootstrap.min.css.map	404	
1500	2022-05-15 02:59:05.103953+00	/playground	200	
1501	2022-05-15 02:59:05.166896+00	/build/bundle.css	200	
1502	2022-05-15 02:59:05.188168+00	/build/bundle.js	200	
1503	2022-05-15 02:59:05.258191+00	/build/bootstrap.min.css.map	404	
1504	2022-05-15 02:59:07.201759+00	/playground	200	
1505	2022-05-15 02:59:07.25701+00	/build/bundle.css	200	
1506	2022-05-15 02:59:07.283504+00	/build/bundle.js	200	
1507	2022-05-15 02:59:07.358674+00	/build/bootstrap.min.css.map	404	
1508	2022-05-15 02:59:09.748329+00	/playground	200	
1509	2022-05-15 02:59:09.808474+00	/build/bundle.css	200	
1510	2022-05-15 02:59:09.845247+00	/build/bundle.js	200	
1511	2022-05-15 02:59:09.890063+00	/build/bootstrap.min.css.map	404	
1512	2022-05-15 02:59:10.387873+00	/playground	200	
1513	2022-05-15 02:59:10.438079+00	/build/bundle.css	200	
1514	2022-05-15 02:59:10.472403+00	/build/bundle.js	200	
1515	2022-05-15 02:59:10.526577+00	/build/bootstrap.min.css.map	404	
1516	2022-05-15 02:59:11.742528+00	/playground	200	
1517	2022-05-15 02:59:11.821279+00	/build/bundle.css	200	
1518	2022-05-15 02:59:11.832235+00	/build/bundle.js	200	
1519	2022-05-15 02:59:11.918957+00	/build/bootstrap.min.css.map	404	
1520	2022-05-15 02:59:13.085006+00	/playground	200	
1521	2022-05-15 02:59:13.150976+00	/build/bundle.css	200	
1522	2022-05-15 02:59:13.180863+00	/build/bundle.js	200	
1523	2022-05-15 02:59:13.222578+00	/build/bootstrap.min.css.map	404	
1524	2022-05-15 02:59:14.780143+00	/playground	200	
1525	2022-05-15 02:59:14.85394+00	/build/bundle.css	200	
1526	2022-05-15 02:59:14.876308+00	/build/bundle.js	200	
1527	2022-05-15 02:59:14.972477+00	/build/bootstrap.min.css.map	404	
1528	2022-05-15 02:59:16.965483+00	/playground	200	
1529	2022-05-15 02:59:17.066154+00	/build/bundle.js	200	
1530	2022-05-15 02:59:17.070853+00	/build/bundle.css	200	
1531	2022-05-15 02:59:17.124157+00	/build/bootstrap.min.css.map	404	
1532	2022-05-15 02:59:17.920035+00	/playground	200	
1533	2022-05-15 02:59:17.985137+00	/build/bundle.css	200	
1534	2022-05-15 02:59:18.021057+00	/build/bundle.js	200	
1535	2022-05-15 02:59:18.093942+00	/build/bootstrap.min.css.map	404	
1536	2022-05-15 02:59:19.088806+00	/playground	200	
1537	2022-05-15 02:59:19.158602+00	/build/bundle.css	200	
1538	2022-05-15 02:59:19.193412+00	/build/bundle.js	200	
1539	2022-05-15 02:59:19.247245+00	/build/bootstrap.min.css.map	404	
1540	2022-05-15 02:59:20.175942+00	/playground	200	
1541	2022-05-15 02:59:20.252199+00	/build/bundle.css	200	
1542	2022-05-15 02:59:20.273896+00	/build/bundle.js	200	
1543	2022-05-15 02:59:20.337697+00	/build/bootstrap.min.css.map	404	
1544	2022-05-15 02:59:21.300506+00	/playground	200	
1545	2022-05-15 02:59:21.376826+00	/build/bundle.css	200	
1546	2022-05-15 02:59:21.384865+00	/build/bundle.js	200	
1547	2022-05-15 02:59:21.438135+00	/build/bootstrap.min.css.map	404	
1548	2022-05-15 02:59:27.247389+00	/playground	200	
1549	2022-05-15 02:59:27.567531+00	/build/bundle.css	200	
1550	2022-05-15 02:59:27.641489+00	/build/bootstrap.min.css.map	404	
1551	2022-05-15 02:59:27.686922+00	/build/bundle.js	200	
1552	2022-05-15 02:59:28.56824+00	/vim/vim.js	200	
1553	2022-05-15 02:59:28.948647+00	/vim/vim.wasm	200	
1554	2022-05-15 02:59:29.079652+00	/vim/vim.data	200	
1555	2022-05-15 03:02:54.634717+00	/playground	200	
1556	2022-05-15 03:02:55.16615+00	/build/bundle.css	200	
1557	2022-05-15 03:02:55.333612+00	/build/bundle.js	200	
1558	2022-05-15 03:02:57.875126+00	/vim/vim.js	200	
1559	2022-05-15 03:02:58.462668+00	/vim/vim.wasm	200	
1560	2022-05-15 03:02:58.771096+00	/vim/vim.data	200	
1561	2022-05-15 03:06:04.515265+00	/playground	200	
1562	2022-05-15 03:06:04.829224+00	/build/bundle.css	200	
1563	2022-05-15 03:06:04.838253+00	/build/bundle.js	200	
1564	2022-05-15 03:06:05.065558+00	/build/bootstrap.min.css.map	404	
1565	2022-05-15 03:06:05.791118+00	/vim/vim.js	200	
1566	2022-05-15 03:06:06.106277+00	/vim/vim.wasm	200	
1567	2022-05-15 03:06:06.129351+00	/vim/vim.data	200	
1568	2022-05-15 03:11:33.185478+00	/playground	200	
1569	2022-05-15 03:11:33.379043+00	/build/bundle.css	200	
1570	2022-05-15 03:11:33.515626+00	/build/bundle.js	200	
1571	2022-05-15 03:11:33.553255+00	/build/bootstrap.min.css.map	404	
1572	2022-05-15 03:11:34.084039+00	/vim/vim.js	200	
1573	2022-05-15 03:11:34.399041+00	/vim/vim.wasm	200	
1574	2022-05-15 03:11:34.662478+00	/vim/vim.data	200	
1575	2022-05-15 03:56:28.174428+00	/biowasm/base/2.4.0-rc2/base.js	200	
1576	2022-05-15 03:56:38.309988+00	/playground	200	
1577	2022-05-15 03:56:38.613501+00	/build/bundle.css	200	
1578	2022-05-15 03:56:38.765424+00	/build/bundle.js	200	
1579	2022-05-15 03:56:38.792793+00	/build/bootstrap.min.css.map	404	
1580	2022-05-15 03:56:39.181131+00	/biowasm/base/2.4.0-rc2/base.js	200	
1581	2022-05-15 03:56:39.35594+00	/biowasm/base/2.4.0-rc2/base.wasm	200	
1582	2022-05-15 03:56:39.405257+00	/build/bundle.js.map	200	
1583	2022-05-15 03:56:39.62705+00	/biowasm/jq/1.6/config.json	200	
1584	2022-05-15 03:56:39.685698+00	/biowasm/jq/1.6/jq.js	200	
1585	2022-05-15 03:56:40.076691+00	/biowasm/jq/1.6/jq.wasm	200	
1586	2022-05-15 03:56:40.286726+00	/biowasm/coreutils/8.32/config.json	200	
1587	2022-05-15 03:56:40.293287+00	/biowasm/coreutils/8.32/config.json	200	
1588	2022-05-15 03:56:40.296702+00	/biowasm/coreutils/8.32/config.json	200	
1589	2022-05-15 03:56:40.311721+00	/biowasm/fastp/0.20.1/config.json	200	
1590	2022-05-15 03:56:40.320839+00	/biowasm/gawk/5.1.0/config.json	200	
1591	2022-05-15 03:56:40.316333+00	/biowasm/coreutils/8.32/config.json	200	
1592	2022-05-15 03:56:40.337771+00	/biowasm/coreutils/8.32/config.json	200	
1593	2022-05-15 03:56:40.327574+00	/biowasm/coreutils/8.32/config.json	200	
1594	2022-05-15 03:56:40.336725+00	/biowasm/coreutils/8.32/config.json	200	
1595	2022-05-15 03:56:40.354764+00	/biowasm/coreutils/8.32/config.json	200	
1596	2022-05-15 03:56:40.364663+00	/biowasm/coreutils/8.32/config.json	200	
1597	2022-05-15 03:56:40.364968+00	/biowasm/coreutils/8.32/config.json	200	
1598	2022-05-15 03:56:40.36447+00	/biowasm/coreutils/8.32/config.json	200	
1599	2022-05-15 03:56:40.369533+00	/biowasm/coreutils/8.32/config.json	200	
1600	2022-05-15 03:56:40.367443+00	/biowasm/coreutils/8.32/config.json	200	
1601	2022-05-15 03:56:40.377616+00	/biowasm/coreutils/8.32/config.json	200	
1602	2022-05-15 03:56:40.371895+00	/biowasm/bowtie2/2.4.2/config.json	200	
1603	2022-05-15 03:56:40.383929+00	/biowasm/coreutils/8.32/config.json	200	
1604	2022-05-15 03:56:40.386312+00	/biowasm/coreutils/8.32/config.json	200	
1605	2022-05-15 03:56:40.389259+00	/biowasm/coreutils/8.32/config.json	200	
1606	2022-05-15 03:56:40.437578+00	/biowasm/bedtools/2.29.2/config.json	200	
1607	2022-05-15 03:56:40.437497+00	/biowasm/bcftools/1.10/config.json	200	
1608	2022-05-15 03:56:40.437385+00	/biowasm/grep/3.7/config.json	200	
1609	2022-05-15 03:56:40.43859+00	/biowasm/samtools/1.10/config.json	200	
1610	2022-05-15 03:56:40.439488+00	/biowasm/minimap2/2.22/config.json	200	
1611	2022-05-15 03:56:40.438278+00	/biowasm/coreutils/8.32/config.json	200	
1612	2022-05-15 03:56:40.442124+00	/biowasm/coreutils/8.32/config.json	200	
1613	2022-05-15 03:56:40.488608+00	/vim/vim.js	200	
1614	2022-05-15 03:56:40.570006+00	/vim/vim.wasm	200	
1615	2022-05-15 03:56:40.582133+00	/vim/vim.data	200	
1616	2022-05-15 03:56:54.797331+00	/playground	200	
1617	2022-05-15 03:56:54.852728+00	/build/bundle.css	200	
1618	2022-05-15 03:56:54.860064+00	/build/bundle.js	200	
1619	2022-05-15 03:56:54.923704+00	/build/bootstrap.min.css.map	404	
1620	2022-05-15 03:56:54.998795+00	/build/bundle.js.map	200	
1621	2022-05-15 03:56:55.06303+00	/biowasm/base/2.4.0-rc2/base.js	200	
1622	2022-05-15 03:56:55.142308+00	/biowasm/base/2.4.0-rc2/base.wasm	200	
1623	2022-05-15 03:56:55.184722+00	/biowasm/jq/1.6/config.json	200	
1624	2022-05-15 03:56:55.235837+00	/biowasm/jq/1.6/jq.js	200	
1625	2022-05-15 03:56:55.297287+00	/biowasm/jq/1.6/jq.wasm	200	
1626	2022-05-15 03:56:55.406348+00	/biowasm/coreutils/8.32/config.json	200	
1627	2022-05-15 03:56:55.412906+00	/biowasm/coreutils/8.32/config.json	200	
1628	2022-05-15 03:56:55.42344+00	/biowasm/coreutils/8.32/config.json	200	
1629	2022-05-15 03:56:55.433324+00	/biowasm/coreutils/8.32/config.json	200	
1630	2022-05-15 03:56:55.446495+00	/biowasm/coreutils/8.32/config.json	200	
1631	2022-05-15 03:56:55.453522+00	/biowasm/coreutils/8.32/config.json	200	
1632	2022-05-15 03:56:55.464996+00	/biowasm/coreutils/8.32/config.json	200	
1633	2022-05-15 03:56:55.429772+00	/biowasm/coreutils/8.32/config.json	200	
1634	2022-05-15 03:56:55.470308+00	/biowasm/coreutils/8.32/config.json	200	
1635	2022-05-15 03:56:55.452606+00	/biowasm/fastp/0.20.1/config.json	200	
1636	2022-05-15 03:56:55.491974+00	/vim/vim.js	200	
1637	2022-05-15 03:56:55.479459+00	/biowasm/minimap2/2.22/config.json	200	
1638	2022-05-15 03:56:55.538081+00	/vim/vim.data	200	
1639	2022-05-15 03:56:55.543477+00	/vim/vim.wasm	200	
1640	2022-05-15 03:56:55.521323+00	/biowasm/samtools/1.10/config.json	200	
1641	2022-05-15 03:56:55.518737+00	/biowasm/coreutils/8.32/config.json	200	
1642	2022-05-15 03:56:55.540205+00	/biowasm/bowtie2/2.4.2/config.json	200	
1643	2022-05-15 03:56:55.530174+00	/biowasm/bedtools/2.29.2/config.json	200	
1645	2022-05-15 03:56:55.551398+00	/biowasm/bcftools/1.10/config.json	200	
1644	2022-05-15 03:56:55.542296+00	/biowasm/coreutils/8.32/config.json	200	
1646	2022-05-15 03:56:55.565585+00	/biowasm/coreutils/8.32/config.json	200	
1647	2022-05-15 03:56:55.604829+00	/biowasm/coreutils/8.32/config.json	200	
1648	2022-05-15 03:56:55.595949+00	/biowasm/coreutils/8.32/config.json	200	
1649	2022-05-15 03:56:55.597035+00	/biowasm/coreutils/8.32/config.json	200	
1650	2022-05-15 03:56:55.594144+00	/biowasm/coreutils/8.32/config.json	200	
1651	2022-05-15 03:56:55.602778+00	/biowasm/coreutils/8.32/config.json	200	
1652	2022-05-15 03:56:55.605202+00	/biowasm/coreutils/8.32/config.json	200	
1653	2022-05-15 03:56:55.593997+00	/biowasm/coreutils/8.32/config.json	200	
1654	2022-05-15 03:56:55.597164+00	/biowasm/gawk/5.1.0/config.json	200	
1655	2022-05-15 03:56:55.610314+00	/biowasm/grep/3.7/config.json	200	
1656	2022-05-15 03:57:40.496823+00	/playground	200	
1657	2022-05-15 03:57:40.799231+00	/build/bundle.css	200	
1658	2022-05-15 03:57:40.814629+00	/build/bundle.js	200	
1659	2022-05-15 03:57:41.032209+00	/build/bootstrap.min.css.map	404	
1660	2022-05-15 03:57:41.495508+00	/biowasm/base/2.4.0-rc2/base.js	200	
1661	2022-05-15 03:57:41.769866+00	/biowasm/base/2.4.0-rc2/base.wasm	200	
1662	2022-05-15 03:57:41.931798+00	/biowasm/jq/1.6/config.json	200	
1663	2022-05-15 03:57:42.185622+00	/biowasm/jq/1.6/jq.js	200	
1664	2022-05-15 03:57:43.054947+00	/biowasm/jq/1.6/jq.wasm	200	
1665	2022-05-15 03:57:43.263495+00	/biowasm/coreutils/8.32/config.json	200	
1666	2022-05-15 03:57:43.279884+00	/biowasm/coreutils/8.32/config.json	200	
1667	2022-05-15 03:57:43.29386+00	/biowasm/samtools/1.10/config.json	200	
1668	2022-05-15 03:57:43.307891+00	/biowasm/coreutils/8.32/config.json	200	
1669	2022-05-15 03:57:43.314833+00	/biowasm/coreutils/8.32/config.json	200	
1670	2022-05-15 03:57:43.330553+00	/biowasm/coreutils/8.32/config.json	200	
1671	2022-05-15 03:57:43.314662+00	/biowasm/coreutils/8.32/config.json	200	
1672	2022-05-15 03:57:43.348425+00	/biowasm/coreutils/8.32/config.json	200	
1673	2022-05-15 03:57:43.350208+00	/biowasm/coreutils/8.32/config.json	200	
1674	2022-05-15 03:57:43.357948+00	/biowasm/coreutils/8.32/config.json	200	
1675	2022-05-15 03:57:43.363619+00	/biowasm/coreutils/8.32/config.json	200	
1676	2022-05-15 03:57:43.365056+00	/biowasm/coreutils/8.32/config.json	200	
1677	2022-05-15 03:57:43.370007+00	/biowasm/coreutils/8.32/config.json	200	
1678	2022-05-15 03:57:43.354599+00	/biowasm/coreutils/8.32/config.json	200	
1679	2022-05-15 03:57:43.359899+00	/biowasm/coreutils/8.32/config.json	200	
1680	2022-05-15 03:57:43.355851+00	/biowasm/coreutils/8.32/config.json	200	
1681	2022-05-15 03:57:43.380151+00	/biowasm/coreutils/8.32/config.json	200	
1682	2022-05-15 03:57:43.379551+00	/biowasm/bowtie2/2.4.2/config.json	200	
1683	2022-05-15 03:57:43.382366+00	/biowasm/minimap2/2.22/config.json	200	
1684	2022-05-15 03:57:43.360242+00	/biowasm/fastp/0.20.1/config.json	200	
1685	2022-05-15 03:57:43.389869+00	/biowasm/coreutils/8.32/config.json	200	
1687	2022-05-15 03:57:43.392793+00	/biowasm/gawk/5.1.0/config.json	200	
1686	2022-05-15 03:57:43.390476+00	/biowasm/coreutils/8.32/config.json	200	
1688	2022-05-15 03:57:43.403907+00	/biowasm/bedtools/2.29.2/config.json	200	
1689	2022-05-15 03:57:43.402581+00	/biowasm/coreutils/8.32/config.json	200	
1690	2022-05-15 03:57:43.419331+00	/biowasm/grep/3.7/config.json	200	
1691	2022-05-15 03:57:43.434545+00	/biowasm/bcftools/1.10/config.json	200	
1692	2022-05-15 03:57:43.460444+00	/vim/vim.js	200	
1693	2022-05-15 03:57:43.527103+00	/vim/vim.data	200	
1694	2022-05-15 03:57:43.535457+00	/vim/vim.wasm	200	
1695	2022-05-15 04:00:53.098243+00	/biowasm/base/2.4.0-rc2/base.js	200	
1696	2022-05-15 04:00:55.971003+00	/biowasm/base/2.4.0-rc2/base.js	200	
1697	2022-05-15 15:46:13.336074+00	/playground	200	
1698	2022-05-15 15:46:13.66367+00	/build/bundle.css	200	
1699	2022-05-15 15:46:13.749482+00	/build/bundle.js	200	
1700	2022-05-15 15:46:13.869499+00	/build/bootstrap.min.css.map	404	
1701	2022-05-15 15:46:14.155208+00	/biowasm/base/2.4.0-rc2/base.js	200	
1702	2022-05-15 15:46:14.215543+00	/biowasm/base/2.4.0-rc2/base.wasm	200	
1703	2022-05-15 15:46:14.256717+00	/biowasm/jq/1.6/config.json	200	
1704	2022-05-15 15:46:14.308783+00	/biowasm/jq/1.6/jq.js	200	
1705	2022-05-15 15:46:14.380141+00	/biowasm/jq/1.6/jq.wasm	200	
1706	2022-05-15 15:46:14.483626+00	/biowasm/coreutils/8.32/config.json	200	
1707	2022-05-15 15:46:14.489123+00	/biowasm/coreutils/8.32/config.json	200	
1708	2022-05-15 15:46:14.496375+00	/biowasm/coreutils/8.32/config.json	200	
1709	2022-05-15 15:46:14.501843+00	/biowasm/fastp/0.20.1/config.json	200	
1710	2022-05-15 15:46:14.506695+00	/biowasm/coreutils/8.32/config.json	200	
1711	2022-05-15 15:46:14.515185+00	/biowasm/bcftools/1.10/config.json	200	
1712	2022-05-15 15:46:14.516703+00	/biowasm/grep/3.7/config.json	200	
1713	2022-05-15 15:46:14.521082+00	/biowasm/coreutils/8.32/config.json	200	
1714	2022-05-15 15:46:14.520939+00	/biowasm/coreutils/8.32/config.json	200	
1715	2022-05-15 15:46:14.522977+00	/biowasm/bedtools/2.29.2/config.json	200	
1717	2022-05-15 15:46:14.537759+00	/biowasm/coreutils/8.32/config.json	200	
1722	2022-05-15 15:46:14.555513+00	/biowasm/coreutils/8.32/config.json	200	
1723	2022-05-15 15:46:14.559515+00	/biowasm/coreutils/8.32/config.json	200	
1716	2022-05-15 15:46:14.537854+00	/biowasm/coreutils/8.32/config.json	200	
1718	2022-05-15 15:46:14.541351+00	/biowasm/coreutils/8.32/config.json	200	
1721	2022-05-15 15:46:14.553913+00	/biowasm/coreutils/8.32/config.json	200	
1724	2022-05-15 15:46:14.559398+00	/biowasm/coreutils/8.32/config.json	200	
1719	2022-05-15 15:46:14.542941+00	/biowasm/coreutils/8.32/config.json	200	
1720	2022-05-15 15:46:14.553748+00	/biowasm/coreutils/8.32/config.json	200	
1725	2022-05-15 15:46:14.559551+00	/biowasm/coreutils/8.32/config.json	200	
1726	2022-05-15 15:46:14.546966+00	/biowasm/samtools/1.10/config.json	200	
1727	2022-05-15 15:46:14.579397+00	/vim/vim.js	200	
1728	2022-05-15 15:46:14.587455+00	/biowasm/minimap2/2.22/config.json	200	
1729	2022-05-15 15:46:14.59774+00	/biowasm/coreutils/8.32/config.json	200	
1730	2022-05-15 15:46:14.59685+00	/biowasm/coreutils/8.32/config.json	200	
1731	2022-05-15 15:46:14.608095+00	/biowasm/coreutils/8.32/config.json	200	
1732	2022-05-15 15:46:14.609268+00	/biowasm/bowtie2/2.4.2/config.json	200	
1733	2022-05-15 15:46:14.614326+00	/biowasm/gawk/5.1.0/config.json	200	
1734	2022-05-15 15:46:14.644385+00	/vim/vim.data	200	
1735	2022-05-15 15:46:14.659757+00	/vim/vim.wasm	200	
1736	2022-05-15 20:28:28.470928+00	/playground	200	
1737	2022-05-15 20:28:28.53139+00	/build/bundle.css	200	
1738	2022-05-15 20:28:28.619352+00	/build/bundle.js	200	
1739	2022-05-15 20:28:28.703832+00	/build/bootstrap.min.css.map	404	
1740	2022-05-15 20:28:29.558839+00	/biowasm/base/2.4.0-rc2/base.js	200	
1741	2022-05-15 20:28:29.811329+00	/biowasm/base/2.4.0-rc2/base.wasm	200	
1742	2022-05-15 20:28:30.081737+00	/biowasm/jq/1.6/config.json	200	
1743	2022-05-15 20:28:30.298084+00	/biowasm/jq/1.6/jq.js	200	
1744	2022-05-15 20:28:30.628254+00	/biowasm/jq/1.6/jq.wasm	200	
1745	2022-05-15 20:28:30.853398+00	/biowasm/minimap2/2.22/config.json	200	
1746	2022-05-15 20:28:30.863612+00	/biowasm/coreutils/8.32/config.json	200	
1747	2022-05-15 20:28:30.869909+00	/biowasm/coreutils/8.32/config.json	200	
1748	2022-05-15 20:28:30.872297+00	/biowasm/fastp/0.20.1/config.json	200	
1749	2022-05-15 20:28:30.889375+00	/biowasm/coreutils/8.32/config.json	200	
1750	2022-05-15 20:28:30.88329+00	/biowasm/coreutils/8.32/config.json	200	
1751	2022-05-15 20:28:30.90322+00	/biowasm/coreutils/8.32/config.json	200	
1752	2022-05-15 20:28:30.901603+00	/biowasm/coreutils/8.32/config.json	200	
1753	2022-05-15 20:28:30.899665+00	/biowasm/coreutils/8.32/config.json	200	
1754	2022-05-15 20:28:30.90891+00	/biowasm/bcftools/1.10/config.json	200	
1755	2022-05-15 20:28:30.909957+00	/biowasm/coreutils/8.32/config.json	200	
1756	2022-05-15 20:28:30.909825+00	/biowasm/coreutils/8.32/config.json	200	
1757	2022-05-15 20:28:30.913656+00	/biowasm/coreutils/8.32/config.json	200	
1758	2022-05-15 20:28:30.916067+00	/biowasm/coreutils/8.32/config.json	200	
1759	2022-05-15 20:28:30.916128+00	/biowasm/gawk/5.1.0/config.json	200	
1760	2022-05-15 20:28:30.923933+00	/biowasm/coreutils/8.32/config.json	200	
1761	2022-05-15 20:28:30.925601+00	/biowasm/coreutils/8.32/config.json	200	
1762	2022-05-15 20:28:30.926369+00	/biowasm/grep/3.7/config.json	200	
1763	2022-05-15 20:28:30.932773+00	/biowasm/coreutils/8.32/config.json	200	
1764	2022-05-15 20:28:30.940671+00	/biowasm/coreutils/8.32/config.json	200	
1765	2022-05-15 20:28:30.944447+00	/biowasm/bowtie2/2.4.2/config.json	200	
1766	2022-05-15 20:28:30.955745+00	/biowasm/coreutils/8.32/config.json	200	
1767	2022-05-15 20:28:30.960217+00	/biowasm/coreutils/8.32/config.json	200	
1768	2022-05-15 20:28:30.962153+00	/biowasm/samtools/1.10/config.json	200	
1769	2022-05-15 20:28:30.965411+00	/biowasm/coreutils/8.32/config.json	200	
1770	2022-05-15 20:28:30.97563+00	/biowasm/coreutils/8.32/config.json	200	
1771	2022-05-15 20:28:30.995587+00	/biowasm/bedtools/2.29.2/config.json	200	
1772	2022-05-15 20:28:34.744618+00	/biowasm/coreutils/8.32/ls.js	200	
1773	2022-05-15 20:28:35.059029+00	/biowasm/coreutils/8.32/ls.wasm	200	
1774	2022-05-15 20:28:45.318387+00	/biowasm/coreutils/8.32/cat.js	200	
1775	2022-05-15 20:28:45.587548+00	/biowasm/coreutils/8.32/cat.wasm	200	
1776	2022-05-15 20:29:28.910146+00	/test.py	200	
1777	2022-05-15 22:16:40.714891+00	/build/bootstrap.min.css.map	404	
1778	2022-05-15 22:16:44.734715+00	/playground	200	
1779	2022-05-15 22:16:44.843853+00	/build/bundle.js	200	
1780	2022-05-15 22:16:44.9945+00	/build/bundle.css	200	
1781	2022-05-15 22:16:45.065948+00	/build/bootstrap.min.css.map	404	
1782	2022-05-15 22:16:45.349668+00	/biowasm/base/2.4.0-rc2/base.js	200	
1783	2022-05-15 22:16:45.396075+00	/biowasm/base/2.4.0-rc2/base.wasm	200	
1784	2022-05-15 22:16:45.462989+00	/biowasm/jq/1.6/config.json	200	
1785	2022-05-15 22:16:45.497762+00	/biowasm/jq/1.6/jq.js	200	
1786	2022-05-15 22:16:45.549482+00	/biowasm/jq/1.6/jq.wasm	200	
1787	2022-05-15 22:16:45.632312+00	/biowasm/bcftools/1.10/config.json	200	
1788	2022-05-15 22:16:45.648075+00	/biowasm/samtools/1.10/config.json	200	
1789	2022-05-15 22:16:45.654856+00	/biowasm/bedtools/2.29.2/config.json	200	
1790	2022-05-15 22:16:45.660428+00	/biowasm/gawk/5.1.0/config.json	200	
1791	2022-05-15 22:16:45.669964+00	/biowasm/coreutils/8.32/config.json	200	
1792	2022-05-15 22:16:45.684111+00	/biowasm/coreutils/8.32/config.json	200	
1794	2022-05-15 22:16:45.680009+00	/biowasm/coreutils/8.32/config.json	200	
1793	2022-05-15 22:16:45.677949+00	/biowasm/minimap2/2.22/config.json	200	
1795	2022-05-15 22:16:45.70417+00	/biowasm/coreutils/8.32/config.json	200	
1796	2022-05-15 22:16:45.706776+00	/biowasm/grep/3.7/config.json	200	
1797	2022-05-15 22:16:45.711615+00	/biowasm/coreutils/8.32/config.json	200	
1798	2022-05-15 22:16:45.712835+00	/biowasm/coreutils/8.32/config.json	200	
1799	2022-05-15 22:16:45.712727+00	/biowasm/coreutils/8.32/config.json	200	
1800	2022-05-15 22:16:45.715907+00	/biowasm/coreutils/8.32/config.json	200	
1801	2022-05-15 22:16:45.718202+00	/biowasm/coreutils/8.32/config.json	200	
1802	2022-05-15 22:16:45.724546+00	/biowasm/coreutils/8.32/config.json	200	
1803	2022-05-15 22:16:45.724545+00	/biowasm/coreutils/8.32/config.json	200	
1804	2022-05-15 22:16:45.726642+00	/biowasm/coreutils/8.32/config.json	200	
1805	2022-05-15 22:16:45.705732+00	/biowasm/coreutils/8.32/config.json	200	
1806	2022-05-15 22:16:45.725165+00	/biowasm/coreutils/8.32/config.json	200	
1807	2022-05-15 22:16:45.777153+00	/biowasm/coreutils/8.32/config.json	200	
1808	2022-05-15 22:16:45.771272+00	/biowasm/coreutils/8.32/config.json	200	
1809	2022-05-15 22:16:45.780237+00	/biowasm/fastp/0.20.1/config.json	200	
1810	2022-05-15 22:16:45.786492+00	/biowasm/coreutils/8.32/config.json	200	
1811	2022-05-15 22:16:45.784631+00	/biowasm/coreutils/8.32/config.json	200	
1812	2022-05-15 22:16:45.785642+00	/biowasm/coreutils/8.32/config.json	200	
1813	2022-05-15 22:16:45.791405+00	/biowasm/bowtie2/2.4.2/config.json	200	
1814	2022-05-15 22:16:56.699698+00	/vim/vim.js	200	
1815	2022-05-15 22:16:56.783385+00	/vim/vim.wasm	200	
1816	2022-05-15 22:16:56.946481+00	/vim/vim.data	200	
1817	2022-05-20 13:59:57.823618+00	/	200	
1818	2022-05-20 13:59:57.862655+00	/build/bundle.css	200	
1819	2022-05-20 13:59:57.921921+00	/build/bundle.js	200	
1820	2022-05-20 13:59:58.254689+00	/images/cli.png	200	
1821	2022-05-20 13:59:59.33526+00	/playground	200	
1822	2022-05-21 01:07:01.812195+00	/build/bundle.js	200	
1823	2022-05-26 00:53:08.979333+00	/	200	
1824	2022-05-26 00:53:09.397419+00	/build/bundle.js	200	
1825	2022-05-26 00:53:09.411764+00	/build/bundle.css	200	
1826	2022-05-26 00:53:10.079919+00	/images/cli.png	200	
1827	2022-05-26 00:53:11.614399+00	/playground	200	
1828	2022-06-22 19:36:32.342615+00	/tutorials	200	?id=terminal-basics
1829	2022-06-22 19:36:43.519322+00	/tutorials	200	
1830	2022-06-22 19:36:56.651771+00	/tutorials	200	?id=terminal-basics
1831	2022-06-26 18:06:13.59604+00	/	200	
1832	2022-06-26 18:08:58.167056+00	/	200	
1833	2022-06-26 18:09:01.492137+00	/tutorials	200	
1834	2022-06-26 18:09:04.178329+00	/tutorials	200	?id=jq-intro
\.


--
-- Data for Name: pings; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY "public"."pings" ("id", "time", "ip", "step_from", "step_to", "tutorial") FROM stdin;
171	2021-08-12 01:28:53.946+00	759c7d988093b1c9e9baea57698a1f76	19	18	bedtools-intro
172	2021-08-12 01:31:02.946+00	759c7d988093b1c9e9baea57698a1f76	18	17	bedtools-intro
173	2021-08-12 01:31:04.283+00	759c7d988093b1c9e9baea57698a1f76	17	16	bedtools-intro
174	2021-08-20 21:46:23.92067+00	cae068bee947bac7126bab896ae72903	0	1	bedtools-intro
175	2021-08-20 21:46:24.272357+00	cae068bee947bac7126bab896ae72903	1	2	bedtools-intro
176	2021-08-20 21:46:24.437616+00	cae068bee947bac7126bab896ae72903	2	3	bedtools-intro
177	2021-08-23 17:16:59.211997+00	20ba6e8457e204e24356ccc3c040a117	0	1	bedtools-intro
178	2021-08-23 17:16:59.55379+00	20ba6e8457e204e24356ccc3c040a117	1	2	bedtools-intro
179	2021-08-23 17:16:59.689794+00	20ba6e8457e204e24356ccc3c040a117	2	3	bedtools-intro
180	2021-08-23 17:16:59.846964+00	20ba6e8457e204e24356ccc3c040a117	3	4	bedtools-intro
181	2021-08-25 02:09:19.87349+00	be517575a46ca20e1156fb594847f00a	0	1	terminal-basics
182	2021-08-25 02:11:35.516598+00	be517575a46ca20e1156fb594847f00a	1	2	terminal-basics
183	2021-08-25 02:12:35.988683+00	be517575a46ca20e1156fb594847f00a	2	3	terminal-basics
184	2021-08-25 02:13:04.051043+00	be517575a46ca20e1156fb594847f00a	3	4	terminal-basics
185	2021-08-25 02:14:25.131566+00	be517575a46ca20e1156fb594847f00a	4	5	terminal-basics
186	2021-08-25 02:17:42.585198+00	be517575a46ca20e1156fb594847f00a	5	6	terminal-basics
187	2021-08-25 02:20:18.464636+00	be517575a46ca20e1156fb594847f00a	6	7	terminal-basics
188	2021-08-25 14:48:22.206053+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	0	1	terminal-basics
189	2021-08-25 14:48:55.620001+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	1	2	terminal-basics
190	2021-08-25 14:49:25.52091+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	2	3	terminal-basics
191	2021-08-25 14:49:42.154169+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	3	4	terminal-basics
192	2021-08-25 14:50:00.994607+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	4	5	terminal-basics
193	2021-08-25 14:51:31.589384+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	5	6	terminal-basics
194	2021-08-25 14:52:14.071728+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	6	7	terminal-basics
195	2021-08-25 14:52:34.220146+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	0	1	bedtools-intro
196	2021-08-25 14:52:34.732795+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	1	2	bedtools-intro
197	2021-08-25 14:52:36.722592+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	2	3	bedtools-intro
198	2021-08-25 14:52:37.140655+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	3	4	bedtools-intro
199	2021-08-25 14:52:37.589942+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	4	5	bedtools-intro
200	2021-08-25 14:52:42.135843+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	5	6	bedtools-intro
201	2021-08-25 14:52:46.414801+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	6	7	bedtools-intro
202	2021-08-25 14:52:51.407368+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	7	8	bedtools-intro
203	2021-08-25 14:52:53.230053+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	8	9	bedtools-intro
204	2021-08-25 14:52:57.491361+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	9	10	bedtools-intro
205	2021-08-25 14:52:59.448587+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	10	11	bedtools-intro
206	2021-08-25 14:53:01.936422+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	11	12	bedtools-intro
207	2021-08-25 14:53:17.790314+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	13	14	bedtools-intro
208	2021-08-25 14:53:17.812398+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	12	13	bedtools-intro
209	2021-08-25 14:53:18.524566+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	14	13	bedtools-intro
210	2021-08-25 14:53:21.877068+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	13	14	bedtools-intro
211	2021-08-25 14:53:48.810978+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	14	15	bedtools-intro
212	2021-08-25 14:53:59.738955+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	0	1	bowtie2-intro
213	2021-08-25 14:54:00.298854+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	1	2	bowtie2-intro
214	2021-08-25 14:54:05.53256+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	2	3	bowtie2-intro
215	2021-08-25 14:54:07.318908+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	3	4	bowtie2-intro
216	2021-08-25 14:54:10.633769+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	4	5	bowtie2-intro
217	2021-08-25 14:54:14.193714+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	5	6	bowtie2-intro
218	2021-08-25 14:54:35.98405+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	6	7	bowtie2-intro
219	2021-08-25 14:54:40.391114+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	0	1	samtools-intro
220	2021-08-25 14:54:41.019513+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	1	2	samtools-intro
221	2021-08-25 14:54:41.920398+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	2	3	samtools-intro
222	2021-08-25 14:54:44.776579+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	3	4	samtools-intro
223	2021-08-25 14:54:49.830748+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	4	5	samtools-intro
224	2021-08-25 14:54:54.309401+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	5	6	samtools-intro
225	2021-08-25 14:55:17.090903+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	0	1	bedtools-intro
226	2021-08-25 14:57:22.407692+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	0	1	samtools-intro
227	2021-08-25 14:57:22.981399+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	1	2	samtools-intro
228	2021-08-25 14:57:23.5437+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	2	3	samtools-intro
229	2021-08-25 14:57:24.231185+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	3	4	samtools-intro
230	2021-08-25 14:57:24.426988+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	4	5	samtools-intro
231	2021-08-25 14:57:24.870468+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	5	6	samtools-intro
232	2021-08-25 14:59:38.076462+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	0	1	bedtools-intro
233	2021-08-25 15:01:44.644313+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	0	1	terminal-basics
234	2021-08-25 15:01:45.042107+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	1	2	terminal-basics
235	2021-08-25 15:01:45.68523+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	2	3	terminal-basics
236	2021-08-25 15:01:48.57068+00	99d7fe0c7c2c88c98f3dc7ba7c9fc7e8	3	4	terminal-basics
237	2021-08-31 17:31:33.861427+00	44e601c784e0465c2a1c09f135ebac86	0	1	samtools-intro
238	2021-08-31 17:31:33.950428+00	44e601c784e0465c2a1c09f135ebac86	1	2	samtools-intro
239	2021-08-31 17:31:34.226729+00	44e601c784e0465c2a1c09f135ebac86	2	3	samtools-intro
240	2021-08-31 17:31:34.38009+00	44e601c784e0465c2a1c09f135ebac86	3	4	samtools-intro
241	2021-08-31 17:31:34.654231+00	44e601c784e0465c2a1c09f135ebac86	4	5	samtools-intro
242	2021-08-31 17:31:34.791899+00	44e601c784e0465c2a1c09f135ebac86	5	6	samtools-intro
243	2021-08-31 17:31:35.145944+00	44e601c784e0465c2a1c09f135ebac86	6	7	samtools-intro
244	2021-08-31 17:31:35.605625+00	44e601c784e0465c2a1c09f135ebac86	7	8	samtools-intro
245	2021-08-31 17:31:35.995488+00	44e601c784e0465c2a1c09f135ebac86	8	7	samtools-intro
246	2021-08-31 17:31:36.186429+00	44e601c784e0465c2a1c09f135ebac86	7	6	samtools-intro
247	2021-09-01 20:14:21.874036+00	4d5f71d152e9cd52afddb66c0ef71619	0	1	bedtools-intro
248	2021-09-01 20:14:23.164256+00	4d5f71d152e9cd52afddb66c0ef71619	1	2	bedtools-intro
249	2021-09-01 20:14:44.48916+00	4d5f71d152e9cd52afddb66c0ef71619	2	3	bedtools-intro
250	2021-09-01 20:17:43.616504+00	4d5f71d152e9cd52afddb66c0ef71619	3	4	bedtools-intro
251	2021-09-01 20:17:50.157472+00	4d5f71d152e9cd52afddb66c0ef71619	4	5	bedtools-intro
252	2021-09-01 21:14:03.914136+00	4d5f71d152e9cd52afddb66c0ef71619	0	1	terminal-basics
253	2021-09-01 21:14:07.022233+00	4d5f71d152e9cd52afddb66c0ef71619	1	2	terminal-basics
254	2021-09-01 23:01:29.463508+00	4d5f71d152e9cd52afddb66c0ef71619	5	6	bedtools-intro
255	2021-09-01 23:01:31.009172+00	4d5f71d152e9cd52afddb66c0ef71619	6	7	bedtools-intro
256	2021-09-01 23:01:35.045654+00	4d5f71d152e9cd52afddb66c0ef71619	7	19	bedtools-intro
257	2021-09-01 23:01:51.032857+00	4d5f71d152e9cd52afddb66c0ef71619	0	1	bowtie2-intro
258	2021-09-01 23:01:51.170221+00	4d5f71d152e9cd52afddb66c0ef71619	1	2	bowtie2-intro
259	2021-09-01 23:01:51.318686+00	4d5f71d152e9cd52afddb66c0ef71619	2	3	bowtie2-intro
260	2021-09-01 23:01:51.465848+00	4d5f71d152e9cd52afddb66c0ef71619	3	4	bowtie2-intro
261	2021-09-01 23:01:51.607182+00	4d5f71d152e9cd52afddb66c0ef71619	4	5	bowtie2-intro
262	2021-09-01 23:01:51.894661+00	4d5f71d152e9cd52afddb66c0ef71619	5	6	bowtie2-intro
263	2021-09-01 23:01:52.05915+00	4d5f71d152e9cd52afddb66c0ef71619	6	7	bowtie2-intro
264	2021-09-01 23:03:01.304854+00	4d5f71d152e9cd52afddb66c0ef71619	0	7	terminal-basics
265	2021-09-01 23:25:00.559218+00	4d5f71d152e9cd52afddb66c0ef71619	0	1	terminal-basics
266	2021-09-01 23:25:09.230385+00	4d5f71d152e9cd52afddb66c0ef71619	1	2	terminal-basics
267	2021-09-01 23:27:55.791624+00	44e601c784e0465c2a1c09f135ebac86	0	1	bedtools-intro
268	2021-09-01 23:27:56.072203+00	44e601c784e0465c2a1c09f135ebac86	1	2	bedtools-intro
269	2021-09-01 23:27:56.498159+00	44e601c784e0465c2a1c09f135ebac86	2	3	bedtools-intro
270	2021-09-01 23:27:56.855629+00	44e601c784e0465c2a1c09f135ebac86	3	4	bedtools-intro
271	2021-09-01 23:27:57.267243+00	44e601c784e0465c2a1c09f135ebac86	4	5	bedtools-intro
272	2021-09-01 23:27:57.430554+00	44e601c784e0465c2a1c09f135ebac86	5	6	bedtools-intro
273	2021-09-01 23:27:57.624609+00	44e601c784e0465c2a1c09f135ebac86	6	7	bedtools-intro
274	2021-09-01 23:27:57.877094+00	44e601c784e0465c2a1c09f135ebac86	7	8	bedtools-intro
275	2021-09-01 23:27:58.301945+00	44e601c784e0465c2a1c09f135ebac86	8	9	bedtools-intro
276	2021-09-01 23:27:58.8469+00	44e601c784e0465c2a1c09f135ebac86	9	10	bedtools-intro
277	2021-09-01 23:27:59.39835+00	44e601c784e0465c2a1c09f135ebac86	10	11	bedtools-intro
278	2021-09-01 23:27:59.916972+00	44e601c784e0465c2a1c09f135ebac86	11	12	bedtools-intro
279	2021-09-01 23:28:00.455993+00	44e601c784e0465c2a1c09f135ebac86	12	13	bedtools-intro
280	2021-09-01 23:28:01.743023+00	44e601c784e0465c2a1c09f135ebac86	13	14	bedtools-intro
281	2021-09-01 23:29:56.520068+00	4d5f71d152e9cd52afddb66c0ef71619	14	15	bedtools-intro
282	2021-09-01 23:30:44.479914+00	4d5f71d152e9cd52afddb66c0ef71619	0	1	bowtie2-intro
283	2021-09-01 23:30:45.49612+00	4d5f71d152e9cd52afddb66c0ef71619	1	2	bowtie2-intro
284	2021-09-01 23:31:05.440078+00	4d5f71d152e9cd52afddb66c0ef71619	2	3	bowtie2-intro
285	2021-09-01 23:31:07.32442+00	4d5f71d152e9cd52afddb66c0ef71619	3	4	bowtie2-intro
286	2021-09-01 23:31:13.496912+00	4d5f71d152e9cd52afddb66c0ef71619	4	5	bowtie2-intro
287	2021-09-01 23:31:26.327719+00	4d5f71d152e9cd52afddb66c0ef71619	5	6	bowtie2-intro
288	2021-09-01 23:31:57.20796+00	4d5f71d152e9cd52afddb66c0ef71619	6	5	bowtie2-intro
289	2021-09-01 23:32:12.714808+00	4d5f71d152e9cd52afddb66c0ef71619	5	6	bowtie2-intro
290	2021-09-01 23:32:17.288917+00	4d5f71d152e9cd52afddb66c0ef71619	6	7	bowtie2-intro
291	2021-09-01 23:32:18.733192+00	4d5f71d152e9cd52afddb66c0ef71619	7	6	bowtie2-intro
292	2021-09-01 23:33:00.649503+00	4d5f71d152e9cd52afddb66c0ef71619	6	5	bowtie2-intro
293	2021-09-01 23:33:01.56031+00	4d5f71d152e9cd52afddb66c0ef71619	5	4	bowtie2-intro
294	2021-09-01 23:33:01.842068+00	4d5f71d152e9cd52afddb66c0ef71619	4	3	bowtie2-intro
295	2021-09-01 23:33:02.443222+00	4d5f71d152e9cd52afddb66c0ef71619	3	4	bowtie2-intro
296	2021-09-01 23:33:02.720302+00	4d5f71d152e9cd52afddb66c0ef71619	4	5	bowtie2-intro
297	2021-09-01 23:33:02.914072+00	4d5f71d152e9cd52afddb66c0ef71619	5	6	bowtie2-intro
298	2021-09-01 23:34:30.561673+00	4d5f71d152e9cd52afddb66c0ef71619	6	7	bowtie2-intro
299	2021-09-01 23:34:34.879452+00	4d5f71d152e9cd52afddb66c0ef71619	0	1	samtools-intro
300	2021-09-01 23:34:36.088745+00	4d5f71d152e9cd52afddb66c0ef71619	1	2	samtools-intro
301	2021-09-01 23:34:37.816648+00	4d5f71d152e9cd52afddb66c0ef71619	2	3	samtools-intro
302	2021-09-01 23:34:41.218681+00	4d5f71d152e9cd52afddb66c0ef71619	3	4	samtools-intro
303	2021-09-01 23:34:46.180826+00	4d5f71d152e9cd52afddb66c0ef71619	4	5	samtools-intro
304	2021-09-01 23:34:53.956588+00	4d5f71d152e9cd52afddb66c0ef71619	5	6	samtools-intro
305	2021-09-01 23:34:58.799722+00	4d5f71d152e9cd52afddb66c0ef71619	6	7	samtools-intro
306	2021-09-01 23:34:59.542864+00	4d5f71d152e9cd52afddb66c0ef71619	7	8	samtools-intro
307	2021-09-01 23:35:00.900547+00	4d5f71d152e9cd52afddb66c0ef71619	8	9	samtools-intro
308	2021-09-03 02:56:16.657373+00	28ab9d9d1c2e448bbc579a00008928ec	0	1	terminal-basics
309	2021-09-03 02:56:17.648963+00	28ab9d9d1c2e448bbc579a00008928ec	1	2	terminal-basics
310	2021-09-03 03:00:16.059275+00	28ab9d9d1c2e448bbc579a00008928ec	2	3	terminal-basics
311	2021-09-03 03:00:16.223386+00	28ab9d9d1c2e448bbc579a00008928ec	3	4	terminal-basics
312	2021-09-03 03:00:16.385837+00	28ab9d9d1c2e448bbc579a00008928ec	4	5	terminal-basics
313	2021-09-03 03:00:16.538106+00	28ab9d9d1c2e448bbc579a00008928ec	5	6	terminal-basics
314	2021-09-03 03:00:16.840756+00	28ab9d9d1c2e448bbc579a00008928ec	6	7	terminal-basics
315	2021-09-06 20:53:11.453023+00	f138e95352445fd8529580ed7af2532f	15	14	bedtools-intro
316	2021-09-07 19:44:59.063021+00	f138e95352445fd8529580ed7af2532f	15	14	bedtools-intro
317	2021-09-07 19:44:59.788274+00	f138e95352445fd8529580ed7af2532f	14	15	bedtools-intro
318	2021-09-07 23:17:20.919312+00	2007cf018ed762be00e1f680665bb6b8	0	1	jq-intro
319	2021-09-07 23:17:25.107131+00	2007cf018ed762be00e1f680665bb6b8	1	0	jq-intro
320	2021-09-07 23:17:26.780505+00	2007cf018ed762be00e1f680665bb6b8	0	1	jq-intro
321	2021-09-07 23:17:30.364611+00	2007cf018ed762be00e1f680665bb6b8	1	0	jq-intro
322	2021-09-07 23:17:33.349052+00	2007cf018ed762be00e1f680665bb6b8	0	1	jq-intro
323	2021-09-07 23:17:34.690364+00	2007cf018ed762be00e1f680665bb6b8	1	0	jq-intro
324	2021-09-07 23:17:35.615322+00	2007cf018ed762be00e1f680665bb6b8	0	1	jq-intro
325	2021-09-07 23:19:53.690838+00	2007cf018ed762be00e1f680665bb6b8	1	2	jq-intro
326	2021-09-07 23:24:03.614929+00	2007cf018ed762be00e1f680665bb6b8	2	3	jq-intro
327	2021-09-07 23:34:39.84717+00	2007cf018ed762be00e1f680665bb6b8	3	4	jq-intro
328	2021-09-07 23:35:24.068633+00	2007cf018ed762be00e1f680665bb6b8	4	5	jq-intro
329	2021-09-07 23:36:18.681651+00	2007cf018ed762be00e1f680665bb6b8	5	6	jq-intro
330	2021-09-07 23:37:24.562415+00	2007cf018ed762be00e1f680665bb6b8	6	7	jq-intro
331	2021-09-07 23:45:51.499299+00	2007cf018ed762be00e1f680665bb6b8	7	8	jq-intro
332	2021-09-07 23:48:15.150297+00	2007cf018ed762be00e1f680665bb6b8	8	9	jq-intro
333	2022-05-08 23:07:32.963032+00	1b2512286e88198fe310a837b9961c69	0	1	fastp-intro
334	2022-05-08 23:07:33.697709+00	1b2512286e88198fe310a837b9961c69	1	2	fastp-intro
335	2022-05-08 23:07:35.828011+00	1b2512286e88198fe310a837b9961c69	2	3	fastp-intro
336	2022-06-22 19:36:57.997814+00	933d2aa25b8528a6daf8fa2de9ca37a8	0	1	terminal-basics
337	2022-06-22 19:36:58.14018+00	933d2aa25b8528a6daf8fa2de9ca37a8	1	2	terminal-basics
338	2022-06-22 19:36:58.274403+00	933d2aa25b8528a6daf8fa2de9ca37a8	2	3	terminal-basics
339	2022-06-22 19:36:58.406207+00	933d2aa25b8528a6daf8fa2de9ca37a8	3	4	terminal-basics
340	2022-06-22 19:36:58.528767+00	933d2aa25b8528a6daf8fa2de9ca37a8	4	5	terminal-basics
341	2022-06-22 19:37:30.138162+00	6fe1bc54b4af2f7f3879b1ec3ec3aca5	6	7	terminal-basics
\.


--
-- Data for Name: state; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY "public"."state" ("id", "user_id", "env", "progress") FROM stdin;
2	7bc09320-2922-4f85-b614-44f9369c3733	{"test": "nope"}	\N
12	c661f0e6-f87d-4782-827a-bfbb2de14b6f	{"PS1": "\\\\u@\\\\h$ ", "HOME": "/shared/data", "USER": "maria"}	{"jq-intro": {"step": 9}, "terminal-basics": {"step": 7}}
8	22b3ff6f-fdbd-4d90-8ed4-bdd8f103f065	{"PS1": "\\\\u@\\\\h$ ", "REF": "/bowtie2/example/index/lambda_virus", "def": "hello", "HOME": "/shared/data", "USER": "robert", "REF_FASTA": "/bowtie2/example/reference/lambda_virus.fa"}	{"jq-intro": {"step": 9}, "rosalind": {"step": 20}, "awk-intro": {"step": 10}, "dna-secrets": {"step": 8}, "fastp-intro": {"step": 9}, "bowtie2-intro": {"step": 7}, "bedtools-intro": {"step": 15}, "samtools-intro": {"step": 9}, "terminal-basics": {"step": 7}}
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."schema_migrations" ("version", "inserted_at") FROM stdin;
20211116024918	2021-12-01 08:12:57
20211116045059	2021-12-01 08:12:57
20211116050929	2021-12-01 08:12:57
20211116051442	2021-12-01 08:12:57
20211116212300	2021-12-01 08:12:57
20211116213355	2021-12-01 08:12:57
20211116213934	2021-12-01 08:12:57
20211116214523	2021-12-01 08:12:57
20211122062447	2021-12-01 08:12:57
20211124070109	2021-12-01 08:12:57
20211202204204	2021-12-04 07:43:18
20211202204605	2021-12-04 07:43:18
20211210212804	2022-01-22 02:32:57
20220107221237	2022-01-22 02:32:57
20211228014915	2022-04-01 04:06:03
20220228202821	2022-04-01 04:06:03
20220312004840	2022-04-01 04:06:03
20220603231003	2022-07-31 00:54:14
20220603232444	2022-07-31 00:54:14
20220615214548	2022-07-31 00:54:14
20220712093339	2022-07-31 00:54:14
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."subscription" ("id", "subscription_id", "entity", "filters", "claims", "created_at") FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public") FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."migrations" ("id", "name", "hash", "executed_at") FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2021-08-18 23:11:52.626481
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2021-08-18 23:11:52.62995
2	pathtoken-column	49756be03be4c17bb85fe70d4a861f27de7e49ad	2021-08-18 23:11:52.632367
3	add-migrations-rls	bb5d124c53d68635a883e399426c6a5a25fc893d	2021-08-18 23:11:52.654201
4	add-size-functions	6d79007d04f5acd288c9c250c42d2d5fd286c54d	2021-08-18 23:11:52.656909
5	change-column-name-in-get-size	fd65688505d2ffa9fbdc58a944348dd8604d688c	2021-08-18 23:11:52.659966
6	add-rls-to-buckets	63e2bab75a2040fee8e3fb3f15a0d26f3380e9b6	2021-08-18 23:11:52.663021
7	add-public-to-buckets	82568934f8a4d9e0a85f126f6fb483ad8214c418	2021-08-18 23:11:52.665828
8	fix-search-function	1a43a40eddb525f2e2f26efd709e6c06e58e059c	2021-11-30 09:27:22.054029
9	search-files-search-function	34c096597eb8b9d077fdfdde9878c88501b2fafc	2022-04-06 03:33:17.383733
10	add-trigger-to-auto-update-updated_at-column	37d6bb964a70a822e6d37f22f457b9bca7885928	2022-06-28 10:27:41.346113
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."objects" ("id", "bucket_id", "name", "owner", "created_at", "updated_at", "last_accessed_at", "metadata") FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('"auth"."refresh_tokens_id_seq"', 387, true);


--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: supabase_admin
--

SELECT pg_catalog.setval('"public"."logs_id_seq"', 1834, true);


--
-- Name: pings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: supabase_admin
--

SELECT pg_catalog.setval('"public"."pings_id_seq"', 341, true);


--
-- Name: state_env_id_seq; Type: SEQUENCE SET; Schema: public; Owner: supabase_admin
--

SELECT pg_catalog.setval('"public"."state_env_id_seq"', 12, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_admin
--

SELECT pg_catalog.setval('"realtime"."subscription_id_seq"', 1, false);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."audit_log_entries"
    ADD CONSTRAINT "audit_log_entries_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_pkey" PRIMARY KEY ("provider", "id");


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."instances"
    ADD CONSTRAINT "instances_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_token_unique" UNIQUE ("token");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_email_key" UNIQUE ("email");


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_phone_key" UNIQUE ("phone");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");


--
-- Name: logs logs_pkey; Type: CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY "public"."logs"
    ADD CONSTRAINT "logs_pkey" PRIMARY KEY ("id");


--
-- Name: pings pings_pkey; Type: CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY "public"."pings"
    ADD CONSTRAINT "pings_pkey" PRIMARY KEY ("id");


--
-- Name: state state_env_pkey; Type: CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY "public"."state"
    ADD CONSTRAINT "state_env_pkey" PRIMARY KEY ("id");


--
-- Name: state unique_user_id; Type: CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY "public"."state"
    ADD CONSTRAINT "unique_user_id" UNIQUE ("user_id");


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."subscription"
    ADD CONSTRAINT "pk_subscription" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets"
    ADD CONSTRAINT "buckets_pkey" PRIMARY KEY ("id");


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_name_key" UNIQUE ("name");


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_pkey" PRIMARY KEY ("id");


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_pkey" PRIMARY KEY ("id");


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "audit_logs_instance_id_idx" ON "auth"."audit_log_entries" USING "btree" ("instance_id");


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "confirmation_token_idx" ON "auth"."users" USING "btree" ("confirmation_token") WHERE (("confirmation_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_current_idx" ON "auth"."users" USING "btree" ("email_change_token_current") WHERE (("email_change_token_current")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_new_idx" ON "auth"."users" USING "btree" ("email_change_token_new") WHERE (("email_change_token_new")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_user_id_idx" ON "auth"."identities" USING "btree" ("user_id");


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "reauthentication_token_idx" ON "auth"."users" USING "btree" ("reauthentication_token") WHERE (("reauthentication_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "recovery_token_idx" ON "auth"."users" USING "btree" ("recovery_token") WHERE (("recovery_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id");


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_user_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id", "user_id");


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_parent_idx" ON "auth"."refresh_tokens" USING "btree" ("parent");


--
-- Name: refresh_tokens_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_token_idx" ON "auth"."refresh_tokens" USING "btree" ("token");


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_email_idx" ON "auth"."users" USING "btree" ("instance_id", "lower"(("email")::"text"));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_idx" ON "auth"."users" USING "btree" ("instance_id");


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "ix_realtime_subscription_entity" ON "realtime"."subscription" USING "hash" ("entity");


--
-- Name: subscription_subscription_id_entity_filters_key; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX "subscription_subscription_id_entity_filters_key" ON "realtime"."subscription" USING "btree" ("subscription_id", "entity", "filters");


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bname" ON "storage"."buckets" USING "btree" ("name");


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bucketid_objname" ON "storage"."objects" USING "btree" ("bucket_id", "name");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "name_prefix_search" ON "storage"."objects" USING "btree" ("name" "text_pattern_ops");


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_admin
--

CREATE TRIGGER "tr_check_filters" BEFORE INSERT OR UPDATE ON "realtime"."subscription" FOR EACH ROW EXECUTE FUNCTION "realtime"."subscription_check_filters"();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "update_objects_updated_at" BEFORE UPDATE ON "storage"."objects" FOR EACH ROW EXECUTE FUNCTION "storage"."update_updated_at_column"();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_parent_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_parent_fkey" FOREIGN KEY ("parent") REFERENCES "auth"."refresh_tokens"("token");


--
-- Name: state state_env_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY "public"."state"
    ADD CONSTRAINT "state_env_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id");


--
-- Name: buckets buckets_owner_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets"
    ADD CONSTRAINT "buckets_owner_fkey" FOREIGN KEY ("owner") REFERENCES "auth"."users"("id");


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: objects objects_owner_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_owner_fkey" FOREIGN KEY ("owner") REFERENCES "auth"."users"("id");


--
-- Name: state INSERT; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY "INSERT" ON "public"."state" FOR INSERT WITH CHECK (("auth"."uid"() = "user_id"));


--
-- Name: state SELECT; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY "SELECT" ON "public"."state" FOR SELECT USING (("auth"."uid"() = "user_id"));


--
-- Name: state UPDATE; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY "UPDATE" ON "public"."state" FOR UPDATE USING (("auth"."uid"() = "user_id")) WITH CHECK (("auth"."uid"() = "user_id"));


--
-- Name: logs; Type: ROW SECURITY; Schema: public; Owner: supabase_admin
--

ALTER TABLE "public"."logs" ENABLE ROW LEVEL SECURITY;

--
-- Name: pings; Type: ROW SECURITY; Schema: public; Owner: supabase_admin
--

ALTER TABLE "public"."pings" ENABLE ROW LEVEL SECURITY;

--
-- Name: state; Type: ROW SECURITY; Schema: public; Owner: supabase_admin
--

ALTER TABLE "public"."state" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets" ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."objects" ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION "supabase_realtime" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";

--
-- Name: SCHEMA "auth"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "auth" TO "anon";
GRANT USAGE ON SCHEMA "auth" TO "authenticated";
GRANT USAGE ON SCHEMA "auth" TO "service_role";
GRANT ALL ON SCHEMA "auth" TO "supabase_auth_admin";
GRANT ALL ON SCHEMA "auth" TO "dashboard_user";
GRANT ALL ON SCHEMA "auth" TO "postgres";


--
-- Name: SCHEMA "extensions"; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA "extensions" TO "anon";
GRANT USAGE ON SCHEMA "extensions" TO "authenticated";
GRANT USAGE ON SCHEMA "extensions" TO "service_role";
GRANT ALL ON SCHEMA "extensions" TO "dashboard_user";


--
-- Name: SCHEMA "graphql_public"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "graphql_public" TO "postgres";
GRANT USAGE ON SCHEMA "graphql_public" TO "anon";
GRANT USAGE ON SCHEMA "graphql_public" TO "authenticated";
GRANT USAGE ON SCHEMA "graphql_public" TO "service_role";


--
-- Name: SCHEMA "public"; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";


--
-- Name: SCHEMA "realtime"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "realtime" TO "postgres";


--
-- Name: SCHEMA "storage"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT ALL ON SCHEMA "storage" TO "postgres";
GRANT USAGE ON SCHEMA "storage" TO "anon";
GRANT USAGE ON SCHEMA "storage" TO "authenticated";
GRANT USAGE ON SCHEMA "storage" TO "service_role";
GRANT ALL ON SCHEMA "storage" TO "supabase_storage_admin";
GRANT ALL ON SCHEMA "storage" TO "dashboard_user";


--
-- Name: FUNCTION "email"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."email"() TO "postgres";
GRANT ALL ON FUNCTION "auth"."email"() TO "dashboard_user";


--
-- Name: FUNCTION "jwt"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."jwt"() TO "postgres";
GRANT ALL ON FUNCTION "auth"."jwt"() TO "dashboard_user";


--
-- Name: FUNCTION "role"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."role"() TO "postgres";
GRANT ALL ON FUNCTION "auth"."role"() TO "dashboard_user";


--
-- Name: FUNCTION "uid"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."uid"() TO "postgres";
GRANT ALL ON FUNCTION "auth"."uid"() TO "dashboard_user";


--
-- Name: FUNCTION "get_built_schema_version"(); Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql"."get_built_schema_version"() TO "postgres";
GRANT ALL ON FUNCTION "graphql"."get_built_schema_version"() TO "anon";
GRANT ALL ON FUNCTION "graphql"."get_built_schema_version"() TO "authenticated";
GRANT ALL ON FUNCTION "graphql"."get_built_schema_version"() TO "service_role";


--
-- Name: FUNCTION "rebuild_on_ddl"(); Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql"."rebuild_on_ddl"() TO "postgres";
GRANT ALL ON FUNCTION "graphql"."rebuild_on_ddl"() TO "anon";
GRANT ALL ON FUNCTION "graphql"."rebuild_on_ddl"() TO "authenticated";
GRANT ALL ON FUNCTION "graphql"."rebuild_on_ddl"() TO "service_role";


--
-- Name: FUNCTION "rebuild_on_drop"(); Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql"."rebuild_on_drop"() TO "postgres";
GRANT ALL ON FUNCTION "graphql"."rebuild_on_drop"() TO "anon";
GRANT ALL ON FUNCTION "graphql"."rebuild_on_drop"() TO "authenticated";
GRANT ALL ON FUNCTION "graphql"."rebuild_on_drop"() TO "service_role";


--
-- Name: FUNCTION "rebuild_schema"(); Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql"."rebuild_schema"() TO "postgres";
GRANT ALL ON FUNCTION "graphql"."rebuild_schema"() TO "anon";
GRANT ALL ON FUNCTION "graphql"."rebuild_schema"() TO "authenticated";
GRANT ALL ON FUNCTION "graphql"."rebuild_schema"() TO "service_role";


--
-- Name: FUNCTION "variable_definitions_sort"("variable_definitions" "jsonb"); Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql"."variable_definitions_sort"("variable_definitions" "jsonb") TO "postgres";
GRANT ALL ON FUNCTION "graphql"."variable_definitions_sort"("variable_definitions" "jsonb") TO "anon";
GRANT ALL ON FUNCTION "graphql"."variable_definitions_sort"("variable_definitions" "jsonb") TO "authenticated";
GRANT ALL ON FUNCTION "graphql"."variable_definitions_sort"("variable_definitions" "jsonb") TO "service_role";


--
-- Name: FUNCTION "graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb"); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "postgres";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "anon";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "authenticated";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "service_role";


--
-- Name: FUNCTION "get_auth"("p_usename" "text"); Type: ACL; Schema: pgbouncer; Owner: postgres
--

REVOKE ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") TO "pgbouncer";


--
-- Name: FUNCTION "apply_rls"("wal" "jsonb", "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "dashboard_user";


--
-- Name: FUNCTION "build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "dashboard_user";


--
-- Name: FUNCTION "cast"("val" "text", "type_" "regtype"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "dashboard_user";


--
-- Name: FUNCTION "check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "dashboard_user";


--
-- Name: FUNCTION "is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "dashboard_user";


--
-- Name: FUNCTION "quote_wal2json"("entity" "regclass"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "dashboard_user";


--
-- Name: FUNCTION "subscription_check_filters"(); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "dashboard_user";


--
-- Name: FUNCTION "to_regrole"("role_name" "text"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "extension"("name" "text"); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION "storage"."extension"("name" "text") TO "anon";
GRANT ALL ON FUNCTION "storage"."extension"("name" "text") TO "authenticated";
GRANT ALL ON FUNCTION "storage"."extension"("name" "text") TO "service_role";


--
-- Name: FUNCTION "filename"("name" "text"); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION "storage"."filename"("name" "text") TO "anon";
GRANT ALL ON FUNCTION "storage"."filename"("name" "text") TO "authenticated";
GRANT ALL ON FUNCTION "storage"."filename"("name" "text") TO "service_role";


--
-- Name: FUNCTION "foldername"("name" "text"); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION "storage"."foldername"("name" "text") TO "anon";
GRANT ALL ON FUNCTION "storage"."foldername"("name" "text") TO "authenticated";
GRANT ALL ON FUNCTION "storage"."foldername"("name" "text") TO "service_role";


--
-- Name: TABLE "audit_log_entries"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."audit_log_entries" TO "dashboard_user";
GRANT ALL ON TABLE "auth"."audit_log_entries" TO "postgres";


--
-- Name: TABLE "identities"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."identities" TO "postgres";
GRANT ALL ON TABLE "auth"."identities" TO "dashboard_user";


--
-- Name: TABLE "instances"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."instances" TO "dashboard_user";
GRANT ALL ON TABLE "auth"."instances" TO "postgres";


--
-- Name: TABLE "refresh_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."refresh_tokens" TO "dashboard_user";
GRANT ALL ON TABLE "auth"."refresh_tokens" TO "postgres";


--
-- Name: SEQUENCE "refresh_tokens_id_seq"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "postgres";
GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "dashboard_user";


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."schema_migrations" TO "dashboard_user";
GRANT ALL ON TABLE "auth"."schema_migrations" TO "postgres";


--
-- Name: TABLE "users"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."users" TO "dashboard_user";
GRANT ALL ON TABLE "auth"."users" TO "postgres";


--
-- Name: TABLE "pg_stat_statements"; Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON TABLE "extensions"."pg_stat_statements" TO "dashboard_user";


--
-- Name: TABLE "schema_version"; Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON TABLE "graphql"."schema_version" TO "postgres";
GRANT ALL ON TABLE "graphql"."schema_version" TO "anon";
GRANT ALL ON TABLE "graphql"."schema_version" TO "authenticated";
GRANT ALL ON TABLE "graphql"."schema_version" TO "service_role";


--
-- Name: SEQUENCE "seq_schema_version"; Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE "graphql"."seq_schema_version" TO "postgres";
GRANT ALL ON SEQUENCE "graphql"."seq_schema_version" TO "anon";
GRANT ALL ON SEQUENCE "graphql"."seq_schema_version" TO "authenticated";
GRANT ALL ON SEQUENCE "graphql"."seq_schema_version" TO "service_role";


--
-- Name: TABLE "logs"; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON TABLE "public"."logs" TO "postgres";
GRANT ALL ON TABLE "public"."logs" TO "anon";
GRANT ALL ON TABLE "public"."logs" TO "authenticated";
GRANT ALL ON TABLE "public"."logs" TO "service_role";


--
-- Name: SEQUENCE "logs_id_seq"; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE "public"."logs_id_seq" TO "postgres";
GRANT ALL ON SEQUENCE "public"."logs_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."logs_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."logs_id_seq" TO "service_role";


--
-- Name: TABLE "pings"; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON TABLE "public"."pings" TO "postgres";
GRANT ALL ON TABLE "public"."pings" TO "anon";
GRANT ALL ON TABLE "public"."pings" TO "authenticated";
GRANT ALL ON TABLE "public"."pings" TO "service_role";


--
-- Name: SEQUENCE "pings_id_seq"; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE "public"."pings_id_seq" TO "postgres";
GRANT ALL ON SEQUENCE "public"."pings_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."pings_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."pings_id_seq" TO "service_role";


--
-- Name: TABLE "state"; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON TABLE "public"."state" TO "postgres";
GRANT ALL ON TABLE "public"."state" TO "anon";
GRANT ALL ON TABLE "public"."state" TO "authenticated";
GRANT ALL ON TABLE "public"."state" TO "service_role";


--
-- Name: SEQUENCE "state_env_id_seq"; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE "public"."state_env_id_seq" TO "postgres";
GRANT ALL ON SEQUENCE "public"."state_env_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."state_env_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."state_env_id_seq" TO "service_role";


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."schema_migrations" TO "postgres";
GRANT ALL ON TABLE "realtime"."schema_migrations" TO "dashboard_user";


--
-- Name: TABLE "subscription"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."subscription" TO "postgres";
GRANT ALL ON TABLE "realtime"."subscription" TO "dashboard_user";


--
-- Name: SEQUENCE "subscription_id_seq"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "postgres";
GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "dashboard_user";


--
-- Name: TABLE "buckets"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."buckets" TO "anon";
GRANT ALL ON TABLE "storage"."buckets" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets" TO "postgres";


--
-- Name: TABLE "migrations"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."migrations" TO "anon";
GRANT ALL ON TABLE "storage"."migrations" TO "authenticated";
GRANT ALL ON TABLE "storage"."migrations" TO "service_role";
GRANT ALL ON TABLE "storage"."migrations" TO "postgres";


--
-- Name: TABLE "objects"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."objects" TO "anon";
GRANT ALL ON TABLE "storage"."objects" TO "authenticated";
GRANT ALL ON TABLE "storage"."objects" TO "service_role";
GRANT ALL ON TABLE "storage"."objects" TO "postgres";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES  TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS  TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES  TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES  TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS  TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES  TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES  TO "service_role";


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_graphql_placeholder" ON "sql_drop"
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION "extensions"."set_graphql_placeholder"();


ALTER EVENT TRIGGER "issue_graphql_placeholder" OWNER TO "supabase_admin";

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_cron_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE SCHEMA')
   EXECUTE FUNCTION "extensions"."grant_pg_cron_access"();


ALTER EVENT TRIGGER "issue_pg_cron_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_graphql_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE FUNCTION')
   EXECUTE FUNCTION "extensions"."grant_pg_graphql_access"();


ALTER EVENT TRIGGER "issue_pg_graphql_access" OWNER TO "supabase_admin";

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_ddl_watch" ON "ddl_command_end"
   EXECUTE FUNCTION "extensions"."pgrst_ddl_watch"();


ALTER EVENT TRIGGER "pgrst_ddl_watch" OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_drop_watch" ON "sql_drop"
   EXECUTE FUNCTION "extensions"."pgrst_drop_watch"();


ALTER EVENT TRIGGER "pgrst_drop_watch" OWNER TO "supabase_admin";

--
-- PostgreSQL database dump complete
--

